import pandas as pd
import requests
import input_database
from common_function import get_uuid_list_through_filter
from etc_module.function import stock_mkt_type

session = requests.Session()


class PositionsByTradeIdea:
    def __init__(self, fund_name):
        self.fund_name = fund_name
        self.member = None

    def approved_ideas(self):
        if self.fund_name == "prelude":
            _from = "2024-09-01"
        else:
            _from = "2022-01-01"
        _set_date = {"from": _from, "to": input_database.today_middle_bar}
        approve_ideas = session.get(
            url=input_database.url_tradeideas_new, params=_set_date
        ).json()["body"]
        proper_list = [
            input_database.account_nh_futures['accountId'],
            input_database.account_nh["accountId"],
            input_database.account_samsung_trs["accountId"],
            input_database.account_samsung_cfd["accountId"],
            input_database.account_kiwoom["accountId"],
            input_database.account_kiwoom_futures["accountId"],
            input_database.account_proper_ipo['accountId']
        ]
        ipo_list = get_uuid_list_through_filter("ipo-1")
        kosdaq_venture_list = get_uuid_list_through_filter("venture-1")
        multi_list = get_uuid_list_through_filter("multi-1")
        prelude_list = get_uuid_list_through_filter("et-prelude")
        ipo_position_id = list()
        kosdaq_venture_id = list()
        multi_id = list()
        prelude_id = list()
        for _approve_ideas in approve_ideas:
            for _idea in _approve_ideas["tradeIdeaPerformances"]:
                if _idea["accountId"] in ipo_list:
                    ipo_position_id.append(_idea)
                elif _idea["accountId"] in kosdaq_venture_list:
                    kosdaq_venture_id.append(_idea)
                elif _idea["accountId"] in multi_list:
                    multi_id.append(_idea)
                elif _idea["accountId"] in prelude_list:
                    prelude_id.append(_idea)
        if self.fund_name == "ipo":
            return ipo_position_id
        elif self.fund_name == "kv":
            return kosdaq_venture_id
        elif self.fund_name == 'multi':
            return multi_id
        elif self.fund_name == 'prelude':
            return prelude_id


class CumulativePnlByIdeas:
    def __init__(self, _book_name):
        self.book_name = _book_name

    def cumulative_pnl(self, account_member_id: dict):
        positions_trade = PositionsByTradeIdea(self.book_name)
        positions_list = positions_trade.approved_ideas()
        win_ratio, lose_ratio, hit_ratio = 0, 0, 0
        realize_kp, realize_kq, unrealize_kp, unrealize_kq = 0, 0, 0, 0
        cumulative_kp, cumulative_kq = 0, 0
        member_positions = list()
        for _page in positions_list:
            _market, _type = stock_mkt_type(_page["ticker"])
            try:
                if (
                    member_trade_ideas(_page["positionId"])
                    == account_member_id["memberId"]
                ):
                    if _market == "KOSDAQ" or ("코스닥" in _page["stockName"]):
                        realize_kq += _page["realizedPnl"]
                        unrealize_kq += _page["unrealizedPnl"]
                        cumulative_kq += _page["cumulativePnl"]["value"]
                        member_positions.append(_page)
                        if (
                            _page["realizedPnl"] + _page["unrealizedPnl"] >= 0
                            and _type == "STOCK" or _type == "ETF"
                        ):
                            win_ratio += 1
                        elif (
                            _page["realizedPnl"] + _page["unrealizedPnl"] < 0
                            and _type == "STOCK" or _type == "ETF"
                        ):
                            lose_ratio += 1
                    else:
                        realize_kp += _page["realizedPnl"]
                        unrealize_kp += _page["unrealizedPnl"]
                        cumulative_kp += _page["cumulativePnl"]["value"]
                        member_positions.append(_page)
                        if (
                                _page["realizedPnl"] + _page["unrealizedPnl"] >= 0
                                and _type == "STOCK" or _type == "ETF"
                        ):
                            win_ratio += 1
                        elif (
                                _page["realizedPnl"] + _page["unrealizedPnl"] < 0
                                and _type == "STOCK" or _type == "ETF"
                        ):
                            lose_ratio += 1

                else:
                    continue
            except TypeError:
                print(_page)

        pnl_dict = dict()
        pnl_dict["hit_win"] = win_ratio
        pnl_dict["hit_lose"] = lose_ratio
        pnl_dict["realize_kp"] = realize_kp
        pnl_dict["realize_kq"] = realize_kq
        pnl_dict["unrealize_kp"] = unrealize_kp
        pnl_dict["unrealize_kq"] = unrealize_kq
        pnl_dict["cumulative_kp"] = cumulative_kp
        pnl_dict["cumulative_kq"] = cumulative_kq
        return pnl_dict


def member_trade_ideas(_position_id):
    position_info = session.get(
        url=input_database.url_positions_positionId + str(_position_id)
    ).json()["body"]
    return position_info["memberId"]


if __name__ == "__main__":
    trade_idea = CumulativePnlByIdeas("prelude")
    print(trade_idea.cumulative_pnl(input_database.member_yc))
