import os
import ccxt
import pandas as pd
import pybithumb
import math
import matplotlib.ticker as ticker
import requests
from Historic_Crypto import HistoricalData
from matplotlib import pyplot as plt
from matplotlib import spines
from datetime import datetime, timedelta, date


# 빗썸
def bithumb_hv(_ticker):
    get_data = pybithumb.get_ohlcv(_ticker)
    df = pd.DataFrame(get_data, columns=['open', 'high', 'low', 'close', 'volume'])
    df = df.drop(['open', 'high', 'low', 'volume'], axis=1)
    df['hv_180'] = 0
    df['hv_90'] = 0
    df['hv_30'] = 0
    df['hv_7'] = 0
    date_list = [180, 90, 30, 7]
    for date in date_list:
        for number in range(1, 365):
            df_period = df.iloc[-number - date - 1: -number, :]
            df_period['divide_closed'] = (df_period['close'] / (df_period['close'].shift(1))) - 1
            avg_data = df_period['divide_closed'].mean()
            df_period.loc[:, 'minus_avg'] = 0
            df_period.loc[:, 'dir_ln'] = 0
            df_period.loc[:, 'hv'] = 0
            for i in range(1, date):
                if avg_data >= df_period['divide_closed'].iloc[i]:
                    df_period['minus_avg'].iloc[i] = avg_data - df_period['divide_closed'].iloc[i]
                else:
                    df_period['minus_avg'].iloc[i] = df_period['divide_closed'].iloc[i] - avg_data
            for i in range(1, len(df_period)):
                df_period['dir_ln'].iloc[i] = math.pow(df_period['minus_avg'].iloc[i], 2)
            sum_dr = df_period['dir_ln'].sum()
            std_dev = sum_dr / date
            hv = math.sqrt(std_dev * 365)  # 연 환산일자를 365일로 crypto 기준
            df_period['hv'].iloc[-1] = hv
            df[f'hv_{date}'].iloc[-number] = df_period['hv'].iloc[-1]

    df = df.iloc[2472:, :]
    df.to_excel('../../../resources/output/stock/longshortbook/bithumb_hv.xlsx')
    return df


# 바이낸스
def binance_hv(_ticker):
    binance = ccxt.binance()
    btc_ohlcv = binance.fetch_ohlcv(_ticker + "/USDT", '1d')
    df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
    # df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
    # df.set_index('datetime', inplace=True)
    # df = df.drop(['open', 'high', 'low', 'volume'], axis=1)
    # df['hv_180'] = 0
    # df['hv_90'] = 0
    # df['hv_30'] = 0
    # df['hv_7'] = 0
    # date_list = [180, 90, 30, 7]
    # for date in date_list:
    #     for number in range(1, 320):
    #         df_period = df.iloc[-number - date - 1:-number, :]
    #         df_period['divide_closed'] = (df_period['close'] / (df_period['close'].shift(1))) - 1
    #         avg_data = df_period['divide_closed'].mean()
    #         df_period.loc[:, 'minus_avg'] = 0
    #         df_period.loc[:, 'dir_ln'] = 0
    #         df_period.loc[:, 'hv'] = 0
    #         for i in range(1, date):
    #             if avg_data >= df_period['divide_closed'].iloc[i]:
    #                 df_period['minus_avg'].iloc[i] = avg_data - df_period['divide_closed'].iloc[i]
    #             else:
    #                 df_period['minus_avg'].iloc[i] = df_period['divide_closed'].iloc[i] - avg_data
    #         for i in range(1, len(df_period)):
    #             df_period['dir_ln'].iloc[i] = math.pow(df_period['minus_avg'].iloc[i], 2)
    #         sum_dr = df_period['dir_ln'].sum()
    #         std_dev = sum_dr / date
    #         hv = math.sqrt(std_dev * 365)  # 연 환산일자를 365일로 crypto 기준
    #         df_period['hv'].iloc[-1] = hv
    #         df[f'hv_{date}'].iloc[-number] = df_period['hv'].iloc[-1]
    #
    # df = df.iloc[181:, :]
    df.to_excel('../../../resources/output/stock/longshortbook/binance_hv.xlsx')
    return df


# 업비트
def upbit_hv(_ticker):
    upbit_data = pyupbit.get_ohlcv(f'KRW-{_ticker}', count=800)
    df = upbit_data.drop(['open', 'high', 'low', 'volume', 'value'], axis=1)
    df['hv_180'] = 0
    df['hv_90'] = 0
    df['hv_30'] = 0
    df['hv_7'] = 0
    date_list = [180, 90, 30, 7]
    for date in date_list:
        for number in range(1, 365):
            df_period = df.iloc[-number - date:-number, :]
            df_period['divide_closed'] = (df_period['close'] / (df_period['close'].shift(1))) - 1
            avg_data = df_period['divide_closed'].mean()
            df_period.loc[:, 'minus_avg'] = 0
            df_period.loc[:, 'dir_ln'] = 0
            df_period.loc[:, 'hv'] = 0
            for i in range(1, date):
                if avg_data >= df_period['divide_closed'].iloc[i]:
                    df_period['minus_avg'].iloc[i] = avg_data - df_period['divide_closed'].iloc[i]
                else:
                    df_period['minus_avg'].iloc[i] = df_period['divide_closed'].iloc[i] - avg_data
            for i in range(1, len(df_period)):
                df_period['dir_ln'].iloc[i] = math.pow(df_period['minus_avg'].iloc[i], 2)
            sum_dr = df_period['dir_ln'].sum()
            std_dev = sum_dr / date
            hv = math.sqrt(std_dev * 365)  # 연 환산일자를 365일로 crypto 기준
            df_period['hv'].iloc[-1] = hv
            df[f'hv_{date}'].iloc[-number] = df_period['hv'].iloc[-1]

    df = df.iloc[481:, :]
    df.to_excel('../../../resources/output/stock/longshortbook/upbit_hv.xlsx')
    return df


# 코인베이스 생각
def coinbase_hv(_ticker):
    current_date = datetime.now()
    standard_date = current_date - timedelta(days=800)
    data = HistoricalData(f'{_ticker}-USD', 86400, standard_date.strftime('%Y-%m-%d-%H-%M')).retrieve_data()
    df = data.drop(['open', 'high', 'low', 'volume', ], axis=1)
    df['hv_180'] = 0
    df['hv_90'] = 0
    df['hv_30'] = 0
    df['hv_7'] = 0
    date_list = [180, 90, 30, 7]
    for date in date_list:
        for number in range(1, 365):
            df_period = df.iloc[-number - date: -number, :]
            df_period['divide_closed'] = (df_period['close'] / (df_period['close'].shift(1))) - 1
            avg_data = df_period['divide_closed'].mean()
            df_period.loc[:, 'minus_avg'] = 0
            df_period.loc[:, 'dir_ln'] = 0
            df_period.loc[:, 'hv'] = 0
            for i in range(1, date):
                if avg_data >= df_period['divide_closed'].iloc[i]:
                    df_period['minus_avg'].iloc[i] = avg_data - df_period['divide_closed'].iloc[i]
                else:
                    df_period['minus_avg'].iloc[i] = df_period['divide_closed'].iloc[i] - avg_data
            for i in range(1, len(df_period)):
                df_period['dir_ln'].iloc[i] = math.pow(df_period['minus_avg'].iloc[i], 2)
            sum_dr = df_period['dir_ln'].sum()
            std_dev = sum_dr / date
            hv = math.sqrt(std_dev * 365)  # 연 환산일자를 365일로 crypto 기준
            df_period['hv'].iloc[-1] = hv
            df[f'hv_{date}'].iloc[-number] = df_period['hv'].iloc[-1]

    df = df.iloc[481:, :]
    df.to_excel('../../../resources/output/stock/longshortbook/coinbase_hv.xlsx')
    return df


def get_exchange(_ticker):
    date_list = [180, 90, 30, 7]
    df_coinbase = coinbase_hv(_ticker)
    coin_180_list = list()
    coin_90_list = list()
    coin_30_list = list()
    coin_7_list = list()
    df_upbit = upbit_hv(_ticker)
    upbit_180_list = list()
    upbit_90_list = list()
    upbit_30_list = list()
    upbit_7_list = list()
    df_binance = binance_hv(_ticker)
    binance_180_list = list()
    binance_90_list = list()
    binance_30_list = list()
    binance_7_list = list()
    df_bithumb = bithumb_hv(_ticker)
    bithumb_180_list = list()
    bithumb_90_list = list()
    bithumb_30_list = list()
    bithumb_7_list = list()
    for date in date_list:
        for number in range(2, 9):  # 최근 30일 데이터
            coin_hv_data = (df_coinbase[f'hv_{date}'].iloc[-number])
            upbit_hv_data = (df_upbit[f'hv_{date}'].iloc[-number])
            binance_hv_data = (df_binance[f'hv_{date}'].iloc[-number])
            bithumb_hv_data = (df_bithumb[f'hv_{date}'].iloc[-number])
            if date == 180:
                coin_180_list.append(coin_hv_data)
                coin_180_list.reverse()
                upbit_180_list.append(upbit_hv_data)
                upbit_180_list.reverse()
                binance_180_list.append(binance_hv_data)
                binance_180_list.reverse()
                bithumb_180_list.append(bithumb_hv_data)
                bithumb_180_list.reverse()
            elif date == 90:
                coin_90_list.append(coin_hv_data)
                coin_180_list.reverse()
                upbit_90_list.append(upbit_hv_data)
                upbit_90_list.reverse()
                binance_90_list.append(binance_hv_data)
                binance_90_list.reverse()
                bithumb_90_list.append(bithumb_hv_data)
                bithumb_90_list.reverse()
            elif date == 30:
                coin_30_list.append(coin_hv_data)
                coin_30_list.reverse()
                upbit_30_list.append(upbit_hv_data)
                upbit_30_list.reverse()
                binance_30_list.append(binance_hv_data)
                binance_30_list.reverse()
                bithumb_30_list.append(bithumb_hv_data)
                bithumb_30_list.reverse()
            elif date == 7:
                coin_7_list.append(coin_hv_data)
                coin_7_list.reverse()
                upbit_7_list.append(upbit_hv_data)
                upbit_7_list.reverse()
                binance_7_list.append(binance_hv_data)
                binance_7_list.reverse()
                bithumb_7_list.append(bithumb_hv_data)
                bithumb_7_list.reverse()
    binance_hv_dict = dict()
    upbit_hv_dict = dict()
    bithumb_hv_dict = dict()
    coinbase_hv_dict = dict()

    binance_hv_dict['7hv'] = binance_7_list
    binance_hv_dict['30hv'] = binance_30_list
    binance_hv_dict['90hv'] = binance_90_list
    binance_hv_dict['180hv'] = binance_180_list
    bithumb_hv_dict['7hv'] = bithumb_7_list
    bithumb_hv_dict['30hv'] = bithumb_30_list
    bithumb_hv_dict['90hv'] = bithumb_90_list
    bithumb_hv_dict['180hv'] = bithumb_180_list
    upbit_hv_dict['7hv'] = upbit_7_list
    upbit_hv_dict['30hv'] = upbit_30_list
    upbit_hv_dict['90hv'] = upbit_90_list
    upbit_hv_dict['180hv'] = upbit_180_list
    coinbase_hv_dict['7hv'] = coin_7_list
    coinbase_hv_dict['30hv'] = coin_30_list
    coinbase_hv_dict['90hv'] = coin_90_list
    coinbase_hv_dict['180hv'] = coin_180_list
    return binance_hv_dict, upbit_hv_dict, bithumb_hv_dict, coinbase_hv_dict


def make_graph(_ticker, days):
    binance_hv_dict, upbit_hv_dict, bithumb_hv_dict, coinbase_hv_dict = get_exchange(_ticker)
    plt.plot(date_7_list, binance_hv_dict[f'{days}hv'], label='binance', marker='o')
    plt.plot(date_7_list, upbit_hv_dict[f'{days}hv'], label='upbit', marker='o')
    plt.plot(date_7_list, bithumb_hv_dict[f'{days}hv'], label='bithumb', marker='o')
    plt.plot(date_7_list, coinbase_hv_dict[f'{days}hv'], label='coinbase', marker='o')
    plt.ylabel(f'{days}days_hv', labelpad=10, loc='top')
    plt.xlabel('The last 7 days', labelpad=10, loc='right')
    plt.xticks([hv_7day, hv_yday])
    plt.legend()  # 범례 나타내기

    plt.savefig(f'{days}hv.png', dpi=200, facecolor='#eeeeee', bbox_inches='tight')
    plt.clf()

    return plt


def binance_current_px(_ticker):
    binance = ccxt.binance()
    btc_ohlcv = binance.fetch_ohlcv(_ticker + "/USDT", '1d')
    df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
    df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
    df.set_index('datetime', inplace=True)
    df['adjclose'] = df['close']
    df['ticker'] = str(_ticker)
    df_crypto = df[['open', 'high', 'low', 'close', 'adjclose', 'volume', 'ticker']]
    df_crypto = df_crypto.iloc[-300:]
    return df_crypto


def coinbase_historical_px(_ticker):
    current_date = datetime.now()
    standard_date = current_date - timedelta(days=800)
    data = HistoricalData(f'{_ticker}-USD', 86400, standard_date.strftime('%Y-%m-%d-%H-%M')).retrieve_data()
    price_dataframe = data[['open', 'high', 'low', 'close','volume']]
    return price_dataframe



pd.set_option('mode.chained_assignment', None)  # 오류메세지 X
# 표시할 날짜 리폼
date_yday = date.today() - timedelta(1)
date_30day = date.today() - timedelta(30)
date_20day = date.today() - timedelta(20)
date_10day = date.today() - timedelta(10)
date_7day = date.today() - timedelta(7)
hv_tday = date.today().strftime('%Y-%m-%d')
hv_yday = date_yday.strftime('%Y-%m-%d')
hv_30day = date_30day.strftime('%Y-%m-%d')
hv_20day = date_20day.strftime('%Y-%m-%d')
hv_10day = date_10day.strftime('%Y-%m-%d')
hv_7day = date_7day.strftime('%Y-%m-%d')
# 날짜 x label refrom
x_date_list = list()
x_date_list.append(hv_30day)
x_date_list.append(hv_20day)
x_date_list.append(hv_10day)
x_date_list.append(hv_yday)
date_test_list = pd.date_range(start=hv_7day, end=hv_yday)
date_7_list = list()
for date_reform in date_test_list:
    date_tail = str(date_reform)[0:10]
    date_7_list.append(date_tail)
if __name__ == "__main__":
    # binance_current_px('BTC')
    coinmarketcap_historical_px("SRM")
    # make_graph('BTC', 7)
    # make_graph('BTC', 180)
    # make_graph('BTC', 90)
    # make_graph('BTC', 30)
