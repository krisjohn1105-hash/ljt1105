# beta_hedge.py
import logging
import time
import requests
import input_database
import pandas as pd
import constants
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from etc_module.get_high_beta import chg_90d_beta
from common_function import get_uuid_list_through_filter
from collections import defaultdict

summary_table = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
logging.basicConfig(filename='beta_hedge.log', level=logging.INFO, format='%(asctime)s %(levelname)s:%(message)s')

# ==================== [설정] 전역 상수 (중복 제거) ====================
# 1. 지수 선물 티커
TICKER_KOSPI_FUT = "A0566"
TICKER_KOSDAQ_FUT = "A0666"

# 2. 멀티플라이어 (승수)
MULT_KOSPI = 50000
MULT_KOSDAQ = 10000

# 3. 헷지 임계값 (Threshold)
THRESH_KOSPI = 40000000
THRESH_KOSDAQ = 20000000

# 4. 가격 조회 실패 시 기본값
DEFAULT_PRICE_KOSPI = 800
DEFAULT_PRICE_KOSDAQ = 2107.40

# ==================== 누락된 구성 추가 ====================
if not hasattr(input_database, 'url_register_trade'):
    input_database.url_register_trade = "http://43.202.36.216:13060/register"
if not hasattr(input_database, 'url_approve_trade'):
    input_database.url_approve_trade = "http://43.202.36.216:13060/approve"
if not hasattr(input_database, 'url_trade_detail'):
    input_database.url_trade_detail = "http://43.202.36.216:13060/"
if not hasattr(input_database, 'url_add_position_basket'):
    input_database.url_add_position_basket = "http://43.202.36.216:15000/api/baskets/{}/positions"
if not hasattr(input_database, 'member_pm'):
    input_database.member_pm = {"memberId": "pm_default_id"}


# ==================== 공통 함수 ====================
def format_dict_as_amounts(input_dict):
    return {key: f"{value:,.0f}" for key, value in input_dict.items()}


def post_json_safe(url, data):
    try:
        res = requests.post(url, json=data).json()
        return res['body'] if isinstance(res, dict) and 'body' in res else res
    except Exception as e:
        logging.error(f"Error in POST {url}: {e}")
        return []


def get_json_safe(url, params=None):
    try:
        res = requests.get(url, params=params).json()
        return res['body'] if isinstance(res, dict) and 'body' in res else res
    except Exception as e:
        logging.error(f"Error in GET {url}: {e}")
        return {}


# ==================== [수정] 베타 계산 ====================
def get_beta_for_position(_position_id, position_info_dict):
    try:
        position_info = position_info_dict[_position_id]
        ticker = position_info.get('stockTicker')
        override_info = None

        if ticker in menual_check:
            member_short_name = None
            try:
                username = position_info['tradeIdea']['member']['username']
                if username == "jejang":
                    member_short_name = "jj"
                elif username == "hjung":
                    member_short_name = "hj"
                elif username == "ychung":
                    member_short_name = "yc"
                elif username == "kimwilliam81":
                    member_short_name = 'pm'
            except (KeyError, TypeError):
                pass

            ticker_overrides = menual_check[ticker]
            if member_short_name and member_short_name in ticker_overrides:
                override_info = ticker_overrides[member_short_name]
            elif 'default' in ticker_overrides:
                override_info = ticker_overrides['default']

        if override_info:
            _market = override_info['market']
            _beta = override_info['beta']
            notional = position_info.get('position', {}).get('quantity', 0) * \
                       position_info.get('position', {}).get('multiplier', 0) * \
                       position_info.get('lastPrice', 0) * _beta
        else:
            notional = position_info.get('betaHedgePortion', 0)
            _market = position_info.get('market')

        return {"ks": notional if _market == "KOSPI" else 0, "kq": notional if _market == "KOSDAQ" else 0}

    except KeyError:
        return {"ks": 0, "kq": 0}


def get_total_beta(position_ids, position_info_dict):
    total = {"ks": 0, "kq": 0}
    for pid in position_ids:
        result = get_beta_for_position(pid, position_info_dict)
        total["ks"] += result["ks"]
        total["kq"] += result["kq"]
    return total


# ==================== 인덱스 포지션 헷지 ====================
def open_new_index_and_add_to_basket(basket_id, fund_id, ticker, direction, qty, px, member_nickname="none"):
    asset_type = "TRS" if fund_id == fund_futures_accounts["prelude"] else "FUTURES"
    print(f" Asset Type determined for fund_id {fund_id}: {asset_type}")

    register_data = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": {
            "assetType": asset_type,
            "ticker": ticker,
            "direction": direction,
            "projectId": "string",
            "postId": f"",
            "virtual": True,
            "memberId": {
                "pm": "a080879d-8e96-47d9-9f5f-745ee6560735",
                "yc": "2c9cf099-5690-4778-b47f-3ce89e78d9e4",
                "hj": "5807eba5-c7d1-4fa0-9884-ea0becbda1f5",
                "jj": "ed62babc-3159-4f33-8022-0e507f324c79"
            }.get(member_nickname)
        }
    }
    trade = post_json_safe(input_database.url_register_trade, register_data)
    if not trade or 'id' not in trade:
        print("  ❌ Failed to register new index trade")
        return

    # Step 2: Approve the trade
    trade_id = trade['id']
    trade_time_safe = (datetime.now() - timedelta(seconds=2)).strftime('%H:%M:%S')
    approve_data = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": {
            "tradeIdeaId": trade_id,
            "accountId": fund_id,
            "quantity": abs(int(qty)),
            "currency": "KRW",
            "entryPrice": px,
            "tradeDateTime": f"{input_database.today_middle_bar}T{trade_time_safe}.000Z"
        }
    }
    approve = post_json_safe(input_database.url_approve_trade, approve_data)
    if not approve:
        print("  ❌ Failed to approve new index trade")
        return

    time.sleep(1)

    position_url = f"{input_database.url_trade_detail}{trade_id}"
    trade_detail = get_json_safe(position_url, {"tradeIdeaId": trade_id})
    print(f"  🔍 Trade detail response: {trade_detail}")
    new_position_id = trade_detail.get("positionId")
    if not new_position_id:
        print("  ❌ Failed to retrieve new position ID")
        return

    # Step 4: Add position to basket
    basket_url = input_database.url_add_position_basket.format(basket_id)
    post_json_safe(basket_url, [{"position_id": new_position_id}])
    print(f"  ✅ New index position {new_position_id} added to basket {basket_id}")


def get_index_by_market(position_ids):
    input_data = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": position_ids
    }
    position_data = post_json_safe(input_database.url_positions, input_data)

    market_positions = {
        "KOSPI": [],
        "KOSDAQ": []
    }

    for page in position_data:
        if page.get('quantity', 0) == 0 or len(page.get('ticker', '')) != 5:
            continue
        if page['ticker'].startswith("A05"):
            market_positions["KOSPI"].append(page)
        elif page['ticker'].startswith("A06"):
            market_positions["KOSDAQ"].append(page)

    return market_positions


def find_existing_index_position(market_positions, market: str, target_qty: int):
    for position in market_positions:
        qty = position.get('quantity', 0)
        if (target_qty > 0 and qty > 0) or (target_qty < 0 and qty < 0):
            return position
    return None


def trade_index(basket_name, index_position, target_qx, px):
    return execute_trade(basket_name, index_position['positionId'], target_qx, px)


# ==================== 펀드별 선물 계좌 ID ====================
fund_futures_accounts = {
    "kv1": "87912c10-3c5f-421e-a156-ccb24c179036",
    "kv2": "7cd67c8d-2c5a-416c-b8b5-6c3e514e8a64",
    "kv3": "81a9b5d3-ebf1-4f0f-a750-fb9c91b53d2c",
    "multi1": "a8cabae8-09a1-4301-83df-28c4883ab6c5",
    "multi2": "984730b0-e272-4d67-933b-225eb89c780a",
    "ipo1": "6a0152c8-f189-428b-b8ad-5f05b2702352",
    "prelude": "f30b96fe-59e5-42db-bf0e-b96e6ef8bd22"
}


# ==================== [추가] Sample 양식 변환 함수 ====================
def save_as_sample_format(df_log, timestamp_str):
    """
    생성된 실행 로그(df_log)를 Sample.xlsx 양식으로 변환하여 저장합니다.
    """
    if df_log.empty:
        return

    # 1. 매핑 설정 (필요시 수정하세요)
    member_map = {
        "pm": "Long Short__WK",
        "yc": "Long Short__YW",
        "hj": "Long Short__HJ",
        "jj": "Long Short__JJ"
    }

    ticker_map = {
        "KOSPI": "A0566",
        "KOSDAQ": "A0666"
    }

    # 2. 고정값 설정 (Sample 파일 기준)
    FX_RATE = 0.0007211781165712308  # 필요시 input_database 등에서 가져오도록 수정
    ACCOUNT_ID = 517879  # 고정 계좌 ID
    current_date = datetime.now().strftime("%Y-%m-%d")

    # 3. 데이터 변환
    new_rows = []
    for _, row in df_log.iterrows():
        # Action 변환 (BUY -> BuyToCover, SELL -> SellShort)
        # 헷지 로직상 숏을 칠때 SELL, 숏을 청산할 때 BUY라고 가정
        trans_type = "BuyToCover" if row['Action'] == "BUY" else "SellShort"

        # Book Name 매핑
        book_name = member_map.get(row['Member'], f"Long Short__{str(row['Member']).upper()}")

        # Identifier 매핑
        identifier = ticker_map.get(row['Market'], row['Market'])

        new_row = {
            'Trade Date': current_date,
            'Settle Date': current_date,
            'Account Id': ACCOUNT_ID,
            'Counterparty Code': 'INTL',
            'Transaction Type': trans_type,
            'Book Name': book_name,
            'Identifier': identifier,
            'Identifier Type': 'Bloomberg Yellow',
            'Quantity': abs(row['Req_Contracts']),
            'Settle CCY': 'USD',
            'Trade CCY': 'KRW',
            'Other Payments 1': 0,
            'Other Payments 1 Type': 'FlatCommission',
            'Trade Price': row['Index_Price'],
            'Trade/Settle FX Rate': FX_RATE,
            'Notes': row['Basket'],  # 비고란에 바스켓 이름 기재
            'Basket_id': row['Basket_id']
        }
        new_rows.append(new_row)

    # 4. 데이터프레임 생성 및 컬럼 순서 정렬
    df_converted = pd.DataFrame(new_rows)
    cols_order = [
        'Trade Date', 'Settle Date', 'Account Id', 'Counterparty Code', 'Transaction Type',
        'Book Name', 'Identifier', 'Identifier Type', 'Quantity', 'Settle CCY', 'Trade CCY',
        'Other Payments 1', 'Other Payments 1 Type', 'Trade Price', 'Trade/Settle FX Rate', 'Notes'
    ]

    # 컬럼 순서 강제 적용 (없는 컬럼은 에러 방지를 위해 처리)
    final_cols = [c for c in cols_order if c in df_converted.columns]
    df_converted = df_converted[final_cols]

    # 5. 엑셀 저장
    save_name = f"Converted_Log_{timestamp_str}.xlsx"
    df_converted.to_excel(save_name, index=False)
    print(f"✅ [변환 완료] Sample 양식 파일 저장됨: {save_name}")
# ==================== 실행 함수 ====================
def adjust_beta_priority(position_info_dict, basket_table):
    """
    [실제 실행] 베타헤지를 수행하고, 실행된 내역을 시뮬레이션 양식과 동일하게 엑셀로 저장합니다.
    """
    logging.info("Starting Beta Hedge Execution...")

    execution_details = []

    # [가격 조회]
    px_ks = get_price(TICKER_KOSPI_FUT)
    if px_ks == 0: px_ks = DEFAULT_PRICE_KOSPI

    px_kq = get_price(TICKER_KOSDAQ_FUT)
    if px_kq == 0: px_kq = DEFAULT_PRICE_KOSDAQ

    # [상수 사용] 계약당 가치 계산
    val_per_contract_ks = px_ks * MULT_KOSPI
    val_per_contract_kq = px_kq * MULT_KOSDAQ

    print(f"\n>>> 🚀 [HEDGE EXECUTION] 실제 주문 프로세스 시작")
    print(f"   (적용 가격: KS {px_ks} / KQ {px_kq})")

    _i = 1
    for _c in basket_table:
        basket_name = _c['name']
        basket_id = _c['basket_id']
        position_ids = _c['position_ids']

        # 멤버 파싱
        def extract_member(pids):
            for pid in pids:
                if pid in position_info_dict:
                    username = position_info_dict[pid]['tradeIdea']['member']['username']
                    if "ychung" in username: return "yc"
                    if "kimwilliam81" in username: return "pm"
                    if "jejang" in username: return "jj"
                    if "hjung" in username: return "hj"
            return "pm"

        _member = extract_member(position_ids)

        # 제외 바스켓
        if any(x in basket_name.lower() for x in ["hedge", "event", "macro", "fix", "block"]):
            _i += 1
            continue

        # 베타 계산 (딕셔너리 전달)
        beta_positions = get_total_beta(position_ids, position_info_dict)

        # ==================== KOSPI 헷지 ====================
        ks_beta = beta_positions['ks']
        req_ks = 0

        # [상수 사용] 임계값 체크
        if abs(ks_beta) > THRESH_KOSPI:
            raw_qx = round(abs(ks_beta) / val_per_contract_ks)
            if raw_qx == 0: raw_qx = 1
            req_ks = -raw_qx if ks_beta > 0 else raw_qx

            act = "SELL" if req_ks < 0 else "BUY"

            print(f"  ⚡ [{_member.upper()}] {basket_name} | KOSPI {req_ks:+} 계약 ({act}) 주문 실행 중...")

            index_info = get_index_by_market(position_ids)['KOSPI']
            existing_pos = find_existing_index_position(index_info, "KOSPI", req_ks)

            if existing_pos:
                trade_index(basket_name, existing_pos, req_ks, px_ks)
            else:
                fund_id = get_fund_id_for_basket(position_ids, basket_name)
                open_new_index_and_add_to_basket(basket_id, fund_id, TICKER_KOSPI_FUT,
                                                 "SHORT" if req_ks < 0 else "LONG",
                                                 abs(req_ks), px_ks, _member)

            execution_details.append({
                "Member": _member,
                "Basket": basket_name,
                "Market": "KOSPI",
                "Beta_KRW": ks_beta,
                "Index_Price": px_ks,
                "Req_Contracts": req_ks,
                "Action": act,
                "Status": "Executed"
            })

        # ==================== KOSDAQ 헷지 ====================
        kq_beta = beta_positions['kq']
        req_kq = 0

        # [상수 사용] 임계값 체크
        if abs(kq_beta) > THRESH_KOSDAQ:
            raw_qx = round(abs(kq_beta) / val_per_contract_kq)
            if raw_qx == 0: raw_qx = 1
            req_kq = -raw_qx if kq_beta > 0 else raw_qx

            act = "SELL" if req_kq < 0 else "BUY"

            print(f"  ⚡ [{_member.upper()}] {basket_name} | KOSDAQ {req_kq:+} 계약 ({act}) 주문 실행 중...")

            index_info = get_index_by_market(position_ids)['KOSDAQ']
            existing_pos = find_existing_index_position(index_info, "KOSDAQ", req_kq)

            if existing_pos:
                trade_index(basket_name, existing_pos, req_kq, px_kq)
            else:
                fund_id = get_fund_id_for_basket(position_ids, basket_name)
                open_new_index_and_add_to_basket(basket_id, fund_id, TICKER_KOSDAQ_FUT,
                                                 "SHORT" if req_kq < 0 else "LONG",
                                                 abs(req_kq), px_kq, _member)

            execution_details.append({
                "Member": _member,
                "Basket": basket_name,
                "Basket_id": basket_id,
                "Market": "KOSDAQ",
                "Beta_KRW": kq_beta,
                "Index_Price": px_kq,
                "Req_Contracts": req_kq,
                "Action": act,
                "Status": "Executed"
            })

        _i += 1

    # ==================== 엑셀 저장 ====================
    if execution_details:
        df_log = pd.DataFrame(execution_details)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_name = f"Hedge_Execution_Log_{ts}.xlsx"

        cols = ["Member", "Basket", "Market", "Beta_KRW", "Index_Price", "Req_Contracts", "Action", "Status"]
        final_cols = [c for c in cols if c in df_log.columns]
        df_log = df_log[final_cols]

        # 1. 원본 로그 저장
        df_log.to_excel(log_name, index=False)
        print(f"\n✅ [실행 완료] 주문 내역이 저장되었습니다: {log_name}")

        # 2. [추가] Sample 양식으로 변환하여 저장
        try:
            save_as_sample_format(df_log, ts)
        except Exception as e:
            print(f"⚠️ Sample 양식 변환 중 에러 발생: {e}")

    else:
        print("\n✅ [실행 완료] 헷지 조건에 해당하는 바스켓이 없어 주문이 발생하지 않았습니다.")


def get_fund_id_for_basket(position_ids, basket_name):
    """바스켓 내 포지션의 계좌를 확인하여 적절한 선물 계좌 ID 반환"""
    position_sample_id = position_ids[0] if position_ids else None
    pos_info = get_json_safe(input_database.url_positions_info + str(position_sample_id),
                             {'positionId': position_sample_id})
    acc_id = pos_info.get('accountId')

    if not acc_id:
        print(f"⚠️ Account mapping failed for {basket_name}. Select manually:")
        return fund_futures_accounts["prelude"]

    fund_key = match_account_to_fund(acc_id)
    return fund_futures_accounts.get(fund_key, fund_futures_accounts["prelude"])


# ==================== 유틸: 현재 지수 가격 ====================
def match_account_to_fund(account_id):
    if account_id in ipo_list: return 'ipo1'
    if account_id in kv_list: return 'kv1'
    if account_id in kv_2_list: return 'kv2'
    if account_id in kv_3_list: return 'kv3'
    if account_id in multi_1_list: return 'multi1'
    if account_id in multi_2_list: return 'multi2'
    if account_id in prelude_list: return 'prelude'
    return None


def execute_trade(basket_name, position_id, qty, px, member=None, ticker=None, fund=None):
    logging.info(
        f"Executing trade: basket={basket_name}, position_id={position_id}, qty={qty:+}, price={px}, member={member}, fund={fund}, ticker={ticker}")

    try:
        pos_info = get_json_safe(input_database.url_positions_info + str(position_id), {'positionId': position_id})
        is_virtual = pos_info.get('virtual', True)
    except Exception as e:
        logging.warning(f"Failed to get virtual flag for position {position_id}: {e}")
        is_virtual = True

    trade_time_safe = (datetime.now() - timedelta(seconds=2)).strftime('%H:%M:%S')
    trade_info = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": {
            "positionId": position_id,
            "quantity": abs(int(qty)),
            "currency": "KRW",
            "entryPrice": px,
            "tradeDateTime": f"{input_database.today_middle_bar}T{trade_time_safe}.000Z",
            "virtual": is_virtual
        }
    }

    url = input_database.url_sell_new if qty < 0 else input_database.url_buy_new
    response = requests.post(url=url, json=trade_info)
    summary_table[member][fund][ticker] += qty

    try:
        result = response.json()
        if response.status_code == 200 and 'body' in result:
            print(f"  ✅ Hedge executed in {basket_name}: position {position_id} {qty:+} @ {px}")
            logging.info(f"SUMMARY | {member} | {fund} | {'SELL' if qty < 0 else 'BUY '} | {ticker} | {qty:+} | {px}")
        else:
            print(f"  ❌ Hedge failed in {basket_name}: {result}")
    except Exception as e:
        print(f"  ❌ Exception in hedge response for {basket_name}: {e}")


def get_price(ticker):
    # if ticker == "A0566":
    #     return 1234.02
    try:
        return get_json_safe(input_database.url_get_price_ticker + ticker, {"ticker": ticker}).get("lastPrice", 0)
    except:
        return 0


# ==================== 기본 세팅 (멀티북 리스트 통합) ====================
ipo_list = get_uuid_list_through_filter("ipo-1")
kv_list = get_uuid_list_through_filter("venture-1")
kv_2_list = get_uuid_list_through_filter("venture-2")
kv_3_list = get_uuid_list_through_filter("venture-3")
multi_1_list = get_uuid_list_through_filter("multi-1")
multi_1_ls_list = get_uuid_list_through_filter("multi-1-ls") # 4번 계산기용 LS 전용 리스트
multi_2_list = get_uuid_list_through_filter("multi-2")
prelude_list = get_uuid_list_through_filter("et-prelude")
prelude_ls_list = get_uuid_list_through_filter("et-prelude-ls") # 🆕 프렐류드 LS 전용 필터 사용


def load_all_positions_id(target_list=None):
    # 모든 펀드 통합 조회
    if target_list is None:
        total_list = prelude_list
    else:
        total_list = target_list

    input_data = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": {
            "accountIds": total_list,
            "recordDate": input_database.today_middle_bar
        }
    }
    book_strategy_pages = post_json_safe(input_database.url_books_new, input_data)
    if not isinstance(book_strategy_pages, list): return []
    return [page for item in book_strategy_pages for page in item.get('pages', [])]


def get_basket_table(target_list=None):
    positions_list = load_all_positions_id(target_list)
    position_info_dict = {f"{item['position']['positionId']}": item for item in positions_list}
    position_id_list = list(set(position_info_dict.keys()))
    position_id_data = [{"position_id": item} for item in position_id_list]
    basket_table = post_json_safe(input_database.url_get_basketId_positionId, position_id_data)
    return position_info_dict, basket_table


def unwind_duplicate_index(position_info, basket_table):
    index_ticker = ["A01", "A05", "A06"]

    # [가격 조회]
    px_ks = get_price(TICKER_KOSPI_FUT)
    if px_ks == 0: px_ks = DEFAULT_PRICE_KOSPI
    px_kq = get_price(TICKER_KOSDAQ_FUT)
    if px_kq == 0: px_kq = DEFAULT_PRICE_KOSDAQ

    for _basket in basket_table:
        _index_list = []
        if any(x in _basket['name'].lower() for x in ["hedge", "event", "macro", "block"]): continue

        for _ps in _basket['position_ids']:
            if _ps not in position_info: continue
            info = position_info[_ps]
            ticker = info.get("stockTicker", "")
            if len(ticker) == 5 and ticker[:3] in index_ticker:
                market = info.get("market", "")
                if market in ["KOSPI", "KOSDAQ"]:
                    _index_list.append({"market": market, "position_id": _ps, "quantity": info['position']['quantity']})

        if len(_index_list) <= 1: continue

        for market in ["KOSPI", "KOSDAQ"]:
            longs = [p for p in _index_list if p['market'] == market and p['quantity'] > 0]
            shorts = [p for p in _index_list if p['market'] == market and p['quantity'] < 0]

            for long_pos in longs:
                for short_pos in shorts:
                    if long_pos['quantity'] == 0 or short_pos['quantity'] == 0: continue
                    offset_qty = min(long_pos['quantity'], abs(short_pos['quantity']))
                    if offset_qty == 0: continue

                    print(f"  🔄 Netting {offset_qty} contracts in {market} ({_basket['name']})")
                    price = px_ks if market == "KOSPI" else px_kq

                    execute_trade(_basket['name'], long_pos['position_id'], -offset_qty, price)
                    execute_trade(_basket['name'], short_pos['position_id'], offset_qty, price)
                    long_pos['quantity'] -= offset_qty
                    short_pos['quantity'] += offset_qty


# ==================== [수정] 수동 베타 설정 딕셔너리 ====================
menual_check = {
    # --- 사용자 요청 베타 고정 종목 (정정 반영) ---
    "008770": {"hj": {"beta": 0.4, "market": "KOSPI"}},   # 호텔신라 (KS)
    "000100": {"hj": {"beta": 0.7, "market": "KOSDAQ"}},  # 유한양행 (사용자 요청에 따라 KQ)
    "069620": {"hj": {"beta": 1, "market": "KOSDAQ"}},  # 대웅제약 (사용자 요청에 따라 KQ)
    # ------------------------------------------
    "A0666": {'default': {'beta': 1, 'market': 'KOSDAQ'}},
    "A0566": {'default': {'beta': 1, 'market': 'KOSPI'}},
    "298380": {"hj": {"beta": 1.2, 'market': 'KOSDAQ'}}, # 에이비엘바이오
    "000500": {"hj": {"beta": 1.0, 'market': 'KOSPI'}}, # 가온전선
    "103590": {"hj": {"beta": 1.0, 'market': 'KOSPI'}}, # 일진전기
    "068270": {"hj": {"beta": 0.85, "market": "KOSDAQ"}}, # 셀트리온
    "068760": {"hj": {"beta": 0.85, "market": "KOSDAQ"}}, # 셀트리온제약
    "128940": {"hj": {"beta": 0.8, "market": "KOSPI"}}, # 한미약품
    "207940": {"hj": {"beta": 0.8, "market": "KOSPI"}}, # 삼성바이오로직스
    "141080": {"hj": {"beta": 1.2, "market": "KOSDAQ"}}, # 리가켐바이오
    "456160": {"hj": {"beta": 1, "market": "KOSDAQ"}}, # 지투지바이오
    "302440": {"hj": {"beta": 0.8, "market": "KOSPI"}}, # SK바이오사이언스
    "028260": {"hj": {"beta": 1, "market": "KOSPI"}}, # 삼성물산
    "375500": {"hj": {"beta": 1, "market": "KOSPI"}}, # DL이앤씨
    "263750": {"hj": {"beta": 0.7, "market": "KOSDAQ"}}, # 펄어비스
    "462870": {"hj": {"beta": 0.7, "market": "KOSDAQ"}}, # 시프트업
    "0126Z0": {"hj": {"beta": 1, "market": "KOSDAQ"}}, # 삼성에피스홀딩스
    "006400": {"hj": {"beta": 0.7, "market": "KOSPI"}}, # 삼성SDI
    "373220": {"hj": {"beta": 0.7, "market": "KOSPI"}}, # LG에너지솔루션
}

"""
[beta 적용 우선순위]
1순위: 특정 운용역 이름(hj, yc)의 셋팅값이 있으면 먼저 가져옵니다.
2순위: 1순위 값이 명시되어 있지 않은 운용역이라면, default 값을 찾아 가져옵니다.
둘 다 없다면, 자동 계산 된 서버의 베타 혹은 추정 베타를 활용합니다.

[default로 세팅된 경우]
운용역이 누구든 관계없이 공통으로 모두에게 적용되는 수동 베타 값입니다.
이 종목을 담은 사람이 hj이든 yc이든 상관없이 시스템에서 무조건 고정된 베타를 사용하도록 만들 때 default를 사용합니다.
"""


# ==================== [수정] 베타 조회 및 계산 로직 개선 ====================
def get_ticker_beta_value(ticker, member_short, qty, price, multiplier, server_info=None):
    if ticker in menual_check:
        override = menual_check[ticker]
        setting = override.get(member_short, override.get('default'))
        if setting:
            return (price * qty * multiplier * setting['beta']), setting['market'], setting['beta']

    # 2. 서버 정보 활용
    if server_info:
        # ★ market은 항상 서버 기준 (포지션 진입 시점 상관계수로 서버가 고정한 값)
        market = server_info.get('market', 'KOSDAQ')
        hedge_portion = server_info.get('betaHedgePortion', 0)
        if hedge_portion != 0:
            calc_beta = hedge_portion / (price * qty * multiplier) if price * qty != 0 else 0
            return hedge_portion, market, calc_beta
        # betaHedgePortion이 0인 경우: beta만 chg_90d_beta에서 계산, market은 서버 것 유지
        try:
            _, beta = chg_90d_beta(ticker)  # market은 버리고 beta만 참고
        except:
            beta = 1.0
        return (price * qty * multiplier * beta), market, beta

    # 3. server_info 없는 경우 (엑셀 전용 신규 종목) — chg_90d_beta 사용
    try:
        market, beta = chg_90d_beta(ticker)
        return (price * qty * multiplier * beta), market, beta
    except:
        return (price * qty * multiplier * 1.0), 'KOSDAQ', 1.0


def load_and_simulate_file(fund_choice, include_excel=False):
    final_details = []

    # [가격 조회]
    px_ks = get_price(TICKER_KOSPI_FUT)
    if px_ks == 0: px_ks = DEFAULT_PRICE_KOSPI
    px_kq = get_price(TICKER_KOSDAQ_FUT)
    if px_kq == 0: px_kq = DEFAULT_PRICE_KOSDAQ

    # [상수 사용] 계약당 가치
    val_per_contract_ks = px_ks * MULT_KOSPI
    val_per_contract_kq = px_kq * MULT_KOSDAQ

    # [펀드 및 파일 경로 설정]
    if fund_choice == "1":
        target_list = multi_1_ls_list
        fund_name = "Multi1"
        target_file_path = f"{constants.LONGSHORT_DIR}/beta_test.xlsx" if include_excel else None
    else:
        target_list = prelude_ls_list
        fund_name = "Prelude"
        target_file_path = f"{constants.LONGSHORT_DIR}/_prelude.xlsx" if include_excel else None

    print(f"\n>>> 🔄 [통합 시뮬레이션] {fund_name} 바스켓별 데이터 분석 중...")
    print(f"   (적용 가격: KS {px_ks} / KQ {px_kq})")
    print(f"   (1계약 가치: KS {int(val_per_contract_ks):,}원 / KQ {int(val_per_contract_kq):,}원)")

    # 1. 서버 데이터 로드
    ticker_market_map = {}
    member_ticker_to_basket = {}
    basket_beta_dict = defaultdict(lambda: {'KS': 0.0, 'KQ': 0.0})

    try:
        position_info_dict, basket_table = get_basket_table(target_list)

        for basket in basket_table:
            b_name = basket['name']

            # 살아있는 포지션(position_info_dict에 존재) 중 첫 번째로 대표 멤버 결정
            # 디폴트 없음 — 살아있는 포지션이 하나도 없으면 바스켓 자체를 건너뜀
            current_member = None
            for _pid in basket['position_ids']:
                if _pid not in position_info_dict:
                    continue   # 죽은 포지션 스킵
                uname = position_info_dict[_pid].get('tradeIdea', {}).get('member', {}).get('username', '')
                if 'hjung' in uname:
                    current_member = 'hj'
                elif 'ychung' in uname:
                    current_member = 'yc'
                elif 'jejang' in uname:
                    current_member = 'jj'
                elif 'kimwilliam81' in uname:
                    current_member = 'pm'
                break   # 살아있는 첫 번째 포지션으로 결정 완료

            if current_member is None:
                # 모든 포지션이 죽어있는 바스켓 → 건너뜀
                print(f"  ⚠️  [BASKET SKIP] '{b_name}' — 살아있는 포지션 없음, 스킵")
                continue

            # ── [🔍 진단] 바스켓 내 전체 포지션 멤버 정보 출력 ──
            all_pids_info = []
            for _diag_pid in basket['position_ids']:
                if _diag_pid not in position_info_dict:
                    continue
                _d = position_info_dict[_diag_pid]
                _uname = _d.get('tradeIdea', {}).get('member', {}).get('username', '(없음)')
                _ticker = _d.get('stockTicker', '?')
                _name   = _d.get('stockName',  '?')
                _qty    = _d.get('position', {}).get('quantity', 0)
                all_pids_info.append(
                    f"      positionId={_diag_pid} | username={_uname:<20} | ticker={_ticker} | 종목명={_name} | qty={_qty}"
                )
            print(f"\n[🔍 BASKET] '{b_name}'  →  대표멤버={current_member.upper()}  (position 수={len(basket['position_ids'])})")
            for _line in all_pids_info:
                print(_line)
            # ── 진단 끝 ──

            # ★ [수정됨] 엑셀 파싱 시 '어느 바스켓 소속인지' 매핑하기 위해 딕셔너리에 먼저 무조건 등록합니다 (skip된 바스켓도 포함)
            for pid in basket['position_ids']:
                if pid not in position_info_dict: continue
                info = position_info_dict[pid]
                ticker = info.get('stockTicker')
                if not ticker: continue

                member_ticker_to_basket[(current_member, ticker)] = b_name
                ticker_market_map[ticker] = info.get('market', 'KOSDAQ')

            # ★ [수정됨] 서버 데이터 베타 계산 시뮬레이션에서는 제외해야 할 바스켓을 '매핑 완료 후'에 건너뜁니다
            if any(x in b_name.lower() for x in ["hedge", "event", "macro", "fix", "block"]):
                print(f"  ⚠️  [BETA SKIP] '{b_name}' — 베타 합산 대상이 아닙니다.")
                continue

            basket_beta_ks = 0
            basket_beta_kq = 0

            for pid in basket['position_ids']:
                if pid not in position_info_dict: continue
                info = position_info_dict[pid]
                ticker = info.get('stockTicker')
                if not ticker: continue

                qty = info['position']['quantity']
                price = info.get('lastPrice', 0)

                is_future = False
                temp_mult = info.get('position', {}).get('multiplier', 1) or 1

                if ticker.startswith('A05'):
                    temp_mult = MULT_KOSPI;
                    is_future = True
                elif ticker.startswith('A06'):
                    temp_mult = MULT_KOSDAQ;
                    is_future = True

                val = 0
                if is_future:
                    val = price * qty * temp_mult
                    mkt = 'KOSPI' if ticker.startswith('A05') else 'KOSDAQ'
                    if mkt == 'KOSPI':
                        basket_beta_ks += val
                    else:
                        basket_beta_kq += val
                else:
                    val, mkt, applied_beta = get_ticker_beta_value(
                        ticker, current_member, qty, price, temp_mult, server_info=info
                    )
                    # market은 get_ticker_beta_value 내부에서 서버 기준으로 이미 확정됨
                    if mkt == 'KOSPI':
                        basket_beta_ks += val
                    elif mkt == 'KOSDAQ':
                        basket_beta_kq += val

            if basket_beta_ks != 0 or basket_beta_kq != 0:
                basket_beta_dict[(current_member, b_name)]['KS'] += basket_beta_ks
                basket_beta_dict[(current_member, b_name)]['KQ'] += basket_beta_kq

    except Exception as e:
        print(f"⚠️ 서버 데이터 로드 실패: {e}")

    # 2. 엑셀 데이터 로드
    if target_file_path is not None:
        print(f">>> 📂 엑셀 데이터 로드 중 ('{target_file_path}')...")
        try:
            if target_file_path.endswith('.csv'):
                df = pd.read_csv(target_file_path)
            else:
                df = pd.read_excel(target_file_path)

            df.columns = df.columns.str.replace('\n', '').str.strip()
            excel_count = 0

            for _, row in df.iterrows():
                if fund_choice == "1":
                    raw_key = str(row.get('단축코드', '')).split('.')[0]
                    if raw_key and raw_key != 'nan':
                        raw_key = raw_key.zfill(6)
                else:
                    raw_key = str(row.get('BB Yellow Key', ''))

                if not raw_key or raw_key == 'nan': continue
                ticker = raw_key.split()[0]

                try:
                    if fund_choice == "1":
                        raw_qty = float(str(row.get('체결수량', 0)).replace(',', ''))
                        trade_type = str(row.get('매매구분', '')).strip().lower()
                        if '매도' in trade_type or str(row.get('매매유형', '')).lower() == '매도' or 'sell' in trade_type:
                            qty = -abs(raw_qty)
                        else:
                            qty = abs(raw_qty)

                        price_val = row.get('단가', row.get('체결', 0))
                        price = float(str(price_val).replace(',', ''))
                    else:
                        qty = float(str(row.get('Notional Quantity', 0)).replace(',', ''))
                        price = float(str(row.get('Trade Price', 0)).replace(',', ''))
                    if qty == 0 or price == 0: continue
                except:
                    continue

                # 펀드 필터링 로직: 멀티1호 펀드인지 확인
                if fund_choice == "1":
                    row_text = " ".join(str(v) for v in row.values)
                    if "DM14001" not in row_text and "두나미스 멀티전략" not in row_text:
                        continue

                # 엑셀 데이터상 1차 담당 운용역(주문자) 파싱
                if fund_choice == "1":
                    trader = str(row.get('운용역명', ''))
                    if '정영우' in trader: default_member = 'yc'
                    elif '정항준' in trader: default_member = 'hj'
                    elif '김대욱' in trader: default_member = 'pm'
                    else: default_member = 'pm'
                else:
                    default_member = parse_member_from_book(row.get('Book Name', ''))

                # 서버에 존재하는 포지션(기존 종목)인지 역방향 조회
                matching_members = [m for (m, t) in member_ticker_to_basket.keys() if t == ticker]

                if len(matching_members) == 1:
                    # 이 종목을 보유한 매니저가 단 한 명이라면, 주문자가 누구든 무조건 보유자 바스켓으로 귀속
                    member = matching_members[0]
                    b_name = member_ticker_to_basket.get((member, ticker))
                else:
                    # 아무도 안 갖고 있거나(완전신규) 2명 이상 중복 소유 중이면 주문을 넣은 주문자 우선
                    member = default_member
                    b_name = member_ticker_to_basket.get((member, ticker))

                if b_name is None:
                    b_name = f"NEW_TRADES_{member.upper()}"
                    # ── [🔍 진단] NEW_TRADE 발생 시 종목 정보 출력 ──
                    _sec_desc = str(row.get('Security Description', row.get('BB Yellow Key', ticker)))
                    _book_nm  = str(row.get('Book Name', ''))
                    print(f"  📌 [NEW_TRADE] ticker={ticker} | 종목={_sec_desc} | Book={_book_nm} | 파싱멤버={member.upper()} → '{b_name}'")
                    # ── 진단 끝 ──

                # 엑셀 종목 필터링 로직: 배제해야 할 바스켓에 속하는 종목은 아예 계산 건너뜀
                if any(x in b_name.lower() for x in ["hedge", "event", "macro", "fix", "block"]):
                    continue

                is_future = False
                temp_mult = 1.0

                if ticker.startswith('A05'):
                    temp_mult = MULT_KOSPI;
                    is_future = True
                elif ticker.startswith('A06'):
                    temp_mult = MULT_KOSDAQ;
                    is_future = True

                val = 0
                if is_future:
                    val = price * qty * temp_mult
                    mkt = 'KOSPI' if ticker.startswith('A05') else 'KOSDAQ'
                    if mkt == 'KOSPI':
                        basket_beta_dict[(member, b_name)]['KS'] += val
                    else:
                        basket_beta_dict[(member, b_name)]['KQ'] += val
                else:
                    val, mkt, applied_beta = get_ticker_beta_value(ticker, member, qty, price, 1.0, server_info=None)
                    # ★ 서버가 알고 있는 실제 상장 시장을 항상 우선 사용 (엔터주 등 KOSDAQ 종목이 KOSPI로 오분류되는 케이스 방지)
                    # 이전: mkt == 'KOSDAQ' and applied_beta == 1.0 일 때만 보정 → KOSPI로 잘못 반환 시 보정 안 됨
                    if ticker in ticker_market_map:
                        mkt = ticker_market_map[ticker]

                    if mkt == 'KOSPI':
                        basket_beta_dict[(member, b_name)]['KS'] += val
                    elif mkt == 'KOSDAQ':
                        basket_beta_dict[(member, b_name)]['KQ'] += val

                excel_count += 1

            print(f"   (엑셀 거래 {excel_count}건 반영 완료)")

        except Exception as e:
            print(f"❌ 엑셀 읽기 실패: {e}")

    for (mem, b_name), vals in basket_beta_dict.items():
        if vals['KS'] != 0 or vals['KQ'] != 0:
            final_details.append({
                "Source": "COMBINED", "Member": mem, "BasketName": b_name,
                "Beta_KS": vals['KS'], "Beta_KQ": vals['KQ']
            })

    # 3. 결과 집계 및 출력
    detail_export_list = []
    summary_export_list = []

    print("\n" + "=" * 110)
    print(f"📊 [1] 바스켓별 상세 내역 (Detailed Breakdown)")
    print("=" * 110)
    print(
        f"{'Member':<6} | {'Basket Name':<30} | {'Mkt':<6} | {'Net Beta (KRW)':>18} | {'Price':>8} | {'Req Qty':>8} | {'Action':<6}")
    print("-" * 110)

    final_details.sort(key=lambda x: (x['Member'], x['BasketName']))
    member_summary = defaultdict(lambda: {'KS': 0.0, 'KQ': 0.0})

    for item in final_details:
        mem = item['Member']
        member_summary[mem]['KS'] += item['Beta_KS']
        member_summary[mem]['KQ'] += item['Beta_KQ']

        # KOSPI — 임계값 초과한 바스켓만 Detail에 기록
        if item['Beta_KS'] != 0:
            req_ks = 0
            if abs(item['Beta_KS']) > THRESH_KOSPI:
                raw = round(abs(item['Beta_KS']) / val_per_contract_ks)
                if raw == 0: raw = 1
                req_ks = -raw if item['Beta_KS'] > 0 else raw
            act = "SELL" if req_ks < 0 else "BUY" if req_ks > 0 else "-"
            # 임계값을 넘지 않아도 Detail에 일단 기록 (사용자 요청)
            print(
                f"{mem.upper():<6} | {item['BasketName'][:30]:<30} | {'KS':<6} | {int(item['Beta_KS']):>18,} | {px_ks:>8} | {req_ks:>8} | {act:<6}")
            detail_export_list.append(
                {"Member": mem, "Basket": item['BasketName'], "Market": "KOSPI",
                 "Beta_KRW": item['Beta_KS'], "Index_Price": px_ks,
                 "Req_Contracts": req_ks, "Action": act})

        # KOSDAQ — 임계값 초과한 바스켓만 Detail에 기록
        if item['Beta_KQ'] != 0:
            req_kq = 0
            if abs(item['Beta_KQ']) > THRESH_KOSDAQ:
                raw = round(abs(item['Beta_KQ']) / val_per_contract_kq)
                if raw == 0: raw = 1
                req_kq = -raw if item['Beta_KQ'] > 0 else raw
            act = "SELL" if req_kq < 0 else "BUY" if req_kq > 0 else "-"
            # 임계값을 넘지 않아도 Detail에 일단 기록 (사용자 요청)
            print(
                f"{mem.upper():<6} | {item['BasketName'][:30]:<30} | {'KQ':<6} | {int(item['Beta_KQ']):>18,} | {px_kq:>8} | {req_kq:>8} | {act:<6}")
            detail_export_list.append(
                {"Member": mem, "Basket": item['BasketName'], "Market": "KOSDAQ",
                 "Beta_KRW": item['Beta_KQ'], "Index_Price": px_kq,
                 "Req_Contracts": req_kq, "Action": act})

    print("=" * 110)

    # 4. 멤버별 요약
    # ── [복구] 기존의 멤버/북별 통합 요약 (전체 베타 합산 기준)
    print("\n" + "=" * 80)
    print(f"📉 [2] 멤버별/북별 통합 요약 (Netting Summary)  ← 전체 베타 합산 기준")
    print("=" * 80)

    total_ks_beta = 0.0
    total_kq_beta = 0.0

    for mem in sorted(member_summary.keys()):
        vals = member_summary[mem]
        mem_ks_beta = vals['KS']
        mem_kq_beta = vals['KQ']

        mem_req_ks = 0
        if abs(mem_ks_beta) > THRESH_KOSPI:
            raw = round(abs(mem_ks_beta) / val_per_contract_ks)
            if raw == 0: raw = 1
            mem_req_ks = -raw if mem_ks_beta > 0 else raw

        mem_req_kq = 0
        if abs(mem_kq_beta) > THRESH_KOSDAQ:
            raw = round(abs(mem_kq_beta) / val_per_contract_kq)
            if raw == 0: raw = 1
            mem_req_kq = -raw if mem_kq_beta > 0 else raw

        total_ks_beta += mem_ks_beta
        total_kq_beta += mem_kq_beta

        if mem_ks_beta != 0:
            act = 'SELL' if mem_req_ks < 0 else 'BUY' if mem_req_ks > 0 else '-'
            print(f"{mem.upper():<10} | {'KS':<6} | {int(mem_ks_beta):>20,} | {mem_req_ks:>10} | {act}")
            summary_export_list.append(
                {"Type": "Member", "Name": mem.upper(), "Market": "KOSPI",
                 "Total_Beta_KRW": mem_ks_beta, "Index_Price": px_ks,
                 "Net_Contracts": mem_req_ks, "Action": act})
        if mem_kq_beta != 0:
            act = 'SELL' if mem_req_kq < 0 else 'BUY' if mem_req_kq > 0 else '-'
            print(f"{'':<10} | {'KQ':<6} | {int(mem_kq_beta):>20,} | {mem_req_kq:>10} | {act}")
            summary_export_list.append(
                {"Type": "Member", "Name": mem.upper(), "Market": "KOSDAQ",
                 "Total_Beta_KRW": mem_kq_beta, "Index_Price": px_kq,
                 "Net_Contracts": mem_req_kq, "Action": act})
        print("-" * 80)

    # 5. 전체 북 합산 (전체 베타 기준)
    book_req_ks = 0
    if abs(total_ks_beta) > THRESH_KOSPI:
        raw = round(abs(total_ks_beta) / val_per_contract_ks)
        if raw == 0: raw = 1
        book_req_ks = -raw if total_ks_beta > 0 else raw

    book_req_kq = 0
    if abs(total_kq_beta) > THRESH_KOSDAQ:
        raw = round(abs(total_kq_beta) / val_per_contract_kq)
        if raw == 0: raw = 1
        book_req_kq = -raw if total_kq_beta > 0 else raw

    if total_ks_beta != 0:
        act = 'SELL' if book_req_ks < 0 else 'BUY' if book_req_ks > 0 else '-'
        print(f"{'TOTAL_BOOK':<10} | {'KS':<6} | {int(total_ks_beta):>20,} | {book_req_ks:>10} | {act}")
        summary_export_list.append(
            {"Type": "BOOK_TOTAL", "Name": "ALL", "Market": "KOSPI",
             "Total_Beta_KRW": total_ks_beta, "Index_Price": px_ks,
             "Net_Contracts": book_req_ks, "Action": act})
    if total_kq_beta != 0:
        act = 'SELL' if book_req_kq < 0 else 'BUY' if book_req_kq > 0 else '-'
        print(f"{'':<10} | {'KQ':<6} | {int(total_kq_beta):>20,} | {book_req_kq:>10} | {act}")
        summary_export_list.append(
            {"Type": "BOOK_TOTAL", "Name": "ALL", "Market": "KOSDAQ",
             "Total_Beta_KRW": total_kq_beta, "Index_Price": px_kq,
             "Net_Contracts": book_req_kq, "Action": act})

    print("=" * 80 + "\n")

    # 6. 엑셀 저장
    if detail_export_list:
        try:
            timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_filename = f"Hedge_Simulation_{timestamp_str}.xlsx"

            with pd.ExcelWriter(save_filename, engine='openpyxl') as writer:
                pd.DataFrame(summary_export_list).to_excel(writer, sheet_name='Summary(요약)', index=False)
                pd.DataFrame(detail_export_list).to_excel(writer, sheet_name='Details(상세)', index=False)
            print(f"✅ [저장 완료] 파일명: {save_filename} | Details 행 수: {len(detail_export_list)}")
        except Exception as e:
            print(f"❌ 엑셀 저장 실패: {e}")


def parse_member_from_book(book_name):
    bn = str(book_name).upper().strip()
    if bn.endswith("YW"): return "yc"
    if bn.endswith("HJ"): return "hj"
    return "pm"


# ==================== [신규 추가] 4번 메뉴: Macro / Hedge 계산 ====================

def load_target_positions(target_list):
    """지정된 펀드 리스트의 포지션만 로드"""
    input_data = {
        "requestHeader": {
            "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
            "requestId": input_database.request_uuid,
            "requestTimestamp": input_database.timestamp
        },
        "body": {
            "accountIds": target_list,
            "recordDate": input_database.today_middle_bar
        }
    }
    book_strategy_pages = post_json_safe(input_database.url_books_new, input_data)
    if not isinstance(book_strategy_pages, list): return []
    return [page for item in book_strategy_pages for page in item.get('pages', [])]


def calculate_macro_hedge_contracts(target_list, fund_name):
    """
    pf_multi2와 로직을 동기화하며,
    검증을 위해 개별 포지션의 상세 내역까지 엑셀로 내보냅니다.
    """
    position_info_dict, basket_table = get_basket_table(target_list)
    if not basket_table:
        print(f"❌ 분석할 {fund_name} 데이터가 없습니다.")
        return

    px_ks = get_price(TICKER_KOSPI_FUT) or DEFAULT_PRICE_KOSPI
    px_kq = get_price(TICKER_KOSDAQ_FUT) or DEFAULT_PRICE_KOSDAQ
    val_per_ks = px_ks * MULT_KOSPI
    val_per_kq = px_kq * MULT_KOSDAQ

    stats = {
        "hj": {"KOSPI": 0.0, "KOSDAQ": 0.0},
        "yc": {"KOSPI": 0.0, "KOSDAQ": 0.0},
        "pm": {"KOSPI": 0.0, "KOSDAQ": 0.0}
    }

    detail_rows = []

    print(f"\n🔄 [데이터 분석 중] {fund_name} (상세 내역 추출 포함)...")

    for basket in basket_table:
        basket_name = basket['name']

        # 2-3번 항목과 동일하게 바스켓 이름에 특정 키워드가 포함되면 제외
        if any(x in basket_name.lower() for x in ["event", "macro", "fix", "block"]):
            continue

        for pid in basket['position_ids']:
            if pid not in position_info_dict:
                continue
            pos = position_info_dict[pid]

            # A. 운용역 분류
            uname = pos.get('tradeIdea', {}).get('member', {}).get('username', '')
            if "hjung" in uname:
                mem_id = "hj"
            elif "ychung" in uname:
                mem_id = "yc"
            else:
                mem_id = "pm"

            # B. 포지션 기본 정보 및 함수 파라미터 추출
            ticker = pos.get("position", {}).get("ticker", "")
            sec_type = pos.get("securityType", "STOCK")
            stock_name = pos.get("stockName", "N/A")

            qty = pos.get("position", {}).get("quantity", 0)
            price = pos.get("lastPrice", 0)
            multiplier = pos.get("position", {}).get("multiplier", 1) or 1
            notional = pos.get("positionNotionalValue", 0)

            # C. 시장 분류 및 베타 계산 (1번 메뉴와 통합)
            is_future = False
            if sec_type == "TRS" or (len(ticker) == 5 and ticker[:3] in ["A05", "A06", "A01"]):
                # 선물/TRS 예외 처리
                mkt_key = "KOSDAQ" if ticker.startswith("A06") or "KOSDAQ" in stock_name else "KOSPI"
                is_future = True
            else:
                mkt_key = "KOSPI" if pos.get('market') == "KOSPI" else "KOSDAQ"

            if is_future:
                # 지수 선물의 경우 델타 금액 그대로 반영 (베타 1.0)
                pos_beta_amt = notional if notional != 0 else (price * qty * multiplier)
                applied_beta = 1.0
            else:
                # 통합 함수 호출 (우선순위: 수동 지정 -> 서버 데이터 -> 외부 모듈)
                pos_beta_amt, func_mkt, applied_beta = get_ticker_beta_value(
                    ticker, mem_id, qty, price, multiplier, server_info=pos
                )
                # 함수에서 반환된 시장 구분(menual_check 마켓 설정 등)이 있다면 덮어쓰기
                if func_mkt:
                    mkt_key = func_mkt

            stats[mem_id][mkt_key] += pos_beta_amt

            detail_rows.append({
                "Member": mem_id.upper(),
                "Market": mkt_key,
                "StockName": stock_name,
                "Ticker": ticker,
                "SecurityType": sec_type,
                "Delta_KRW": int(notional) if notional != 0 else int(price * qty * multiplier),
                "PositionBeta_KRW": int(pos_beta_amt),
                "Applied_Beta": applied_beta
            })

    # 4. 결과 출력
    summary_export = []
    print("\n" + "=" * 125)
    print(f"📊 [{fund_name}] 운용역별 Net Beta 및 바스켓 매매 가이드")
    print("-" * 125)
    print(f"{'Member':<10} | {'Market':<8} | {'Net Beta (KRW)':>20} | {'Hedge Basket':>22} | {'Macro Basket':>22}")
    print("-" * 125)

    for mem in ["hj", "yc", "pm"]:
        for mkt in ["KOSPI", "KOSDAQ"]:
            net_beta = stats[mem][mkt]
            v_per_con = val_per_ks if mkt == "KOSPI" else val_per_kq
            contracts = round(abs(net_beta) / v_per_con)

            if net_beta > 0:
                h_act, m_act = "SELL", "BUY"
            else:
                h_act, m_act = "BUY", "SELL"

            h_str = f"{contracts}계약 {h_act}" if contracts > 0 else "-"
            m_str = f"{contracts}계약 {m_act}" if contracts > 0 else "-"

            print(f"{mem.upper():<10} | {mkt:<8} | {int(net_beta):>20,} | {h_str:>22} | {m_str:>22}")

            summary_export.append({
                "Member": mem.upper(),
                "Market": mkt,
                "Net_Beta_KRW": int(net_beta),
                "Hedge_Action": h_act,
                "Hedge_Qty": contracts,
                "Macro_Action": m_act,
                "Macro_Qty": contracts
            })

    print("=" * 125 + "\n")

    # 5. 엑셀 파일 저장
    if summary_export:
        ts = datetime.now().strftime('%H%M%S')
        filename = f"Net_Beta_Analysis_{fund_name}_{ts}.xlsx"

        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            pd.DataFrame(summary_export).to_excel(writer, sheet_name='Summary', index=False)
            pd.DataFrame(detail_rows).to_excel(writer, sheet_name='Position_Details', index=False)

        print(f"✅ 상세 내역이 포함된 리포트 저장 완료: {filename}")


# ==================== [신규 추가] 5번 메뉴: 바스켓단 + 애널리스트단 통합 시뮬레이션 ====================
def simulate_analyst_level_hedge(fund_choice):
    """
    1. 바스켓별로 베타를 구해서 예상 헤지를 계산 (시뮬레이션)
    2. YC의 모든 바스켓 베타와 1차 헤지 예상값을 합산하여 넷 베타 도출
    3. 남은 넷 베타를 메우기 위해 LS Hedge 바스켓에서 필요한 선물 계약 수 계산
    ※ 옵션 5는 거래 내역(엑셀)을 참고할 필요 없이 이미 부킹된 데이터만 조회합니다.
    """
    if fund_choice == "1":
        target_list = multi_1_ls_list
        fund_name = "Multi1"
    else:
        target_list = prelude_ls_list
        fund_name = "Prelude"

    position_info_dict, basket_table = get_basket_table(target_list)

    px_ks = get_price(TICKER_KOSPI_FUT)
    if px_ks == 0: px_ks = DEFAULT_PRICE_KOSPI
    px_kq = get_price(TICKER_KOSDAQ_FUT)
    if px_kq == 0: px_kq = DEFAULT_PRICE_KOSDAQ

    val_per_contract_ks = px_ks * MULT_KOSPI
    val_per_contract_kq = px_kq * MULT_KOSDAQ

    print(f"\n>>> 🚀 [AUTO HEDGE SIMULATION] {fund_name} 애널리스트단 (YC) 통합 헤지 시뮬레이션 (부킹 완료 기준)")
    print(f"   (적용 가격: KS {px_ks} / KQ {px_kq})")

    yc_baskets = []
    total_yc_current_ks = 0
    total_yc_current_kq = 0
    simulated_basket_hedges_ks_val = 0
    simulated_basket_hedges_kq_val = 0

    for _basket in basket_table:
        basket_name = _basket['name']
        position_ids = _basket['position_ids']

        # 멤버 파싱
        def extract_member(pids):
            for pid in pids:
                if pid in position_info_dict:
                    username = position_info_dict[pid]['tradeIdea']['member']['username']
                    if "ychung" in username: return "yc"
                    if "kimwilliam81" in username: return "pm"
                    if "jejang" in username: return "jj"
                    if "hjung" in username: return "hj"
            return "pm"

        _member = extract_member(position_ids)
        if _member != "yc":
            continue

        beta_positions = get_total_beta(position_ids, position_info_dict)
        ks_beta = beta_positions['ks']
        kq_beta = beta_positions['kq']

        total_yc_current_ks += ks_beta
        total_yc_current_kq += kq_beta

        is_exclude = any(x in basket_name.lower() for x in ["hedge", "event", "macro", "fix", "block"])

        req_ks = 0
        req_kq = 0

        if not is_exclude:
            # 1차 헤지 KOSPI
            if abs(ks_beta) > THRESH_KOSPI:
                raw_qx = round(abs(ks_beta) / val_per_contract_ks)
                if raw_qx == 0: raw_qx = 1
                req_ks = -raw_qx if ks_beta > 0 else raw_qx
                simulated_basket_hedges_ks_val += (req_ks * val_per_contract_ks)

            # 1차 헤지 KOSDAQ
            if abs(kq_beta) > THRESH_KOSDAQ:
                raw_qx = round(abs(kq_beta) / val_per_contract_kq)
                if raw_qx == 0: raw_qx = 1
                req_kq = -raw_qx if kq_beta > 0 else raw_qx
                simulated_basket_hedges_kq_val += (req_kq * val_per_contract_kq)

        yc_baskets.append({
            'name': basket_name,
            'ks_beta': ks_beta,
            'kq_beta': kq_beta,
            'req_ks': req_ks,
            'req_kq': req_kq,
            'is_exclude': is_exclude
        })

    # 전체 예상 합계 도출
    expected_net_ks = total_yc_current_ks + simulated_basket_hedges_ks_val
    expected_net_kq = total_yc_current_kq + simulated_basket_hedges_kq_val

    ls_hedge_req_ks = 0
    if abs(expected_net_ks) > THRESH_KOSPI:
        raw_qx = round(abs(expected_net_ks) / val_per_contract_ks)
        if raw_qx == 0: raw_qx = 1
        ls_hedge_req_ks = -raw_qx if expected_net_ks > 0 else raw_qx

    ls_hedge_req_kq = 0
    if abs(expected_net_kq) > THRESH_KOSDAQ:
        raw_qx = round(abs(expected_net_kq) / val_per_contract_kq)
        if raw_qx == 0: raw_qx = 1
        ls_hedge_req_kq = -raw_qx if expected_net_kq > 0 else raw_qx

    print("\n" + "=" * 105)
    print("📋 [1차] YC 바스켓단 베타 및 예상 헤지 내역")
    print("=" * 105)
    for b in yc_baskets:
        if b['is_exclude']:
            print(f"[{b['name'][:30]:<30}] (제외) KS Beta: {int(b['ks_beta']):>15,} | KQ Beta: {int(b['kq_beta']):>15,}")
        else:
            ks_act = f"{b['req_ks']:+}계약" if b['req_ks'] != 0 else "-"
            kq_act = f"{b['req_kq']:+}계약" if b['req_kq'] != 0 else "-"
            print(f"[{b['name'][:30]:<30}] KS Beta: {int(b['ks_beta']):>15,} ({ks_act:<6}) | KQ Beta: {int(b['kq_beta']):>15,} ({kq_act:<6})")

    print("\n" + "=" * 105)
    print("📊 [2차] YC 애널리스트단 통합 (LS Hedge) 예상 내역")
    print("=" * 105)
    print(f"현재 YC 전체 베타 (KS)        : {int(total_yc_current_ks):>18,}")
    print(f"바스켓단 시뮬레이션 반영 (KS) : {int(simulated_basket_hedges_ks_val):>18,}")
    print(f"최종 예상 넷 베타 (KS)        : {int(expected_net_ks):>18,}")

    if ls_hedge_req_ks != 0:
         print(f"▶️ [LS Hedge] 코스피 선물 추가 필요: {ls_hedge_req_ks:+} 계약 ({'SELL' if ls_hedge_req_ks < 0 else 'BUY'})")
    else:
         print(f"▶️ [LS Hedge] 코스피 선물 추가 불필요 (임계값 한도 내)")

    print("-" * 105)
    print(f"현재 YC 전체 베타 (KQ)        : {int(total_yc_current_kq):>18,}")
    print(f"바스켓단 시뮬레이션 반영 (KQ) : {int(simulated_basket_hedges_kq_val):>18,}")
    print(f"최종 예상 넷 베타 (KQ)        : {int(expected_net_kq):>18,}")

    if ls_hedge_req_kq != 0:
         print(f"▶️ [LS Hedge] 코스닥 선물 추가 필요: {ls_hedge_req_kq:+} 계약 ({'SELL' if ls_hedge_req_kq < 0 else 'BUY'})")
    else:
         print(f"▶️ [LS Hedge] 코스닥 선물 추가 불필요 (임계값 한도 내)")
    print("=" * 105 + "\n")


# ==================== 실행부 ====================
# ==================== 실행부 ====================
if __name__ == "__main__":
    print("=== BETA HEDGE SYSTEM ===")
    print("1. [SIMULATION] 시뮬레이션 (엑셀기반)")
    print("2. [EXECUTION] 실제 주문 실행")
    print("3. [CLEANUP] 중복 상계")
    print("4. [CALC] 운용역별 Macro/Hedge 계약 수 산출")
    print("5. [AUTO SIMULATION] 바스켓단 + 애널리스트단 통합 시뮬레이션 (YC 한정)")

    choice = input("Choice >> ").strip()

    if choice == "1":
        print("\n계산할 펀드를 선택하세요.")
        print("1. 멀티전략1호 (Multi1)")
        print("2. Prelude")
        fund_choice = input("Fund Choice >> ").strip()

        sub_choice = input("엑셀(거래내역 파일) 거래 내역을 포함하여 시뮬레이션 하시겠습니까? (1: 포함, 그 외: 미포함) >> ").strip()
        load_and_simulate_file(fund_choice, include_excel=(sub_choice == "1"))

    elif choice == "2":
        print("\n[실제 주문 실행] 베타 헤지를 실행할 펀드를 선택하세요.")
        print("1. Multi 1")
        print("2. Multi 2")
        print("3. KV 1")
        print("4. KV 2")
        print("5. KV 3")
        print("6. 국내 펀드 전체 일괄 (Multi 1/2 + KV 1/2/3)")
        print("7. Prelude (해외 펀드)")

        exec_choice = input("Fund Choice >> ").strip()

        fund_map = {
            "1": ("Multi1", multi_1_list),
            "2": ("Multi2", multi_2_list),
            "3": ("KV1", kv_list),
            "4": ("KV2", kv_2_list),
            "5": ("KV3", kv_3_list),
            "6": ("국내 펀드 전체", multi_1_list + multi_2_list + kv_list + kv_2_list + kv_3_list),
            "7": ("Prelude", prelude_list)
        }

        if exec_choice in fund_map:
            fund_name, target_list = fund_map[exec_choice]
            pos_dict, b_table = get_basket_table(target_list=target_list)
            print(f"\n>>> 🚀 [{fund_name}] 실제 주문 프로세스 시작")
            adjust_beta_priority(pos_dict, b_table)
        else:
            print("❌ 잘못된 입력입니다. 1~7 사이의 값을 선택해주세요.")

    elif choice == "3":
        print("\n[중복 상계] 정리할 펀드를 선택하세요.")
        print("1. Multi 1")
        print("2. Multi 2")
        print("3. KV 1")
        print("4. KV 2")
        print("5. KV 3")
        print("6. 국내 펀드 전체 일괄 (Multi 1/2 + KV 1/2/3)")
        print("7. Prelude (해외 펀드)")

        cleanup_choice = input("Fund Choice >> ").strip()

        fund_map = {
            "1": ("Multi1", multi_1_list),
            "2": ("Multi2", multi_2_list),
            "3": ("KV1", kv_list),
            "4": ("KV2", kv_2_list),
            "5": ("KV3", kv_3_list),
            "6": ("국내 펀드 전체", multi_1_list + multi_2_list + kv_list + kv_2_list + kv_3_list),
            "7": ("Prelude", prelude_list)
        }

        if cleanup_choice in fund_map:
            fund_name, target_list = fund_map[cleanup_choice]
            pos_dict, b_table = get_basket_table(target_list=target_list)
            print(f"\n>>> 🧹 [{fund_name}] 중복 상계(Cleanup) 프로세스 시작")
            unwind_duplicate_index(pos_dict, b_table)
        else:
            print("❌ 잘못된 입력입니다. 1~7 사이의 값을 선택해주세요.")

    elif choice == "4":
        print("\n계산할 펀드를 선택하세요.")
        print("1. 멀티전략1호 (Multi1)")
        print("2. Prelude")
        fund_choice = input("Fund Choice >> ").strip()

        if fund_choice == "1":
            calculate_macro_hedge_contracts(multi_1_ls_list, "Multi1_LS")
        elif fund_choice == "2":
            calculate_macro_hedge_contracts(prelude_ls_list, "Prelude_LS")
        else:
            print("❌ 잘못된 입력입니다. 1번 또는 2번을 선택해 주세요.")

    elif choice == "5":
        print("\n계산할 펀드를 선택하세요.")
        print("1. 멀티전략1호 (Multi1)")
        print("2. Prelude")
        fund_choice = input("Fund Choice >> ").strip()
        simulate_analyst_level_hedge(fund_choice)

    else:
        print("잘못된 입력입니다. 1~5번 중 하나를 선택해 주세요.")

"""
======================================================================
💡 [BETA HEDGE 시스템 사용 가이드 및 기존 대비 개선점 정리]
======================================================================

[1. 사수님 업데이트: 기존 대비 핵심 로직 개선점]
1) 헷지 잔량(계약 수) 합산 파이프라인 정밀화:
   개별 바스켓 단위에서 임계값(Threshold)을 초과한 진성 펀드별 선물 '계약 수'들을 합산하던 방식을,
   모든 펀드의 베타값을 합쳐 전체 Net Beta에서 한 번에 헷지 잔량을 산출하도록 원복했습니다.
   (소형 바스켓의 베타도 모두 Netting에 포함되어 정확한 헷지 계약 수를 계산합니다.)
2) 시장(Market) 오분류 강력 방어:
   엔터주 등 KOSDAQ 종목이 일시적 오류로 KOSPI 베타를 바라보는 사고를 막기 위해,
   항상 서버가 보유한 실제 상장 시장 데이터(`ticker_market_map`)를 최우선으로 강제 덮어씌웁니다.
3) 청산된(Dead) 바스켓 크래시(Crash) 방지:
   바스켓 내 첫 종목이 청산된 포지션일 때 코드 라인이 꼬여 시스템이 강제종료되는 현상을 고쳤습니다.
   살아있는 포지션을 능동적으로 찾아 대표 운용역을 색출하고, 빈 바스켓은 에러 없이 깔끔히 스킵(Skip)합니다.
4) 새로운 종목(NEW_TRADES) 임시 격리 바스켓:
   사전 정의되지 않은 낯선 신규 거래 발생 시 프로그램이 뻗지 않도록 
   `NEW_TRADES_멤버명` 이라는 격리 바스켓 폴더에 즉시 편입시켜 안내 문구를 띄워줍니다.
5) 엑셀 결과물 최적화 필터:
   수량이 0이거나 '-' 로 처리되는 불필요한 바스켓 행들은 시뮬레이션 엑셀(Details) 결과물에서 제외하여 가독성을 높였습니다.
6) 한국 ATS 거래내역 양식(Multi-1) 완벽 호환 보강:
   기존 Prelude(Enfusion) 양식에 맞춰져 있던 파싱 로직을, 멀티1호 엑셀 양식(beta_test.xlsx)에 맞춰 전면 개편했습니다.
   - 열 헤더의 줄바꿈특수문자 제거 지원 (도착시간, 매매구분 등 파싱 오류 해결)
   - 'BB Yellow Key' 대신 6자리 '단축코드' 읽기 지원
   - '체결수량'에 절대값만 나오는 치명적 문제 해결 ('매매구분' 열의 '매도/매수' 텍스트를 감지하여 숏칠 경우 강제 음수(-) 차감 처리)
   - 'Trade Price' 대신 '단가' 열에서 결제 단가 호출 적용
   
   [❌ 기존 오류 코드] - 매도/매수 구분 없이 절대값 합산, 'BB Yellow Key' 의존으로 데이터 스킵 발생
   raw_key = str(row.get('BB Yellow Key', '')) 
   qty = float(str(row.get('체결수량', 0)).replace(',', ''))
   
   [✅ 수정된 코드] - 단축코드로 인식 후, 매도 텍스트가 발견되면 수량을 강제 마이너스(-) 전환
   raw_key = str(row.get('단축코드', ''))
   raw_qty = float(str(row.get('체결수량', 0)).replace(',', ''))
   trade_type = str(row.get('매매구분', '')).strip().lower()
   if '매도' in trade_type or str(row.get('매매유형', '')).lower() == '매도' or 'sell' in trade_type:
       qty = -abs(raw_qty)
   else:
       qty = abs(raw_qty)

7) Pandas 엑셀 읽기 오류(단축코드 소수점 표시) 완벽 방어:
   엑셀을 읽을 때 비어있는 셀이 있으면 파이썬이 종목코드를 소수점(float)으로 변환해버리는 고질적 오류를 해결했습니다.
   
   [❌ 기존 오류 발생] - '042660' 종목이 넘어오다 '42660.0' 으로 변질되어 종목 매칭 100% 실패
   raw_key = str(row.get('단축코드', ''))
   
   [✅ 수정된 코드] - 소수점을 자르고 빈 공간만큼 왼쪽을 '0'으로 채워 무조건 강력한 6자리 문자형(042660) 단위로 자동 복구
   raw_key = str(row.get('단축코드', '')).split('.')[0]
   if raw_key and raw_key != 'nan':
       raw_key = raw_key.zfill(6)

8) 가짜 신규 거래(NEW_TRADES) 쏠림 차단:
   기존엔 바스켓 이름에 'fix', 'hedge' 등이 있으면 서버 조회때 그 바스켓을 스킵해 버려 사전에 이름이 누락되었습니다.
   그로 인해 엑셀 파싱 시 시스템 로직이 '서버에 없는 신규 종목'이라 착각하고 NEW_TRADES_PM 이라는 임시 바스켓에 모든 거래를 넣게 되었고,
   이는 PM의 베타를 부풀리는 치명적인 오류로 이어졌습니다.

   [❌ 기존 오류 코드] - fix 바스켓 종목은 사전에 기록하지도 않고 스킵함 (역방향 매핑 실패의 원흉)
   if any(x in b_name.lower() for x in ["hedge", "event", "macro", "fix", "block"]): 
       continue

   [✅ 수정된 코드] - 모든 바스켓 소속의 '본명'을 사전에 무조건 등록부터 한 뒤에, 실제 베타 더하기 로직에서만 스킵하도록 이동!
   # 1. 엑셀 파싱 시 검색될 수 있게 사전에 무조건 모든 종목의 소속 본명을 등록함
   member_ticker_to_basket[(current_member, ticker)] = b_name
   
   # 2. 서버 데이터 베타 계산 시뮬레이션에서는 제외해야 할 바스켓을 '매핑 완료 후'에 건너뜁니다
   if any(x in b_name.lower() for x in ["hedge", "event", "macro", "fix", "block"]):
       continue

   # 3. 주문 역방향 추적 로직 추가
   matching_members = [m for (m, t) in member_ticker_to_basket.keys() if t == ticker]
   if len(matching_members) == 1:
       member = matching_members[0] # PM 계정으로 주문했더라도 본래 주인이 YC 한 명이면 무조건 YC 역방향 귀속!

---

[2. 모드(Mode)별 작동 원리 및 사용 안내]

▶ 1. [SIMULATION] 시뮬레이션 (엑셀기반)
   - 용도: 당일 체결 내역(엑셀)과 서버의 실제 롱숏 포지션을 합산하여 최신 순베타 수치를 구상합니다.
   - 작동: 종목별 베타는 '수동 매뉴얼(menual_check)' → '서버 지정 헷지비율' → '시스템 90일 계산 베타' 순의 
           우선순위로 적용되어 돌아가며, 임계치(KS: 4천만, KQ: 2천만)를 넘어선 바스켓만 모아 헷지 시뮬레이션 엑셀을 뽑아냅니다.
           실제 주문은 나가지 않는 안전한 모드입니다.

▶ 2. [EXECUTION] 실제 헷지 주문 결행
   - 용도: 시뮬레이션에서 나온 헷지 필요 계약 수 결과값을 실제로 서버에 밀어넣어 '현행 주문'을 발생시킵니다.
   - 주의: KOSPI/KOSDAQ 선물 주문 결제 API(`execute_trade`)가 호출되므로 포지션 변동에 직접적인 영향이 큽니다.

▶ 3. [UNWIND] 양방향 선물 네팅(Netting) 자동 상계
   - 용도: 동일 바스켓 안에 서로 방향이 교차하는(롱/숏이 혼재된) 인덱스 포지션이 있을 경우 진단합니다.
   - 작동: 양방향이 겹치는 최소 수량(offset_qty)만큼 내부적으로 롱과 숏 주문을 서로 부딪히게 태워, 
           불필요한 인덱스 선물 중복 결제를 자동 청산(Netting) 해줍니다.

▶ 4. [ANALYST SIMULATION] 애널리스트/매니저별 가벼운 헷지 현황 조회
   - 용도: 멀티전략1호나 Prelude 계좌 안에서도, 세부 매니저(pm, hj, yc, jj 등)별로 헷지 시뮬레이션 결과를 
           무거운 엑셀 저장 절차 없이 가상으로 돌려보고 터미널(콘솔) 화면으로 빠르게 진단하고 싶을 때 사용합니다.
======================================================================
"""