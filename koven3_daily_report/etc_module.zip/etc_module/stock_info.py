import time
import pandas as pd
import win32com.client
from pywinauto import application


def ping():
    loggin_api = win32com.client.Dispatch("CpUtil.CpCybos")
    bconnect = loggin_api.IsConnect
    if bconnect != 1:
        print("연결 시도중")
        connect_daishin()
        time.sleep(40)


def connect_daishin():
    app = application.Application()
    path = 'C:\CREON\STARTER/coStarter.exe'
    project = 'cp'
    id = 'zldqms6'
    pwd = 'wns0220!'
    pwd_cer = 'rkwns0118!'
    app.start(
        f'{path} /prj:{project} /id:{id} /pwd:{pwd} '
        f'/pwdcert:{pwd_cer} /autostart')


def scrap_current(ticker):
    ping()
    creon_api_stock = win32com.client.Dispatch("Dscbo1.StockMst")
    creon_api_stock.SetInputValue(0, "A" + str(ticker))
    creon_api_stock.BlockRequest()
    current_px = creon_api_stock.GetHeaderValue(10)
    return current_px


def scrap_listing_date(ticker: str):
    ping()
    creon_api_list = win32com.client.Dispatch("CpUtil.CpCodeMgr")
    value = creon_api_list.GetStockListedDate('A' + ticker)
    return value


def get_period_price(_ticker, _date):
    ping()
    formatted_date = _date.replace("-", "")
    obj_stock_week = win32com.client.Dispatch("CpSysDib.StockChart")
    obj_stock_week.SetInputValue(0, 'A' + str(_ticker))
    obj_stock_week.SetInputValue(1, ord('1'))
    obj_stock_week.SetInputValue(3, int(formatted_date))
    obj_stock_week.SetInputValue(5, (0, 8, 9))
    obj_stock_week.SetInputValue(6, ord('D'))
    obj_stock_week.BlockRequest()
    num_data = obj_stock_week.GetHeaderValue(3)
    stock_list = list()
    for i in reversed(range(num_data)):
        chart_data = dict()
        chart_data['date'] = obj_stock_week.GetDataValue(0, i)
        chart_data['vol']: int = obj_stock_week.GetDataValue(1, i)
        chart_data['price'] = int(obj_stock_week.GetDataValue(2, i)) / int(chart_data['vol'])
        stock_list.append(chart_data)
    stock_dataframe = pd.DataFrame(stock_list)
    stock_dataframe.set_index("date", inplace=True)
    return stock_dataframe


def convert_string_format(_date: str):
    formatted_date = _date[:4] + "-" + _date[4:6] + "-" + _date[6:]
    return formatted_date


if __name__ == '__main__':
    print(get_period_price("105760", "2024-08-02"))
