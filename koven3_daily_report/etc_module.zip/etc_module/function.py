import uuid
import time
import constants
import pandas as pd
import requests
import input_database
from prettytable import PrettyTable

session = requests.Session()


def stock_mkt_type(_ticker: str):
    stock_data = session.get(
        url=input_database.url_stock_ticker + _ticker, params=_ticker
    ).json()["body"]
    _market = stock_data["market"]
    _type = stock_data["securityType"]
    return _market, _type


def cumulative_pnl_list(account_id: dict):
    input_ecm = {"accountId": account_id["accountId"]}
    positions_list = session.get(
        url=input_database.url_position_all_new, params=input_ecm
    ).json()["body"]
    cumulative_list = list()
    for _page in positions_list:
        perform_dict = dict()
        perform_dict["Ticker"] = str(_page["ticker"])
        try:
            perform_dict["Name"] = _page["stockName"]
        except KeyError:
            perform_dict["Name"] = _page["contractName"]
        perform_dict["OpenDate"] = _page["openedDateTime"]
        perform_dict["LastDate"] = _page["closedDateTime"]
        perform_dict["ListingDate"] = get_listing_date(_page["ticker"])
        perform_dict["direction"] = _page["direction"]
        if _page["direction"] == "LONG":
            perform_dict["pnl"] = -_page["grossValueSell"] - _page["grossValueBuy"]
        else:
            perform_dict["pnl"] = _page["grossValueBuy"] + _page["grossValueSell"]
        cumulative_list.append(perform_dict)
    ecm_perform_data = pd.DataFrame(cumulative_list)
    ecm_perform_data.to_excel(
        f"{constants.OUTPUT_DIR}/check_member_pnl.xlsx", index=False
    )
    return cumulative_list


def get_listing_date(ticker: str):
    stock_data = session.get(
        url=input_database.url_stock_ticker + ticker, params=ticker
    ).json()["body"]
    listing_date = stock_data["listingDate"]
    return listing_date


def revert_last_order(positionid):
    revert_order = {
        "requestHeader": {
            "protocolVersion": {"minor": 0, "major": 1, "revision": 0},
            "requestId": f"{request_uuid}",
            "requestTimestamp": timestamp,
        },
        "body": {"positionId": positionid},
    }
    revert_order_data = session.post(
        url=input_database.url_stock_revert, json=revert_order
    ).json()
    print(revert_order_data)
    return revert_order_data


class OrderData:
    def __init__(self, _ticker, _positionid, _quantity, _price, _date):
        self.positionid = _positionid
        self.ticker = _ticker
        self.quantity = _quantity
        self.price = _price
        self.date = _date

    def buy_order(self):
        # position_order = {
        #     "requestHeader": {
        #         "protocolVersion": {
        #             "major": 1,
        #             "minor": 0,
        #             "revision": 0
        #         },
        #         "requestId": f'{request_uuid}',
        #         "requestTimestamp": timestamp
        #     },
        #     "body": {
        #         "positionId": self.positionid,
        #         "quantity": self.quantity,
        #         "currency": "KRW",
        #         "entryPrice": self.price,
        #         "tradeDateTime": f"2022-{self.date}T09:01:49"
        #     }
        # }
        # position_order_data = session.post(url=buy_url, json=position_order).json()
        # print(position_order_data)
        name_by_ticker = session.get(
            url=input_database.url_stock_ticker + str(self.ticker)
        ).json()["body"]
        contract_message = f'[체결내역]\n매수 - {name_by_ticker["name"]}({self.ticker}) / {self.quantity} 주 / 체결단가 : {self.price} 원'
        nateon_parameter = {"content": contract_message}
        send_nateon_order = session.post(
            url=nateon_url,
            headers=headers,
            data=nateon_parameter,
            timeout=5,
            verify=False,
        )
        # return position_order_data

    def sell_order(self):
        sell_position_order = {
            "requestHeader": {
                "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                "requestId": f"{request_uuid}",
                "requestTimestamp": timestamp,
            },
            "body": {
                "positionId": self.positionid,
                "quantity": self.quantity,
                "currency": "KRW",
                "entryPrice": self.price,
                "tradeDateTime": f"2022-{self.date}T10:01:49",
            },
        }
        sell_order_data = session.post(
            url=input_database.url_pre_sell, json=sell_position_order
        ).json()
        print(sell_order_data)
        name_by_ticker = session.get(
            url=input_database.url_stock_ticker + str(self.ticker)
        ).json()["body"]
        contract_message = f'[체결내역]\n매도 - {name_by_ticker["name"]}({self.ticker}) / {self.quantity} 주 / 체결단가 : {self.price} 원'
        nateon_parameter = {"content": contract_message}
        send_nateon_order = session.post(
            url=nateon_url,
            headers=headers,
            data=nateon_parameter,
            timeout=5,
            verify=False,
        )
        return contract_message

def get_transaction(position_id):
    input_trans_data = {"positionIds": position_id}
    trans_data = session.get(url=trans_url, params=input_trans_data).json()
    print(trans_data["body"])
    return trans_data["body"]


def pages_list(account_name):
    if account_name == "ipo":
        input_ipo_ss = {"accountId": "d123d371-0395-458c-8a8e-f553fca42f13"}
        ipo_ss = session.get(url=positions_url, params=input_ipo_ss).json()
        input_ipo_futures = {"accountId": "b924f96c-2b12-426b-af8e-7a1b0ac473ad"}
        ipo_futures = session.get(url=positions_url, params=input_ipo_futures).json()
        ipo_list = ipo_ss["body"] + ipo_futures["body"]
        ipo_id = list()
        for page in ipo_list:
            id_dict = dict()
            id_dict[f'{page["stockName"]}'] = page["positionId"]
            ipo_id.append(id_dict)
        print(ipo_id)
        return ipo_id
    elif account_name == "proper":
        input_samsung_ss = {"accountId": "ea1ef880-9f7f-4cfd-867e-1e2ec5da39e4"}
        input_nh_ss = {"accountId": "0c0338a6-36e4-4c38-ac0f-6fe17b4db23e"}
        get_samsung = session.get(url=positions_url, params=input_samsung_ss).json()[
            "body"
        ]
        get_nh = session.get(url=positions_url, params=input_nh_ss).json()["body"]
        get_proper_account = get_samsung + get_nh
        proper_id = list()
        for page in get_proper_account:
            proper_dict = dict()
            if page["accountId"] == input_samsung_ss["accountId"]:
                proper_dict["account"] = "samsung"
            elif page["accountId"] == input_nh_ss["accountId"]:
                proper_dict["account"] = "nh"
            else:
                proper_dict["account"] = "TBD"
            proper_dict[f'{page["stockName"]}'] = page["positionId"]
            proper_id.append(proper_dict)
        print(proper_id)
        return proper_id
    elif account_name == "qb":
        qb_id = list()
        get_qb = session.get(
            url=positions_url, params=input_database.account_qb
        ).json()["body"]
        for page in get_qb:
            qb_dict = dict()
            qb_dict[f'{page["stockName"]}'] = page["positionId"]
            qb_id.append(qb_dict)
        print(qb_id)
        return qb_id
    else:
        print("Check AccountName")


class TradingFunction:
    def __init__(self, _quantity, _entry_price, _open_date):
        self.account_id = None
        self.ticker = None
        self.quantity = _quantity
        self.entry_price = _entry_price
        self.open_date = _open_date
        self.position_id = None

    def order_open(self, account_id, ticker):
        order_body = {
            "requestHeader": {
                "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                "requestId": f"{request_uuid}",
                "requestTimestamp": timestamp,
            },
            "body": {
                "accountId": account_id,
                "ticker": ticker,
                "quantity": self.quantity,
                "entryPrice": self.entry_price,
                "openDateTime": f"2022-{self.open_date}T15:01:49",
            },
        }
        order_status = session.post(url=input_database.url_open_new, json=order_body)
        if order_status != 200:
            print("Error - Open order")
        return None

    def order_sell(self, position_id):
        order_body = {
            "requestHeader": {
                "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                "requestId": f"{request_uuid}",
                "requestTimestamp": timestamp,
            },
            "body": {
                "positionId": position_id,
                "quantity": self.quantity,
                "entryPrice": self.entry_price,
                "currency": "KRW",
                "tradeDateTime": f"2022-{self.open_date}T10:01:49",
            },
        }
        order_status = session.post(url=input_database.url_sell_new, json=order_body)
        if order_status.status_code != 200:
            print("Error - Sell order")
        return None

    def order_buy(self, position_id):
        order_body = {
            "requestHeader": {
                "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                "requestId": f"{request_uuid}",
                "requestTimestamp": timestamp,
            },
            "body": {
                "positionId": position_id,
                "quantity": self.quantity,
                "entryPrice": self.entry_price,
                "tradeDateTime": f"2022-{self.open_date}T10:01:49",
            },
        }
        order_status = session.post(url=input_database.url_buy_new, json=order_body)
        if order_status.status_code != 200:
            print("Error - Sell order")


request_uuid = uuid.uuid4()
timestamp = int(time.time())
buy_url = "http://13.125.130.41/position/stock/buy"
trans_url = "http://13.125.130.41/order/stock/orders-by-positions"
positions_url = "http://13.125.130.41/position/stock/positions"
headers = {"Content-Type": "application/x-www-form-urlencoded"}
# nateon_url = "https://teamroom.nate.com/api/webhook/cd40e595/BfPjv1fQ7S2ydAjECgdZ16B7" #tester
nateon_url = "https://teamroom.nate.com/api/webhook/cd40e595/DRspY3LMQS5YDgAzM6qGGcQX"

if __name__ == "__main__":
    revert_last_order(5729126999)
    # order_data = OrderData(107600, 10779751, 1500, 93900, '08-11')
    # order_data.sell_order()
    # get_transaction("10769061")
    # cumulative_pnl()
    # cumulative_pnl_list(input_database.account_ipo_futures)
    # trading_order = TradingFunction(640, 155313, "09-22")
    # trading_order.order_open(input_database.account_kjoh_test['accountId'], '383220')
