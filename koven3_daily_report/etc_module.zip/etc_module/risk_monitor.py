import requests
import input_database
import constants
from common_function import get_uuid_list_through_filter
from datetime import datetime, timedelta
import math
import os
import pandas as pd
import sys
from collections import defaultdict
from openpyxl import load_workbook
from apscheduler.schedulers.blocking import BlockingScheduler

# ==========================================
# 0. 설정 및 상수
# ==========================================
URL_BASKET_BY_POSITION = "http://43.202.36.216:15000/api/baskets/by_positions"
NATEON_WEBHOOK_URL = "https://teamroom.nate.com/api/webhook/cd40e595/LKRTfbg0DJ04N4C81fa2gMef"

# 펀드별 기본 설정
FUND_SETTINGS = {
    "PRELUDE": {"GROSS_LIMIT": 1.75, "NET_LIMIT_RANGE": 0.175, "LIQUIDITY_DAYS": 5},
    "MULTI_1": {"LIQUIDITY_DAYS": 5},
    "MULTI_2": {"LIQUIDITY_DAYS": 5},
    "IPO": {"LIQUIDITY_DAYS": 5},
    "KV": {"LIQUIDITY_DAYS": 5},
    "KV_2": {"LIQUIDITY_DAYS": 5},
    "KV_3": {"LIQUIDITY_DAYS": 5},
    "BLOCK": {"LIQUIDITY_DAYS": 5},
}

FUND_MAPPINGS = {
    "PRELUDE": {"filter": ["et-prelude-ls-trs", "et-prelude-block-trs", "et-prelude-event-trs", "et-prelude-ipo-trs",
                           "et-prelude-macro", "et-prelude-macro-trs"], "excel_name": "prelude"},
    "MULTI_1": {"filter": "multi-1", "excel_name": "multi_1"},
    "MULTI_2": {"filter": "multi-2", "excel_name": "multi_2"},
    "IPO": {"filter": "ipo-1", "excel_name": "ipo"},
    "KV": {"filter": "venture-1", "excel_name": "kv"},
    "KV_2": {"filter": "venture-2", "excel_name": "kv_2"},
    "KV_3": {"filter": "venture-3", "excel_name": "kv_3"},
    "BLOCK": {"filter": "ipo-block", "excel_name": "block"},
}

STRATEGY_FILTERS = {
    "IPO": [
        "ipo-1-ipo", "venture-1-ipo", "venture-2-ipo", "venture-3-ipo",
        "multi-1-ipo", "multi-2-ipo", "ipo-focus", "ipo-2", "ipo-alpha", "ipo-ent",
        "prelude-ipo", "ipo-block-ipo"
    ],
    "MACRO": ["macro-stock", "macro-futures", "prelude-macro"],
    "BLOCK": ["block-stock", "block-futures", "prelude-block", "ipo-block-block"],
    "EVENT": ["event-stock", "event-futures", "prelude-event"]
}


class RiskMonitor:
    def __init__(self, enable_alerts=True):
        self.headers = input_database.nateon_header
        self.alert_url = NATEON_WEBHOOK_URL
        self.today = datetime.today().strftime('%Y-%m-%d')
        self.enable_alerts = enable_alerts
        self.account_strategy_map = {}
        self.load_strategy_accounts()

    def load_strategy_accounts(self):
        print("   🔄 Loading Strategy Accounts...", end="")
        count = 0
        for strategy, filters in STRATEGY_FILTERS.items():
            for f_name in filters:
                try:
                    uuids = get_uuid_list_through_filter(f_name)
                    if uuids:
                        for uid in uuids:
                            self.account_strategy_map[str(uid)] = strategy
                            count += 1
                except:
                    continue
        print(f" Done. ({count} accounts mapped)")

    def post_json_safe(self, url, data):
        try:
            res = requests.post(url, json=data, verify=False)
            return res.json() if res.status_code == 200 else []
        except Exception as e:
            print(f"   [Error] POST {url}: {e}")
            return []

    def map_positions_to_baskets(self, positions):
        if not positions: return {}
        # [수정] positionId 추출 시 안전한 접근
        position_id_list = []
        for p in positions:
            # 상위 레벨에 positionId가 있거나, position 객체 안에 있거나 둘 다 확인
            pid = p.get('positionId') or p.get('position', {}).get('positionId')
            if pid:
                position_id_list.append({"position_id": str(pid)})

        if not position_id_list: return {}

        basket_data = self.post_json_safe(URL_BASKET_BY_POSITION, position_id_list)
        mapping = {}
        if basket_data and isinstance(basket_data, list):
            for basket in basket_data:
                b_name = basket.get('name', 'Unknown')
                b_id = basket.get('basket_id')
                for pid in basket.get('position_ids', []):
                    mapping[str(pid)] = {'name': b_name, 'basket_id': b_id}
        return mapping

    def get_realtime_data(self, fund_key):
        """
        [수정] beta_hedge.py와 동일하게 url_books_new (Batch API)를 사용하여
        Unwind된(죽은) 포지션까지 모두 불러옵니다.
        """
        fund_conf = FUND_MAPPINGS.get(fund_key)
        if not fund_conf: return 100_000_000_000, []

        pre_aum = self._get_pre_aum_from_hints(fund_conf['excel_name'])

        # 1. 해당 펀드의 모든 계좌 ID 수집
        filters = fund_conf['filter'] if isinstance(fund_conf['filter'], list) else [fund_conf['filter']]
        all_account_uuids = []
        for f_name in filters:
            try:
                uuids = get_uuid_list_through_filter(f_name)
                if uuids: all_account_uuids.extend(uuids)
            except:
                continue
        all_account_uuids = list(set(all_account_uuids))

        if not all_account_uuids:
            return pre_aum, []

        # 2. [변경] 일괄 조회 API (url_books_new) 사용 -> 죽은 포지션 포함
        input_data = {
            "requestHeader": {
                "protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                "requestId": input_database.request_uuid,
                "requestTimestamp": input_database.timestamp
            },
            "body": {
                "accountIds": all_account_uuids,
                "recordDate": input_database.today_middle_bar
            }
        }

        # API 호출 및 응답 파싱
        try:
            # response 구조: [{'accountId': '...', 'pages': [...]}, ...]
            book_strategy_pages = self.post_json_safe(input_database.url_books_new, input_data)

            # 응답이 'body' 키 안에 감싸져 있을 경우 처리 (post_json_safe 구현에 따라 다름)
            if isinstance(book_strategy_pages, dict) and 'body' in book_strategy_pages:
                book_strategy_pages = book_strategy_pages['body']

            all_positions = []
            delta_sum = 0

            if book_strategy_pages and isinstance(book_strategy_pages, list):
                for item in book_strategy_pages:
                    acc_id = item.get('accountId')
                    pages = item.get('pages', [])

                    for p in pages:
                        # 계좌 ID 주입 (나중에 전략 분류에 필요)
                        if acc_id and 'accountId' not in p:
                            p['accountId'] = str(acc_id)

                        all_positions.append(p)

                        # AUM 보정을 위한 PnL 합산
                        d2d = p.get('performance', {}).get('dayToDayPositionalPnl', {}).get('value', 0) or 0
                        intra = p.get('performance', {}).get('intraDayPnl', 0) or 0
                        delta_sum += (d2d + intra)

            realtime_aum = pre_aum + delta_sum
            return realtime_aum, all_positions

        except Exception as e:
            print(f"   [Error] Failed to fetch realtime data: {e}")
            return pre_aum, []

    def _get_pre_aum_from_hints(self, book_name):
        if book_name == "prelude":
            try:
                res = requests.post("http://43.202.36.216:13020/forex/fx-rates", json={
                    "requestHeader": {"protocolVersion": {"major": 1, "minor": 0, "revision": 0},
                                      "requestId": input_database.request_uuid,
                                      "requestTimestamp": input_database.timestamp},
                    "body": {"base": "USD", "quote": "KRW", "from": self.today, "to": self.today}
                }, verify=False).json()
                rate = res['body'][-1]['rate'] if res.get('body') else 1450
                return 10_000_000 * rate
            except:
                return 14500000000

        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            parent_dir = os.path.dirname(current_dir)
            target_dir = parent_dir
            target_filename = f"10304_일자별기준가격 조회_{input_database.today_constant}.xlsx"
            target_path = os.path.join(target_dir, target_filename)

            if not os.path.exists(target_path):
                print(f"   ⚠️ Today's file '{target_filename}' not found. Searching latest...")
                files = [f for f in os.listdir(target_dir) if f.startswith("10304_일자별기준가격 조회_") and f.endswith(".xlsx")]
                if not files: raise FileNotFoundError("No Excel files found.")
                files.sort(reverse=True)
                target_path = os.path.join(target_dir, files[0])
                print(f"   ✅ Using latest: {files[0]}")

            wb = load_workbook(target_path, data_only=True)
            sheet = wb["22204_기준가격표"]
            EXCEL_NAME_MAP = {
                "multi_1": "두나미스 멀티전략 일반사모(운)", "multi_2": "두나미스 멀티전략 일반사모투자신탁 2호",
                "ipo": "두나미스 공모주멀티 일반사모투자신탁", "kv": "두나미스 코스닥벤처 일반사모투자신탁",
                "kv_2": "두나미스 코스닥벤처 일반사모투자신탁 2호", "kv_3": "두나미스 코스닥벤처 일반사모투자신탁 3호",
                "block": "두나미스 블록딜공모주 일반사모투자신탁 1호(운용)"
            }
            target_name = EXCEL_NAME_MAP.get(book_name)
            if not target_name: raise ValueError("Mapping not found")

            for row in sheet.iter_rows(min_row=2, max_row=100, min_col=4, max_col=7):
                if row[1].value == target_name and isinstance(row[3].value, (int, float)):
                    return float(row[3].value)
            raise ValueError(f"Fund '{target_name}' not found in Excel.")
        except Exception as e:
            print(f"\n❌ [FATAL ERROR] AUM Load Failed: {e}")
            sys.exit(1)

    def get_avg_volume_20d(self, ticker):
        date_from = (datetime.now() - timedelta(days=40)).strftime('%Y-%m-%d')
        url = f"http://43.202.36.216:13020/candlestick/day-candles/{ticker}"
        try:
            res = requests.get(url, params={"ticker": ticker, "from": date_from, "to": self.today}).json()
            data = res.get('body', [])
            if not data: return 0
            df = pd.DataFrame(data)
            return int(df['volume'].rolling(window=20).mean().iloc[-1]) if not pd.isna(df['volume'].iloc[-1]) else 0
        except:
            return 0

    def classify_strategy(self, fund_key, basket_name, is_index_future, account_id):
        b_name_lower = basket_name.lower()

        if "block" in b_name_lower or "블록" in b_name_lower: return "BLOCK"
        if "event" in b_name_lower or "이벤트" in b_name_lower: return "EVENT"
        if "ipo" in b_name_lower: return "IPO"
        if "macro" in b_name_lower or "매크로" in b_name_lower: return "MACRO"

        if "(single)" in b_name_lower or "unclassified" in b_name_lower:
            if account_id and account_id in self.account_strategy_map:
                mapped_strategy = self.account_strategy_map[account_id]
                if is_index_future and mapped_strategy != "MACRO":
                    return "LS_NAKED"
                return mapped_strategy
            if is_index_future: return "LS_NAKED"
            if fund_key in ["KV", "KV_2", "KV_3", "IPO", "BLOCK"]:
                return "IPO"
            else:
                return "LS_NAKED"

        has_l = "l " in b_name_lower or " l" in b_name_lower
        has_s = "s " in b_name_lower or " s" in b_name_lower
        if has_l and has_s:
            return "LS_HEDGED"
        elif has_l or has_s:
            return "LS_NAKED"

        return "LS_HEDGED"

    def get_strategy_limits(self, strategy_type):
        limits = {
            "BLOCK": {"SIZE": 0.10, "SL_LEVEL": -0.10, "SL_WARNING": -0.07, "SL_TYPE": "ROI"},
            "IPO": {"SIZE": 0.02, "SL_LEVEL": -0.40, "SL_WARNING": -0.30, "SL_TYPE": "ROI"},
            "EVENT": {"SIZE": 0.10, "SL_LEVEL": None, "SL_WARNING": None, "SL_TYPE": None},
            "MACRO": {"SIZE": 0.10, "SL_LEVEL": None, "SL_WARNING": None, "SL_TYPE": None},
            "LS_HEDGED": {"SIZE": 0.03, "SL_LEVEL": -0.006, "SL_WARNING": -0.004, "SL_TYPE": "NAV"},
            "LS_NAKED": {"SIZE": 0.0075, "SL_LEVEL": -0.006, "SL_WARNING": -0.004, "SL_TYPE": "NAV"}
        }
        return limits.get(strategy_type, limits["LS_HEDGED"])

    def check_risks(self, fund_key):
        print(f"\n🔵 [{fund_key}] Risk Check ({datetime.now().strftime('%H:%M:%S')})")

        aum, positions = self.get_realtime_data(fund_key)
        fund_settings = FUND_SETTINGS.get(fund_key, {})
        if not fund_settings: return

        basket_mapping = self.map_positions_to_baskets(positions)

        stock_gross_sum = 0
        stock_net_sum = 0
        future_net_beta_sum = 0

        basket_stats = defaultdict(lambda: {
            'notional': 0, 'cumulative_pnl': 0, 'invested_capital': 0,
            'tickers': set(), 'is_index_future': False, 'account_ids': set()
        })
        index_futures_prefix = ('101', 'A05', 'A06')
        liquidity_alerts = []

        for p in positions:
            ticker = str(p.get('stockTicker', ''))
            name = p.get('stockName', 'Unknown')
            pos_data = p.get('position', {})

            # [중요] 죽은 포지션(Quantity 0)도 API가 내려주면 여기서 처리됨
            qty = abs(pos_data.get('quantity', 0))
            avg_price = pos_data.get('averagePrice', 0)
            multiplier = pos_data.get('multiplier', 1)

            # 투자 원금 계산 (죽은 포지션은 qty=0이므로 0이 됨 -> PnL만 남음)
            invested_cap = qty * avg_price * multiplier

            raw_id = p.get('positionId') or pos_data.get('positionId')
            pos_id = str(raw_id) if raw_id else None

            # get_realtime_data에서 강제 주입한 accountId 사용
            acc_id = str(p.get('accountId', ''))

            notional_val = p.get('positionNotionalValue', 0)
            beta_portion = p.get('betaHedgePortion', 0)
            is_future = (p.get('securityType') == "FUTURES")
            is_index_future = (is_future and ticker.startswith(index_futures_prefix))

            if is_future:
                future_net_beta_sum += beta_portion
            else:
                stock_gross_sum += abs(notional_val)
                stock_net_sum += notional_val

            if qty > 0 and ticker and not is_index_future:
                avg_vol = self.get_avg_volume_20d(ticker)
                if avg_vol > 0:
                    days_needed = math.ceil(qty / (avg_vol * 0.2))
                    if days_needed > fund_settings.get('LIQUIDITY_DAYS', 5):
                        liquidity_alerts.append(f"{name}({days_needed}d)")

            if pos_id and pos_id in basket_mapping:
                b_name = basket_mapping[pos_id].get('name', 'Unclassified')
            else:
                b_name = f"{name} (Single)"

            raw_pnl = p.get('performance', {}).get('cumulativePnl', 0)
            cumulative_pnl = raw_pnl.get('value', 0) if isinstance(raw_pnl, dict) else (raw_pnl or 0)

            # [핵심] 죽은 포지션의 PnL도 여기서 누적됨
            basket_stats[b_name]['notional'] += notional_val
            basket_stats[b_name]['cumulative_pnl'] += cumulative_pnl
            basket_stats[b_name]['invested_capital'] += invested_cap
            basket_stats[b_name]['tickers'].add(name)
            basket_stats[b_name]['account_ids'].add(acc_id)
            if is_index_future: basket_stats[b_name]['is_index_future'] = True

        gross_delta_sum = stock_gross_sum + abs(future_net_beta_sum)
        net_exposure_sum = stock_net_sum + future_net_beta_sum
        gross_r = gross_delta_sum / aum if aum else 0
        net_r = net_exposure_sum / aum if aum else 0

        print(f"   📊 Est. AUM    : {aum:,.0f} KRW")
        print(f"   📊 Gross Delta : {gross_delta_sum:,.0f} KRW ({gross_r * 100:.1f}%)")
        print(f"   📊 Net Exposure: {net_exposure_sum:,.0f} KRW ({net_r * 100:.1f}%)")
        print("   " + "-" * 30)

        alert_payloads = []
        gross_limit = fund_settings.get('GROSS_LIMIT')
        if gross_limit and gross_r > gross_limit:
            alert_payloads.append(f"🚨 Gross Exposure : {gross_r * 100:.1f}% (Limit {gross_limit * 100}%)")
        net_limit = fund_settings.get('NET_LIMIT_RANGE')
        if net_limit and abs(net_r) > net_limit:
            alert_payloads.append(f"🚨 Net Exposure   : {net_r * 100:.1f}% (Limit ±{net_limit * 100}%)")

        basket_size_alerts = []
        basket_stop_alerts = []
        b_keys = list(basket_stats.keys())
        print(f"   [Debug] Baskets: {b_keys[:5] + ['...'] if len(b_keys) > 5 else b_keys} (Total {len(b_keys)})")

        for b_name, stats in basket_stats.items():
            if b_name == 'Unclassified': pass
            is_index_future = stats.get('is_index_future', False)
            acc_id_sample = list(stats['account_ids'])[0] if stats['account_ids'] else None
            strategy_type = self.classify_strategy(fund_key, b_name, is_index_future, acc_id_sample)
            rules = self.get_strategy_limits(strategy_type)
            is_hedge_basket = "hedge" in b_name.lower()
            is_macro_basket = "macro" in b_name.lower() or "매크로" in b_name.lower() or strategy_type == "MACRO"
            is_single = "(Single)" in b_name

            if is_hedge_basket or b_name == 'Unclassified':
                pass
            elif is_index_future and not is_macro_basket:
                pass
            else:
                basket_net_abs = abs(stats['notional'])
                size_ratio = basket_net_abs / aum if aum else 0
                if rules['SIZE'] and size_ratio > rules['SIZE']:
                    basket_size_alerts.append(
                        f"{b_name} ({strategy_type}): {size_ratio * 100:.1f}% > {rules['SIZE'] * 100}%")

            if (is_single and is_index_future) or is_hedge_basket: continue

            sl_limit = rules['SL_LEVEL']
            sl_warning = rules.get('SL_WARNING')
            sl_type = rules['SL_TYPE']

            if sl_limit is not None:
                current_val = 0
                if sl_type == "ROI":
                    base_capital = stats['invested_capital']
                    # [주의] 일부만 남고 대부분 익절/손절하여 원금이 줄어들면,
                    # 남은 원금 대비 PnL(누적) 비율이 왜곡될 수 있음 (매우 커짐).
                    # 하지만 '잔존 금액 대비 손익' 관리 측면에서는 보수적인 접근이므로 유지함.
                    if base_capital > 0:
                        current_val = stats['cumulative_pnl'] / base_capital
                    elif abs(stats['notional']) > 0:
                        current_val = stats['cumulative_pnl'] / abs(stats['notional'])
                elif sl_type == "NAV":
                    current_val = stats['cumulative_pnl'] / aum if aum else 0

                if current_val < sl_limit:
                    basket_stop_alerts.append(
                        f"🔥 [손절] {b_name} ({strategy_type}): {current_val * 100:.2f}% (Limit {sl_limit * 100}%)")
                elif sl_warning is not None and current_val < sl_warning:
                    basket_stop_alerts.append(
                        f"⚠️ [주의] {b_name} ({strategy_type}): {current_val * 100:.2f}% (Warn {sl_warning * 100}%)")

        if basket_size_alerts:
            msg = f"🚨 Basket Size Limit:\n      " + "\n      ".join(basket_size_alerts)
            print(f"   {msg}")
            alert_payloads.append(msg)
        else:
            print("   ✅ Basket Size    : OK")

        if basket_stop_alerts:
            msg = f"📉 Basket Stop Loss:\n      " + "\n      ".join(basket_stop_alerts)
            print(f"   {msg}")
            alert_payloads.append(msg)
        else:
            print("   ✅ Basket StopLoss: Safe")

        if liquidity_alerts:
            msg = f"💧 Liquidity      : {', '.join(liquidity_alerts)}"
            print(f"   {msg}")
            alert_payloads.append(msg)
        else:
            print("   ✅ Liquidity      : OK")

        if alert_payloads: self.send_alert(fund_key, alert_payloads)

    def send_alert(self, fund_key, messages):
        content = f"[{fund_key} Risk Report]\n" + "\n".join(messages)
        if self.enable_alerts:
            try:
                requests.post(self.alert_url, headers=self.headers, data={"content": content}, verify=False)
            except:
                pass


def run_scheduled_checks():
    print(f"\n⏰ [Scheduler] Start: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    monitor = RiskMonitor(enable_alerts=False)
    fund_list = ["PRELUDE", "MULTI_1", "MULTI_2", "KV", "KV_2", "KV_3"]
    for fund in fund_list: monitor.check_risks(fund)
    print("\n✅ Check Completed\n" + "=" * 50)


if __name__ == "__main__":
    USE_SCHEDULER = False
    print(f"System Start... (Scheduler: {'ON' if USE_SCHEDULER else 'OFF'})")
    if USE_SCHEDULER:
        print("🚀 Risk Monitor Scheduler Started...")
        sched = BlockingScheduler()
        sched.add_job(run_scheduled_checks, 'cron', day_of_week='mon-fri', hour='9,11,13,15', minute='0')
        sched.add_job(run_scheduled_checks, 'cron', day_of_week='mon-fri', hour='16', minute='0')
        try:
            sched.start()
        except (KeyboardInterrupt, SystemExit):
            print("🛑 Scheduler Stopped")
    else:
        run_scheduled_checks()
        print("🏁 Execution Finished.")

"""
[리스크 모니터링 로직 요약]

1. 데이터 수집 (Data Fetching):
   - 'beta_hedge.py'와 동일한 Batch API (url_books_new)를 사용하여, 
     현재 잔고가 0인(Unwind된) 포지션의 누적 PnL 정보까지 모두 가져옵니다.

2. 바스켓 그룹핑 (Grouping):
   - API를 통해 포지션별 Basket ID를 매핑합니다.
   - 바스켓 정보가 없는 포지션은 '종목명 (Single)'을 이름으로 하여 '개별 바스켓'으로 취급합니다.

3. 전략 자동 분류 (Classify Strategy):
   - 순서: 바스켓 이름 확인 > **계좌 ID 매핑** > **L/S 여부 확인** > 펀드 기본값 Fallback
   - 바스켓 이름에 'Block', 'Event', 'IPO', 'Macro' 등이 포함되면 해당 전략으로 분류.
   - 개별 포지션(Single)은 **계좌(Account ID)**를 조회하여, 해당 계좌가 IPO/MACRO/BLOCK 계좌군에 속하는지 확인 후 분류.
   - 계좌 매핑이 안 된 경우: KV/IPO 펀드 -> IPO 전략, 그 외 -> Naked LS 전략.
   - 일반 바스켓(LS): 이름에 "L"과 "S"가 **둘 다** 있으면 Hedged, **하나만** 있으면 Naked로 분류.

4. 리스크 한도 (Risk Rules):
   ------------------------------------------------------------------------------------------
   전략 분류      | Size Limit (NAV%) | Stop Loss (기준) | Warning (주의) | SL 계산 방식
   ------------------------------------------------------------------------------------------
   BLOCK          | 10%               | -10%             | -7%            | ROI (원금 대비)
   IPO            | 2%                | -40%             | -30%           | ROI (원금 대비)
   EVENT / MACRO  | 10%               | None (체크 안함) | None           | -
   LS Hedged      | 3% (Mid-cap)      | -0.6% (Tier 2)   | -0.4%          | NAV (펀드 기여도)
   LS Naked       | 0.75% (Mid-cap)   | -0.6% (Tier 2)   | -0.4%          | NAV (펀드 기여도)
   ------------------------------------------------------------------------------------------

5. 예외 처리 (Exceptions):
   - 'Hedge' 바스켓: Size Check 및 Stop Loss Check에서 모두 제외.
   - 'Macro'가 아닌 인덱스 선물: Size Check 제외.
   - 'Single Index Future': Stop Loss Check 제외.
"""