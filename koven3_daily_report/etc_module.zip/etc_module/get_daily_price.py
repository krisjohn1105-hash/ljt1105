import pandas as pd

import input_database
import requests


def candle_stick(_ticker:str):
    stock_info = {
        "n": 20,
        "ticker": str(_ticker),
        # "before": input_database.today_middle_bar,
        "before": "2025-03-31",
    }
    candle_data = requests.get(
        url=input_database.url_candlestick + str(_ticker), params=stock_info
    ).json()["body"]
    candle_list = list()
    for _candle in candle_data:
        candle_dict = dict()
        candle_dict['ticker'] = _candle['ticker']
        candle_dict['date'] = _candle['startDateTime']
        candle_dict['price'] = _candle['closingPrice']
        candle_dict['vol'] = _candle['volume']
        candle_list.append(candle_dict)
    candle_frame = pd.DataFrame(candle_list)
    return candle_frame


def merge_list(_ticker_list:list):
    df_list = list()
    for _ticker in _ticker_list:
        _frame = candle_stick(_ticker)
        df_list.append(_frame)
    result_df = pd.concat(df_list, ignore_index=True)
    result_df.to_excel("price.xlsx", index=False)
    return result_df


ticker_list = [
    "A0566", "252670", "106W6", "010620", "011070", "007070", "066570", "095340",
    "003550", "018260", "097950", "337930", "079550", "035250", "278470", "005387",
    "004370", "298040", "353200", "207940", "241710", "298380", "006260", "103140",
    "448710", "036620", "196170", "031210", "042370", "141080", "128940", "417790",
    "000080", "001120", "417010", "000660", "012750", "440820", "439410", "457940",
    "455910", "078160", "484870", "1DWW4", "1C8W4", "1FWW4", "1CNW4", "123W4",
    "147W4", "1GYW4", "1GHW4", "1F5W4", "1F9W4", "139W4", "1DKW4", "373220",
    "1BMW4", "1CPW4", "1FVW4", "1C9W4", "10KW4", "1FRW4", "1GSW4", "1FFW4",
    "1FDW4", "1BHW4", "1EEW4", "1G6W4", "462860", "098070", "240550", "450950",
    "212710", "226590", "444530", "448900", "493790", "006370", "046210", "389030"
]

class GetDayCandles:
    def __init__(self, _ticker: str):
        self.ticker = _ticker

    def get_price(self):
        price_url = f"http://43.202.36.216:13020/candlestick/last-n-days/tickers/{self.ticker}"
        price_data = {
            "ticker": self.ticker,
            "before": input_database.today_middle_bar,
            "n": 20
        }
        try:
            price_list = requests.get(url=price_url, params=price_data, timeout=10).json().get('body', [])
            if not price_list:
                print(f"No data found for ticker: {self.ticker}. Skipping...")
                return pd.DataFrame()

            df = pd.DataFrame(price_list)
            filtered_df = df[
                ['startDateTime', 'openingPrice', 'highPrice', 'lowPrice', 'closingPrice', 'closingPrice', 'volume']]
            filtered_df.columns = ['date', 'open', 'high', 'low', 'close', 'adjclose', 'volume']

            filtered_df.loc[:, 'date'] = pd.to_datetime(filtered_df['date'])
            filtered_df = filtered_df.sort_values(by='date', ascending=True).reset_index(drop=True)
            filtered_df = filtered_df.set_index('date')
            return filtered_df
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data for {self.ticker}: {e}. Skipping...")
            return pd.DataFrame()

if __name__ == "__main__":
    merge_list(ticker_list)