import requests
import sys
import os

# Automation 프로젝트의 루트 경로를 시스템 패스에 추가하여 하위 모듈들을 import할 수 있게 함
project_root = r'C:\Users\오광준\PycharmProjects\Automation'
if project_root not in sys.path:
    sys.path.append(project_root)

import input_database
from common_function import get_uuid_full_string
from dailyUpdate.adv_fund_aum import sum_delta, main as get_aum_dict
from collections import defaultdict


def format_currency(val):
    # 1억(100,000,000) 단위로 나누어 반올림 후 소수점 없이 표기
    return f"{int(round(val / 100_000_000)):,d}"


def report_available_funds_and_gmv(long_collateral_ratio=0.90, short_excess_margin=0.50):
    """
    국내펀드들의 AUM, 소모자금, 가용자금 및 GMV를 계산하여 네이트온으로 보고하는 함수
    """
    # 북(펀드) 이름과 해당 펀드의 계좌를 필터링할 키워드 매핑
    book_filters = {
        'M1': 'multi-1',
        'M2': 'multi-2',
        'K1': 'venture-1',
        'K2': 'venture-2',
        'K3': 'venture-3',
        'BLO': 'ipo-block-',
        'PRE': 'et-prelude'
    }
    
    msg = "[가용자금 및 GMV 현황] (단위: 억원)\n"
    
    total_aum = 0
    total_gmv = 0
    total_cash = 0
    total_bp = 0
    
    table_data = []
    
    # adv_fund_aum의 main()을 실행하여 최종 가장 정확한 AUM dict를 가져옴
    try:
        aum_dict = get_aum_dict()
    except Exception as e:
        print(f"AUM을 가져오는데 실패했습니다: {e}")
        aum_dict = {}
    
    for display_name, filter_str in book_filters.items():
        # AUM 딕셔너리 매핑
        aum_key_map = {
            'M1': 'multi_1',
            'M2': 'multi_2',
            'K1': 'kv',
            'K2': 'kv_2',
            'K3': 'kv_3',
            'BLO': 'block'
        }
            
        if display_name == 'PRE':
            from common_function import get_krwusd
            try:
                # Prelude AUM은 1,000만 달러 고정 * 원달러 환율
                usd_rate = get_krwusd()
            except Exception as e:
                print(f"환율 조회 실패: {e}")
                usd_rate = 1400 # 기본 fallback
            current_aum = 10_000_000 * usd_rate
        else:
            param_book_name = aum_key_map.get(display_name)
            current_aum = aum_dict.get(param_book_name)
            
        if current_aum is None:
            print(f"[{display_name}] AUM 값이 None이거나 조회되지 않아 건너뜁니다.")
            continue
            
        # 해당 북에 속하는 계좌(alias)들 필터링
        matched_aliases = [item for item in input_database.account_list if filter_str in item]
        
        utilized_funds = 0
        gmv = 0
        futures_net = defaultdict(float)
        strategy_longs = defaultdict(float)
        strategy_shorts = defaultdict(float)
        
        for alias in matched_aliases:
            # 계좌의 이름(alias)을 통해 전략 분류 (stock 계좌일 경우 사용)
            strategy = 'unknown'
            if '-ls-' in alias or '-ipo-exist-' in alias:
                strategy = 'ls'
            elif '-event-' in alias:
                strategy = 'event'
            elif '-block-' in alias:
                strategy = 'block'
            elif '-macro-' in alias:
                strategy = 'macro'
            elif '-ipo-' in alias: # ipo-new, ipo-ipo 포함
                strategy = 'ipo'
            elif '-post-' in alias:
                strategy = 'post'
                
            try:
                # UUID 변환 후 포지션 데이터 조회
                uuid = get_uuid_full_string(alias)
                input_data = {"recordDate": input_database.today_middle_bar}
                res = requests.get(url=input_database.url_book_new + str(uuid), params=input_data).json()
                pages = res.get('body', {}).get('pages', [])
            except Exception as e:
                print(f"[{alias}] 포지션 조회 오류: {e}")
                continue
                
            for page in pages:
                sec_type = page.get('securityType', '')
                notional = page.get('positionNotionalValue', 0)
                
                # ------ 선물(Futures) 포지션 처리 ------
                ticker = page.get('ticker') or page.get('stockTicker', 'UNKNOWN')
                
                # Prelude 등에서 TRS 타입이더라도 종목코드 길이가 5자리인 경우 선물로 판단
                is_futures = (sec_type == 'FUTURES') or alias.endswith('-futures') or (ticker != 'UNKNOWN' and len(ticker) == 5)
                
                if is_futures:
                    # 선물은 전략 구분없이 티커 단위로 네팅 처리하기 위해 딕셔너리에 합산
                    futures_net[ticker] += notional
                
                # ------ 주식(Stock) 포지션 처리 ------
                else:
                    # GMV는 절대값 그대로 더함
                    gmv += abs(notional)
                    
                    # 락업 여부 확인 (IPO 전략 등에서 사용)
                    pos = page.get('position', {})
                    lock_till = pos.get('lockedUpTill')
                    is_locked = False
                    if lock_till and lock_till > input_database.today_middle_bar:
                        is_locked = True
                    
                    # 락업 해제된 IPO는 일반(LS/BLOCK/MACRO) 전략처럼 담보로 잡을 수 있음
                    can_use_as_collateral = strategy in ['ls', 'block', 'macro'] or (strategy == 'ipo' and not is_locked)
                    
                    if can_use_as_collateral:
                        # 롱/숏 원금을 각각 합산하여 추후에 일괄 계산 (담보 인정 비율 반영)
                        if notional > 0:
                            strategy_longs[strategy] += notional
                        else:
                            strategy_shorts[strategy] += abs(notional)
                            
                    elif strategy == 'ipo' and is_locked:
                        # 락업이 안 풀린 IPO는 롱/숏 모두 100% 소모 (일반적으로 롱)
                        utilized_funds += abs(notional)
                        
                    elif strategy in ['event']:
                        # 이벤트는 롱/숏 모두 100% 소모
                        utilized_funds += abs(notional)
                        
                    else:
                        # 그외 (명시되지 않은 post 등)는 일괄 100% 처리로 가정
                        utilized_funds += abs(notional)

        # 담보 로직 (LS, BLOCK, MACRO 전략 및 락업 해제된 IPO 별로 산정)
        for strat in ['ls', 'block', 'macro', 'ipo']:
            long_val = strategy_longs[strat]
            short_val = strategy_shorts[strat]
            
            # 롱 포지션은 원금 100% 소모자금으로 반영
            utilized_funds += long_val
            
            # 숏 포지션은 담보 인정액 (롱 포지션의 담보비율) 한도 내에서 무료.
            # 초과하는 분에 대해서만 초과 마진율 적용
            free_short_capacity = long_val * long_collateral_ratio
            if short_val > free_short_capacity:
                uncovered_short = short_val - free_short_capacity
                utilized_funds += uncovered_short * short_excess_margin
        
        # 모든 계좌의 순회가 끝난 후, 선물 네팅된 결과로 GMV 및 소모자금 반영
        for t, net_val in futures_net.items():
            # 네팅된 수량 기준 포지션 가치의 20%를 소모자금으로 산정
            gmv += abs(net_val)
            utilized_funds += abs(net_val) * 0.2
            
        # 가용자금 = AUM - 소모자금
        available_funds = current_aum - utilized_funds
        
        # 가용자금이 마이너스일 경우, AUM의 5%를 최소 가용자금으로 설정
        if available_funds < 0:
            available_funds = current_aum * 0.05
        
        total_aum += current_aum
        total_gmv += gmv
        total_cash += available_funds
        
        # 특정 펀드 제외하고 가용자금의 1.7배 레버리지 적용 (Buying Power)
        if display_name in ['BLO', 'PRE']:
            bp = available_funds
        else:
            bp = available_funds * 1.7
            
        total_bp += bp
        
        # 테이블 데이터 추가 (순서: AUM, GMV, Cash, BP, Fund)
        table_data.append([
            format_currency(current_aum),
            format_currency(gmv),
            format_currency(available_funds),
            format_currency(bp),
            display_name
        ])

    msg = "[가용자금 및 GMV 현황] (단위: 억원)\n"
    
    # 네이트온 웹훅이 연속된 공백을 1개로 압축해버리는 현상을 방지하기 위해 
    # 피규어 스페이스(숫자 크기와 동일한 공백, U+2007)와 제로위드스페이스(U+200B)를 교차 사용하여 패딩을 강제 유지합니다.
    def pad(text, width):
        val = str(text)
        spaces_needed = width - len(val)
        if spaces_needed > 0:
            return ("\u2007\u200b" * spaces_needed) + val
        return val
        
    # 헤더는 숫자 패딩(pad)을 쓰면 영어의 글꼴 장평(가변폭) 때문에 숫자의 오른쪽 끝선을 뚫고 우측으로 튀어나가 버립니다!
    # 따라서 일반 스페이스바로 시각적인 중앙/우측 정렬을 하드코딩합니다.
    header = "   AUM |    GMV       Cash | BP(Max)  Fund"
    divider = "-------------   ------------------  -----"
    
    msg += header + "\n" + divider + "\n"
    
    for row in table_data:
        # row: [aum, gmv, cash, bp, fund]
        col1 = f"{pad(row[0], 6)} | {pad(row[1], 6)}"
        col2 = f"{pad(row[2], 6)} | {pad(row[3], 7)}"
        col3 = f"{pad(row[4], 5)}"
        msg += f"{col1}   {col2}  {col3}\n"

    msg += divider + "\n"
    
    tot_col1 = f"{pad(format_currency(total_aum), 6)} | {pad(format_currency(total_gmv), 6)}"
    tot_col2 = f"{pad(format_currency(total_cash), 6)} | {pad(format_currency(total_bp), 7)}"
    tot_col3 = f"{pad('TOTAL', 5)}"
    msg += f"{tot_col1}   {tot_col2}  {tot_col3}\n"


    # 집계된 최종 문자열을 네이트온으로 전송
    send_to_nateon(msg)
    return msg

def send_to_nateon(msg):
    """
    구성된 메시지를 네이트온 지정된 웹훅으로 발송하는 함수
    """
    # 전송 대상 웹훅 URL (펀드 규제 의무비율 채널)
    nateon_url = input_database.nateon_communication
    headers = input_database.nateon_header
    parameter = {"content": msg}
    
    try:
        response = requests.post(url=nateon_url, headers=headers, data=parameter, timeout=5, verify=False)
        if response.status_code == 200:
            print("성공적으로 네이트온 메시지를 전송하였습니다.")
        else:
            print(f"네이트온 전송 실패. 응답 코드: {response.status_code}\n응답 내용: {response.text}")
    except Exception as e:
        print(f"네이트온 전송 중 오류 발생: {e}")


if __name__ == "__main__":
    # ==============================================================
    # [설정] LS, MACRO, BLOCK 전략의 롱 담보 비율 및 숏 초과 마진율 변경
    # ==============================================================
    # 🌟 원하시는 담보 비율을 여기서 직접 수정하시면 됩니다!
    LONG_COLLATERAL_RATIO = 0.90  # 롱 포지션 담보 인정 금액 (기본값: 70% -> 0.7)
    SHORT_EXCESS_MARGIN   = 0.50  # 담보 한도 초과 숏 분에 대한 마진율 (기본값: 70% -> 0.7)
    
    report_available_funds_and_gmv(
        long_collateral_ratio=LONG_COLLATERAL_RATIO, 
        short_excess_margin=SHORT_EXCESS_MARGIN
    )
