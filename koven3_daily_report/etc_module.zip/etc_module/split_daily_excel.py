import pandas as pd
import os


def save_daily_data_as_yyyymmdd_csv(input_csv_path, output_dir='daily_csv_files'):
    """
    단일 CSV 파일을 읽어 '보고의무발생일' 컬럼의 YYYYMMDD 형식 날짜를 기준으로
    각각 YYYYMMDD.csv 파일로 저장하는 함수.

    저장되는 파일 안의 '보고의무발생일' 컬럼도 YYYYMMDD 형식으로 표시됩니다.

    Args:
        input_csv_path (str): 읽어올 CSV 파일의 경로.
        output_dir (str): CSV 파일들을 저장할 디렉터리 이름. 기본값은 'daily_csv_files'.
    """
    try:
        # 1. CSV 파일 읽기
        # 컬럼을 처음부터 문자열로 읽도록 지정하여 날짜 형식 변환 문제를 방지합니다.
        df = pd.read_csv(input_csv_path, encoding='cp949', dtype={'보고의무발생일': str})
        print(f"'{input_csv_path}' 파일을 성공적으로 읽었습니다.")
    except FileNotFoundError:
        print(f"오류: '{input_csv_path}' 파일을 찾을 수 없습니다.")
        return
    except Exception as e:
        print(f"파일을 읽는 중 오류가 발생했습니다: {e}")
        print("파일 인코딩 문제일 수 있습니다. 'cp949' 대신 'utf-8'이나 'euc-kr'을 시도해 보세요.")
        return

    # 2. 날짜 컬럼 찾기
    date_col = '보고의무발생일'
    if date_col not in df.columns:
        print(f"오류: '{date_col}' 컬럼을 찾을 수 없습니다.")
        print(f"현재 CSV 파일의 컬럼: {df.columns.tolist()}")
        return

    # 3. 유효하지 않은 날짜가 있는 행은 제외
    # YYYYMMDD 형태가 아닌 데이터가 있을 경우를 대비해 결측치 제거
    df.dropna(subset=[date_col], inplace=True)

    # 4. CSV 파일들을 저장할 디렉터리 생성
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"'{output_dir}' 디렉터리를 생성했습니다.")

    # 5. 날짜별로 데이터 분리 및 저장
    # YYYYMMDD 형식의 날짜 문자열을 그대로 사용
    unique_dates = df[date_col].unique()

    if len(unique_dates) == 0:
        print("날짜 컬럼에 유효한 데이터가 없어 저장할 파일이 없습니다.")
        return

    print(f"총 {len(unique_dates)}개의 고유한 날짜를 발견했습니다. 저장을 시작합니다.")

    for date_str in unique_dates:
        # 해당 날짜의 데이터만 필터링
        daily_df = df[df[date_col] == date_str]

        # 파일명과 파일 내부 데이터 모두 YYYYMMDD 형식으로 사용
        file_name = f"{date_str}.csv"
        file_path = os.path.join(output_dir, file_name)

        daily_df.to_csv(file_path, index=False, encoding='utf-8-sig')
        print(f"-> {file_path} 파일이 저장되었습니다.")

    print("\n모든 작업이 완료되었습니다.")

if __name__ == "__main__":
    save_daily_data_as_yyyymmdd_csv("주식 공매도 포지션(공시대상)_20250401~20250430).csv")