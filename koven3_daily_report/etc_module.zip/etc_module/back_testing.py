# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import requests
import input_database
import openpyxl
from openpyxl.styles import Font, PatternFill
import os
import itertools


# --- 데이터 가져오기 클래스 ---
class GetDayCandles:
    def __init__(self, _ticker: str):
        self.ticker = _ticker

    def get_price(self):
        price_url = f"http://43.202.36.216:13020/candlestick/last-n-days/tickers/{self.ticker}"
        price_data = {
            "ticker": self.ticker,
            "before": input_database.today_middle_bar,
            "n": 300
        }
        try:
            price_list = requests.get(url=price_url, params=price_data, timeout=10).json().get('body', [])
            if not price_list:
                print(f"No data found for ticker: {self.ticker}. Skipping...")
                return pd.DataFrame()

            df = pd.DataFrame(price_list)
            filtered_df = df[
                ['startDateTime', 'openingPrice', 'highPrice', 'lowPrice', 'closingPrice', 'closingPrice', 'volume']]
            filtered_df.columns = ['date', 'open', 'high', 'low', 'close', 'adjclose', 'volume']

            filtered_df.loc[:, 'date'] = pd.to_datetime(filtered_df['date'])
            filtered_df = filtered_df.sort_values(by='date', ascending=True).reset_index(drop=True)
            filtered_df = filtered_df.set_index('date')
            return filtered_df
        except requests.exceptions.RequestException as e:
            print(f"Error fetching data for {self.ticker}: {e}. Skipping...")
            return pd.DataFrame()


# --- 롱숏 페어 분석 함수들 ---
def analyze_and_suggest_rebalancing(stock_A_prices, stock_B_prices, z_score_threshold=1.5):
    """
    Analyzes the price spread of a long-short pair and suggests rebalancing actions.
    """
    if len(stock_A_prices) < 90 or len(stock_B_prices) < 90:
        return {"error": "Insufficient data length (at least 90 days required)."}

    spread = np.log(stock_A_prices) - np.log(stock_B_prices)
    rolling_mean = spread.rolling(window=90).mean()
    rolling_std = spread.rolling(window=90).std()
    z_scores = (spread - rolling_mean) / rolling_std

    latest_z_score = z_scores.iloc[-1]

    suggestion = "The pair position does not require rebalancing."
    action = "Maintain"

    if latest_z_score > z_score_threshold:
        suggestion = "Z-Score has exceeded the threshold. Consider unwinding the long position and adding to the short position."
        action = "Unwind Long / Add Short"
    elif latest_z_score < -z_score_threshold:
        suggestion = "Z-Score has fallen below the threshold. Consider unwinding the short position and adding to the long position."
        action = "Unwind Short / Add Long"

    analysis_result = {
        "latest_z_score": latest_z_score,
        "z_score_threshold": z_score_threshold,
        "suggestion": suggestion,
        "action": action
    }

    return analysis_result


def backtest_strategy(stock_A_prices, stock_B_prices, z_score_entry=1.5, z_score_exit=0.5, stop_loss_threshold=-0.05,
                      bb_window=20, bb_std_dev=2):
    """
    백테스팅 전략 실행 함수.
    Z-Score와 볼린저밴드 지표를 사용하여 포지션을 동적으로 전환합니다.
    """
    if len(stock_A_prices) < 90 or len(stock_B_prices) < 90:
        return {"error": "Insufficient data length (at least 90 days required)."}, {}

    log_prices_A = np.log(stock_A_prices)
    log_prices_B = np.log(stock_B_prices)
    spread = log_prices_A - log_prices_B

    rolling_mean_z = spread.rolling(window=90).mean()
    rolling_std_z = spread.rolling(window=90).std()
    z_scores = (spread - rolling_mean_z) / rolling_std_z

    rolling_mean_bb = spread.rolling(window=bb_window).mean()
    rolling_std_bb = spread.rolling(window=bb_window).std()
    upper_band = rolling_mean_bb + (rolling_std_bb * bb_std_dev)
    lower_band = rolling_mean_bb - (rolling_std_bb * bb_std_dev)

    initial_capital = 10000
    portfolio_value = pd.Series(initial_capital, index=spread.index)
    in_position = False

    long_shares = 0
    short_shares = 0
    trade_returns = []
    trade_start_value = 0

    trade_logs = []
    position_entry_date = None

    daily_signals = pd.Series('Maintain', index=spread.index)

    start_index = max(90, bb_window)

    for i in range(start_index, len(spread)):
        # 포지션이 없을 경우, 포트폴리오 가치 유지
        if not in_position and i > 0:
            portfolio_value.iloc[i] = portfolio_value.iloc[i - 1]

        current_z = z_scores.iloc[i]
        current_spread = spread.iloc[i]
        current_upper_band = upper_band.iloc[i]
        current_lower_band = lower_band.iloc[i]

        if in_position:
            # PNL 계산
            long_pnl = long_shares * (stock_A_prices.iloc[i] - stock_A_prices.iloc[i - 1])
            short_pnl = short_shares * (stock_B_prices.iloc[i - 1] - stock_B_prices.iloc[i])
            portfolio_value.iloc[i] = portfolio_value.iloc[i - 1] + long_pnl + short_pnl

            trade_pnl_rate = (portfolio_value.iloc[i] - trade_start_value) / trade_start_value
            if trade_pnl_rate < stop_loss_threshold:
                in_position = False
                trade_returns.append(trade_pnl_rate)
                trade_logs.append({
                    "entry_date": position_entry_date,
                    "exit_date": spread.index[i],
                    "pnl": trade_pnl_rate,
                    "reason": "Stop Loss",
                    "signal_type": "Exit"
                })
                daily_signals.iloc[i] = "Exit"
                if i + 1 < len(portfolio_value):
                    portfolio_value.iloc[i + 1:] = portfolio_value.iloc[i]
                continue

        if not in_position:
            # Z > 0 (과매수) -> 스프레드가 과도하게 벌어짐
            # 이 경우, 스프레드가 좁아질 것으로 예상하고 A를 숏, B를 롱 포지션 진입
            if current_z > z_score_entry and current_spread > current_upper_band:
                in_position = True
                trade_start_value = portfolio_value.iloc[i]
                position_entry_date = spread.index[i]

                # A(stock_A_prices)를 숏, B(stock_B_prices)를 롱 포지션
                long_shares = (trade_start_value / 2) / stock_B_prices.iloc[i]
                short_shares = (trade_start_value / 2) / stock_A_prices.iloc[i]
                daily_signals.iloc[i] = "Entry Short A / Long B"

            # Z < 0 (과매도) -> 스프레드가 과도하게 좁아짐
            # 이 경우, 스프레드가 벌어질 것으로 예상하고 A를 롱, B를 숏 포지션 진입
            elif current_z < -z_score_entry and current_spread < current_lower_band:
                in_position = True
                trade_start_value = portfolio_value.iloc[i]
                position_entry_date = spread.index[i]

                # A(stock_A_prices)를 롱, B(stock_B_prices)를 숏 포지션
                long_shares = (trade_start_value / 2) / stock_A_prices.iloc[i]
                short_shares = (trade_start_value / 2) / stock_B_prices.iloc[i]
                daily_signals.iloc[i] = "Entry Long A / Short B"
        else:
            if abs(current_z) < z_score_exit:
                in_position = False
                trade_pnl_rate = (portfolio_value.iloc[i] - trade_start_value) / trade_start_value
                trade_returns.append(trade_pnl_rate)
                trade_logs.append({
                    "entry_date": position_entry_date,
                    "exit_date": spread.index[i],
                    "pnl": trade_pnl_rate,
                    "reason": "Z-Score Exit",
                    "signal_type": "Exit"
                })
                daily_signals.iloc[i] = "Exit"
                if i + 1 < len(portfolio_value):
                    portfolio_value.iloc[i + 1:] = portfolio_value.iloc[i]

    cumulative_return = (portfolio_value.iloc[-1] / initial_capital) - 1
    max_drawdown_value = (portfolio_value.cummax() - portfolio_value).max()
    max_drawdown = max_drawdown_value / portfolio_value.cummax().max() if portfolio_value.cummax().max() != 0 else 0
    total_days = (spread.index.max() - spread.index.min()).days
    annualized_return = pow(1 + cumulative_return, 365 / total_days) - 1 if total_days > 0 else 0
    daily_returns = portfolio_value.pct_change().dropna()
    sharpe_ratio = daily_returns.mean() / daily_returns.std() * np.sqrt(252) if daily_returns.std() != 0 else 0
    total_trades = len(trade_returns)
    winning_trades = len([r for r in trade_returns if r > 0])
    win_rate = winning_trades / total_trades if total_trades > 0 else 0
    total_profit = sum([r for r in trade_returns if r > 0])
    total_loss = abs(sum([r for r in trade_returns if r < 0]))
    profit_factor = total_profit / total_loss if total_loss > 0 else np.inf
    holding_periods = [(t['exit_date'] - t['entry_date']).days for t in trade_logs if
                       t['entry_date'] and t['exit_date']]
    avg_holding_period = np.mean(holding_periods) if holding_periods else 0

    backtest_results = {
        "total_return": cumulative_return,
        "max_drawdown": max_drawdown,
        "annualized_return": annualized_return,
        "sharpe_ratio": sharpe_ratio,
        "number_of_trades": total_trades,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "avg_holding_period": avg_holding_period,
        "trade_history": trade_logs,
    }

    daily_indicators = {
        'Z-Score': z_scores,
        'Bollinger Upper': upper_band,
        'Bollinger Lower': lower_band,
        'Spread': spread,
        'Signal': daily_signals
    }

    return backtest_results, daily_indicators


def generate_consolidated_report(all_pair_metrics, all_pair_indicators, filename='combined_backtest_report.xlsx'):
    """
    여러 페어의 백테스트 결과를 통합하여 하나의 엑셀 파일로 생성합니다.
    요약 시트와 각 페어의 상세 시트를 포함합니다.
    """
    print(f"\nGenerating consolidated Excel report: {filename}...")

    # 요약 보고서용 데이터프레임 생성
    summary_data = []
    for pair_name, metrics in all_pair_metrics.items():
        summary_row = {
            'Pair': pair_name,
            'Optimal Z-Entry': metrics['optimal_params']['z_score_entry'],
            'Optimal Z-Exit': metrics['optimal_params']['z_score_exit'],
            'Optimal BB-Win': metrics['optimal_params']['bb_window'],
            'Optimal BB-Std': metrics['optimal_params']['bb_std_dev'],
            'Total Return': metrics['total_return'],
            'Max Drawdown': metrics['max_drawdown'],
            'Annualized Return': metrics['annualized_return'],
            'Sharpe Ratio': metrics['sharpe_ratio'],
            'Number of Trades': metrics['number_of_trades'],
            'Win Rate': metrics['win_rate'],
            'Profit Factor': metrics['profit_factor'],
            'Avg Holding Period (Days)': metrics['avg_holding_period']
        }
        summary_data.append(summary_row)

    summary_df = pd.DataFrame(summary_data)

    # 엑셀 파일 생성 및 시트별 데이터 쓰기
    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        # 1. 요약 시트 작성
        summary_df.to_excel(writer, sheet_name='Summary', index=False)
        worksheet_summary = writer.sheets['Summary']

        # 요약 시트 열 너비 및 헤더 스타일 조정
        for column in worksheet_summary.columns:
            max_length = 0
            column_list = [cell for cell in column]
            for cell in column_list:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = (max_length + 2)
            worksheet_summary.column_dimensions[column_list[0].column_letter].width = adjusted_width

        header_font = Font(bold=True)
        for cell in worksheet_summary[1]:
            cell.font = header_font

        # 2. 각 페어의 상세 시트 작성
        for pair_name, indicators in all_pair_indicators.items():
            df = pd.DataFrame({
                f'Stock A ({pair_name.split("_")[0]}) Close': indicators['close_A'],
                f'Stock B ({pair_name.split("_")[1]}) Close': indicators['close_B'],
                'Z-Score': indicators['Z-Score'],
                'Bollinger Upper': indicators['Bollinger Upper'],
                'Bollinger Lower': indicators['Bollinger Lower'],
                'Spread': indicators['Spread'],
                'Trading Signal': indicators['Signal']
            })
            df = df.dropna(subset=['Trading Signal'])

            df.to_excel(writer, sheet_name=pair_name, index=True)
            worksheet = writer.sheets[pair_name]

            # 상세 시트 열 너비, 헤더 스타일, 신호 색상 조정
            for column in worksheet.columns:
                max_length = 0
                column_list = [cell for cell in column]
                for cell in column_list:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = (max_length + 2)
                worksheet.column_dimensions[column_list[0].column_letter].width = adjusted_width

            header_font = Font(bold=True)
            for cell in worksheet[1]:
                cell.font = header_font

            red_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
            green_fill = PatternFill(start_color="CCFFCC", end_color="CCFFCC", fill_type="solid")

            signal_col_index = df.columns.get_loc('Trading Signal') + 2
            for row in worksheet.iter_rows(min_row=2, max_row=len(df) + 1, min_col=signal_col_index,
                                           max_col=signal_col_index):
                cell = row[0]
                if "Entry" in str(cell.value):
                    cell.fill = green_fill
                elif "Exit" in str(cell.value):
                    cell.fill = red_fill

    print(f"Consolidated Excel report saved successfully to {os.path.abspath(filename)}")


# --- 메인 실행 로직 ---
def run_backtests():
    """
    여러 페어를 순회하며 최적 파라미터를 찾고, 각 페어에 대한 백테스트를 실행합니다.
    """
    # 분석할 롱숏 페어 리스트 (딕셔너리 형태로 관리)
    pairs_to_analyze = {
        '141080_298380': {'long': '141080', 'short': '298380'},  # 리가켐-에이비엘
        '068760_068270': {'long': '068760', 'short': '068270'},  # 셀트리온제약-셀트리온
        '000100_039200': {'long': '000100', 'short': '039200'},  # 유한양행-오스코텍
    }

    # 파라미터 탐색 범위 설정 (세분화 정도를 0.05로 줄임)
    z_entry_range = np.arange(1.0, 3.6, 0.05)
    z_exit_range = np.arange(0.1, 1.1, 0.05)
    stop_loss_range = np.arange(-0.10, -0.009, 0.05)
    bb_window_range = [10, 15, 20, 25, 30]
    bb_std_dev_range = np.arange(1.0, 3.1, 0.25)

    # 모든 파라미터 조합 생성
    param_combinations = list(itertools.product(
        z_entry_range, z_exit_range, stop_loss_range, bb_window_range, bb_std_dev_range
    ))

    all_pair_metrics = {}
    all_pair_indicators = {}

    print(f"Starting analysis for {len(pairs_to_analyze)} pairs.")
    print(f"Total combinations per pair for grid search: {len(param_combinations)}\n")

    for pair_name, tickers in pairs_to_analyze.items():
        long_ticker = tickers['long']
        short_ticker = tickers['short']

        print(f"--- Analyzing Pair: {long_ticker} (Long) vs {short_ticker} (Short) ---")

        long_prices_df = GetDayCandles(long_ticker).get_price()
        short_prices_df = GetDayCandles(short_ticker).get_price()

        if long_prices_df.empty or short_prices_df.empty:
            continue

        long_prices = long_prices_df['close']
        short_prices = short_prices_df['close']

        if len(long_prices) != len(short_prices):
            min_len = min(len(long_prices), len(short_prices))
            long_prices = long_prices.iloc[:min_len]
            short_prices = short_prices.iloc[:min_len]

        if len(long_prices) < 90:
            print("Insufficient data. Skipping this pair.")
            continue

        optimal_params = None
        best_score = -np.inf  # 최적화 기준을 '최고 점수'로 변경
        best_metrics = None
        best_indicators = None

        print(f"Starting grid search for {pair_name}...")
        for z_entry, z_exit, stop_loss, bb_win, bb_std in param_combinations:
            results, daily_indicators = backtest_strategy(
                stock_A_prices=long_prices,
                stock_B_prices=short_prices,
                z_score_entry=z_entry,
                z_score_exit=z_exit,
                stop_loss_threshold=stop_loss,
                bb_window=bb_win,
                bb_std_dev=bb_std
            )

            if "error" not in results and results['number_of_trades'] > 0:
                # 복합 지표 점수 계산 (샤프 비율에 더 큰 가중치 부여)
                current_score = (results['sharpe_ratio'] * 0.7) + (results['number_of_trades'] * 0.3)

                if current_score > best_score:
                    best_score = current_score
                    best_metrics = results
                    best_indicators = daily_indicators
                    optimal_params = {
                        "z_score_entry": z_entry,
                        "z_score_exit": z_exit,
                        "stop_loss_threshold": stop_loss,
                        "bb_window": bb_win,
                        "bb_std_dev": bb_std
                    }

        print("\n--- Optimal Parameters Found ---")
        if optimal_params:
            best_metrics['optimal_params'] = optimal_params
            all_pair_metrics[pair_name] = best_metrics

            # 일별 지표에 종가 데이터 추가
            best_indicators['close_A'] = long_prices
            best_indicators['close_B'] = short_prices
            all_pair_indicators[pair_name] = best_indicators

            print("Optimal Parameters:")
            for param, value in optimal_params.items():
                print(f"  - {param}: {value:.2f}")
            print("\nCorresponding Performance Metrics:")
            print(f"  - Total Return: {best_metrics['total_return']:.4f}")
            print(f"  - Number of Trades: {best_metrics['number_of_trades']}")
            print(f"  - Win Rate: {best_metrics['win_rate']:.4f}")
            print(f"  - Sharpe Ratio: {best_metrics['sharpe_ratio']:.4f}")
        else:
            print("No profitable parameter combination with trades found in the specified range.")

        print("\n" + "=" * 50 + "\n")

    # 모든 페어 분석이 끝난 후 통합 보고서 생성
    if all_pair_metrics:
        generate_consolidated_report(all_pair_metrics, all_pair_indicators)
    else:
        print("No valid pairs found for analysis. Exiting.")


if __name__ == "__main__":
    run_backtests()
