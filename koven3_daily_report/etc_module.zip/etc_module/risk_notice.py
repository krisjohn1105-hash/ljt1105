# risk_report.py
import pandas as pd
import requests
from sqlalchemy.testing import skip_if

import input_database
from pathlib import Path

# 외부 의존: 순환 import 피하려면 get_basket_table만 가볍게 가져오세요.
from etc_module.beta_hedge import get_basket_table, menual_check
from common_function import get_uuid_list_through_filter
from dailyUpdate.adv_fund_aum import sum_delta

# ──────────────────────────────────────────────────────────────────────────────
# 설정/상수
INDEX_PREFIXES = ("A01", "A05", "A06")  # 선물/인덱스 티커 제외
SKIP_TAGS = ()  # 제외할 바스켓 네이밍 키워드

# 포지션 한도(펀드 NAV 대비)
# Naked: S 0.5%, M 0.75%, L 1%
# Hedged-Long: S 2%, M 3%, L 4%
# Hedged-Short: S 1.5%, M 2.25%, L 3%
NAKED_LIMITS = {"S": 0.005, "M": 0.0075, "L": 0.01}
HEDGED_LONG = {"S": 0.02, "M": 0.03, "L": 0.04}
HEDGED_SHORT = {"S": 0.015, "M": 0.0225, "L": 0.03}

# 바스켓 언헤지드 불균형 한도(최소 시총 그룹 기준)
# S: 0.5%, M: 0.75%, L: 1%
UNHEDGED_DIFF_LIMIT = {"S": 0.005, "M": 0.0075, "L": 0.01}

# ──────────────────────────────────────────────────────────────────────────────
# 펀드 AccountID 세트 (펀드 식별용)
ipo_book = get_uuid_list_through_filter("ipo-1")
kv_book = get_uuid_list_through_filter("venture-1")
kv_2_book = get_uuid_list_through_filter("venture-2")
kv_3_book = get_uuid_list_through_filter("venture-3")
multi_1_book = get_uuid_list_through_filter("multi-1")
multi_2_book = get_uuid_list_through_filter("multi-2")
block_book = get_uuid_list_through_filter("ipo-block-")
prelude_book = get_uuid_list_through_filter("-prelude")  # 최신 스키마에 맞춤


def get_fund_key_by_account_id(account_id: str):
    if account_id in ipo_book:      return "ipo"
    if account_id in multi_1_book:  return "multi_1"
    if account_id in multi_2_book:  return "multi_2"
    if account_id in kv_book:       return "kv"
    if account_id in kv_2_book:     return "kv_2"
    if account_id in kv_3_book:     return "kv_3"
    if account_id in block_book:    return "block"
    if account_id in prelude_book:  return "prelude"
    return None


# ──────────────────────────────────────────────────────────────────────────────
# 유틸 함수

def get_account_id_with_position_id(position_id: int):
    try:
        res = requests.get(
            url=input_database.url_positions_info + str(position_id),
            params={"positionId": position_id}
        ).json()
        body = res['body'] if isinstance(res, dict) and 'body' in res else res
        return body.get('accountId')
    except Exception as e:
        # [디버깅] position_id 조회 실패 로그
        print(f"⚠️ [Error] get_account_id Fail (PID: {position_id}): {e}")
        return None


def is_index_ticker(ticker: str) -> bool:
    return len(ticker) == 5 and ticker[:3] in INDEX_PREFIXES


def classify_basket(position_ids, position_info_dict) -> str:
    """인덱스 제외하고 롱/숏 둘 다 존재하면 HEDGED, 아니면 NAKED"""
    longs = shorts = 0
    for pid in position_ids:
        info = position_info_dict.get(pid)
        if not info:
            continue
        ticker = info.get("stockTicker", "")
        if is_index_ticker(ticker):
            continue
        q = info['position']['quantity']
        if q > 0:
            longs += 1
        elif q < 0:
            shorts += 1
    return "HEDGED" if (longs > 0 and shorts > 0) else "NAKED"


def get_market_cap(ticker: str) -> float:
    """티커가 선물이면 언더라이잉 티커를 따라가 시총 계산"""
    try:
        sd = requests.get(input_database.url_stock_ticker + str(ticker),
                          params={"ticker": ticker}).json()['body']
        if sd.get('securityType') == "FUTURES":
            ud = requests.get(input_database.url_underlying_ticker + str(ticker),
                              params={"ticker": ticker}).json()['body']
            return get_market_cap(ud['ticker'])
        return float(sd['lastPrice']) * float(sd['outstandingShares'])
    except Exception:
        return 0.0


def get_cap_group(cap: float) -> str:
    if cap < 1e12:   return "S"
    if cap < 5e12:   return "M"
    return "L"


def per_position_limit(cap_group: str, direction: str, basket_type: str) -> float:
    if basket_type == "NAKED":
        return NAKED_LIMITS[cap_group]
    # HEDGED
    return HEDGED_LONG[cap_group] if direction == "LONG" else HEDGED_SHORT[cap_group]


def build_fund_nav_map() -> dict:
    """펀드 키 -> NAV (sum_delta 사용)"""
    nav_map = {}
    for key in ["ipo", "multi_1", "multi_2", "kv", "kv_2", "kv_3", "block", "prelude"]:
        try:
            nav = sum_delta(key)
            if nav is not None:
                nav_map[key] = float(nav)
        except Exception as e:
            # [디버깅] NAV 로드 실패 필수 출력
            print(f"❌ [NAV Error] Key: {key}, Msg: {e}")
            pass
    return nav_map


def basket_to_fund_key(basket, position_info_dict):
    """바스켓의 첫 유효 포지션으로 accountId 조회 -> 펀드 키"""
    for pid in basket.get('position_ids', []):
        acct = get_account_id_with_position_id(pid)
        # [디버깅] pid별 accountId 조회 결과 (로그가 너무 많으면 주석 처리)
        print(f"  - PID {pid} -> Account: {acct}")
        if acct:
            fk = get_fund_key_by_account_id(acct)
            if fk:
                return fk
    return None


# ──────────────────────────────────────────────────────────────────────────────
# 핵심 분석

def analyze_risk_single_sheet(position_info_dict, basket_table, out_xlsx="risk_report_요약.xlsx"):
    """
    델타 기준 단일 시트 리포트.
    - POSITION: 포지션 단위 위반 (PositionDeltaNotional / NAV > per-position limit)
    - BASKET(hedged): 언헤지드 갭 위반 (|sum_long_delta - sum_short_delta| / NAV > limit(가중평균 시가총액 기준))
    - BASKET(hedged): 스탑로스 위반 (바스켓 내 누적손익 합(손실크기) / NAV > 0.6%)
    """
    STOPLOSS_LIMIT = 0.003  # 0.6%
    fund_nav_map = build_fund_nav_map()
    rows = []

    for b in basket_table:
        name = b.get('name', '')
        pids = b.get('position_ids', [])

        # [디버깅] 바스켓 루프 시작
        print(f"▶️ Analyzing Basket: {name} (PIDs: {len(pids)})")

        lname = name.lower()
        if any(tag in lname for tag in SKIP_TAGS):
            # [디버깅] SKIP_TAGS 필터링 로그
            matched = [tag for tag in SKIP_TAGS if tag in lname]
            print(f"   [SKIP] Matched tags: {matched}")
            continue

        fund_key = basket_to_fund_key(b, position_info_dict)

        # [디버깅] fund_key 판별 핵심 로그
        if not fund_key or fund_key not in fund_nav_map:
            reason = "Not Fund Key" if not fund_key else f"Key Missing in NAV Map (Found: {fund_key})"
            print(f"   [SKIP] {reason} | Available NAV Keys: {list(fund_nav_map.keys())}")
            continue

        nav = fund_nav_map[fund_key]
        if nav <= 0:
            # [디버깅] NAV 0 이하 스킵
            print(f"   [SKIP] Fund: {fund_key}, NAV is Zero or Negative: {nav}")
            continue

        basket_type = classify_basket(b['position_ids'], position_info_dict)

        # 롱/숏 합산 (델타 기준)
        long_delta_sum = 0.0
        short_delta_sum = 0.0

        # 바스켓 가중평균 시총 계산용
        cap_weight_sum = 0.0
        cap_value_weighted = 0.0

        for pid in b['position_ids']:
            is_dead = False
            info = position_info_dict.get(pid)
            if not info:
                # 죽은 포지션 API로 다시 조회
                try:
                    res = requests.get(input_database.url_positions_info + str(pid),
                                       params={"positionId": pid}).json()
                    info = res['body'] if isinstance(res, dict) and 'body' in res else res
                    is_dead = True
                except Exception:
                    info = None

            if not info:
                continue

            # 구조 파싱 (book API는 nested, position info API는 flat)
            if 'stockTicker' in info:
                ticker = info.get("stockTicker", "")
            else:
                ticker = info.get("ticker", "")

            is_idx = is_index_ticker(ticker)

            if 'position' in info:
                q = info['position']['quantity']
                mult = info['position']['multiplier']
            else:
                q = info.get('quantity', 0)
                mult = info.get('multiplier', 1)

            if q == 0:
                is_dead = True
                direction = info.get("direction", "N/A")
                d_notional = 0.0
            else:
                direction = "LONG" if q > 0 else "SHORT"
                d_notional = abs(q * mult * info.get('lastPrice', 0))

            # 죽은 포지션도 엑셀 row에 출력하여 "나오게" 함 (is_dead 활용)
            if not is_idx or is_dead:
                cap = get_market_cap(ticker) if not is_idx else 0.0
                cap_group = get_cap_group(cap) if not is_idx else "-"

                limit = per_position_limit(cap_group, direction, basket_type) if not is_idx and not is_dead else 0.0
                ratio = d_notional / nav if nav and not is_dead else 0.0
                violation = ratio > limit if limit > 0 else False
                excess_ratio = max(ratio - limit, 0.0)

                rows.append({
                    "Level": "POSITION",
                    "Basket": name,
                    "BasketType": basket_type,
                    "Fund": fund_key,
                    "Ticker": ticker,
                    "Direction": direction + ("(DEAD)" if is_dead else ""),
                    "CapGroup": cap_group,
                    "PositionDeltaNotional": d_notional,
                    "UnhedgedDeltaGap": 0.0,
                    "BasketLossAmount": 0.0,
                    "PositionRatio": ratio,
                    "PositionLimit": limit,
                    "UnhedgedRatio": 0.0,
                    "UnhedgedLimit": 0.0,
                    "StopLossRatio": 0.0,
                    "StopLossLimit": 0.0,
                    "ExcessRatio": excess_ratio,
                    "Violation": violation,
                    "Reason": "per_position_limit" if violation else ""
                })

                if not is_dead:
                    # 가중평균 시총 대상에는 살아있는 주식만 반영
                    if not is_idx:
                        cap_weight_sum += d_notional
                        cap_value_weighted += cap * d_notional

            # 롱/숏 합산 (인덱스 포함, 델타 기준)
            if not is_dead:
                if direction == "LONG":
                    long_delta_sum += d_notional
                else:
                    short_delta_sum += d_notional

        # ─── BASKET 단위 체크 (단일 행으로 통합) ───

        # 1. 언헤지드 갭 (HEDGED 바스켓만 해당)
        diff_delta = 0.0
        diff_ratio = 0.0
        diff_limit = 0.0
        diff_violate = False
        diff_excess = 0.0
        weighted_group = "N/A"

        if basket_type == "HEDGED":
            # 가중평균 시총 → 시총 그룹으로 환산
            if cap_weight_sum > 0:
                weighted_cap = cap_value_weighted / cap_weight_sum
                weighted_group = get_cap_group(weighted_cap)
            else:
                weighted_group = "M"  # fallback

            # 언헤지드 갭
            diff_delta = abs(long_delta_sum - short_delta_sum)
            diff_ratio = diff_delta / nav if nav else 0.0
            diff_limit = UNHEDGED_DIFF_LIMIT[weighted_group]
            diff_violate = diff_ratio > diff_limit
            diff_excess = max(diff_ratio - diff_limit, 0.0)

        # 2. 스탑로스 (바스켓 누적손익 합 계산)
        # NAKED, HEDGED 관계없이 모든 바스켓에 적용되도록 구조 개선
        basket_cml_sum = 0.0
        for pid in b['position_ids']:
            info2 = position_info_dict.get(pid)
            if not info2:
                # API로 직접 조회: position_ids에는 있으나 get_basket_table()에서
                # 누락된(quantity == 0 등) 종료된 포지션 정보를 누락 없이 합산
                try:
                    res = requests.get(input_database.url_positions_info + str(pid),
                                       params={"positionId": pid}).json()
                    info2 = res['body'] if isinstance(res, dict) and 'body' in res else res
                except Exception:
                    info2 = None

            if not info2:
                continue

            try:
                if 'performance' in info2:
                    cml_val = float(info2.get("performance", {}).get("cumulativePnl", {}).get("value", 0.0))
                else:
                    cml_val = float(info2.get("realizedPnl", 0.0)) + float(info2.get("unrealizedPnl", 0.0))
            except Exception:
                cml_val = 0.0
            basket_cml_sum += cml_val

        loss_amount = -basket_cml_sum if basket_cml_sum < 0 else 0.0
        stop_ratio = loss_amount / nav if nav else 0.0
        stop_violate = stop_ratio > STOPLOSS_LIMIT
        stop_excess = max(stop_ratio - STOPLOSS_LIMIT, 0.0)

        # 3. 엑셀에 출력될 단일 BASKET 결과 반영 (두 줄 출력을 하나로 통합)
        reasons = []
        if diff_violate: reasons.append("unhedged_diff_limit")
        if stop_violate: reasons.append("basket_stoploss")

        rows.append({
            "Level": "BASKET",
            "Basket": name,
            "BasketType": basket_type,
            "Fund": fund_key,
            "Ticker": "-",
            "Direction": "N/A",
            "CapGroup": weighted_group,
            "PositionDeltaNotional": 0.0,
            "UnhedgedDeltaGap": diff_delta,
            "BasketLossAmount": loss_amount,
            "PositionRatio": 0.0,
            "PositionLimit": 0.0,
            "UnhedgedRatio": diff_ratio,
            "UnhedgedLimit": diff_limit,
            "StopLossRatio": stop_ratio,
            "StopLossLimit": STOPLOSS_LIMIT,
            "ExcessRatio": max(diff_excess, stop_excess),
            "Violation": diff_violate or stop_violate,
            "Reason": ", ".join(reasons)
        })

    # 엑셀 출력
    df = pd.DataFrame(rows)
    col_order = [
        "Level", "Basket", "BasketType", "Fund", "Ticker", "Direction", "CapGroup",
        "PositionDeltaNotional", "UnhedgedDeltaGap", "BasketLossAmount",
        "PositionRatio", "PositionLimit",
        "UnhedgedRatio", "UnhedgedLimit",
        "StopLossRatio", "StopLossLimit",
        "ExcessRatio", "Violation", "Reason"
    ]
    df = df[col_order]
    df.sort_values(["Level", "Basket", "Violation", "ExcessRatio"], ascending=[True, True, False, False], inplace=True)

    out_path = Path(out_xlsx).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(str(out_path), engine="xlsxwriter") as writer:
        df.to_excel(writer, index=False, sheet_name="Risk")
        wb = writer.book
        ws = writer.sheets["Risk"]
        money_fmt = wb.add_format({"num_format": "#,##0"})
        pct_fmt = wb.add_format({"num_format": "0.00%"})
        header = {c: i for i, c in enumerate(col_order)}

        for c in ("PositionDeltaNotional", "UnhedgedDeltaGap", "BasketLossAmount"):
            ws.set_column(header[c], header[c], 16, money_fmt)

        for c in ("PositionRatio", "PositionLimit", "UnhedgedRatio", "UnhedgedLimit", "StopLossRatio", "StopLossLimit",
                  "ExcessRatio"):
            ws.set_column(header[c], header[c], 12, pct_fmt)

        ws.set_column(header["Basket"], header["Basket"], 30)
        ws.set_column(header["Reason"], header["Reason"], 22)

    print(f"✅ Risk report saved to {out_path}")
    print("Automation/automate 경로의 'risk_report_요약.xlsx' 엑셀 파일을 확인하세요.")


def weighted_cap_group_for_basket(position_ids, position_info_dict):
    """
    바스켓 내 비(非)인덱스 포지션들의 '델타 노셔널 비중'을 가중치로 사용해
    시가총액 가중평균을 구하고, 그 평균 시총으로 캡그룹(S/M/L)을 반환.
    """
    total_delta_notional = 0.0
    weighted_cap_sum = 0.0

    for pid in position_ids:
        info = position_info_dict.get(pid)
        if not info:
            continue
        ticker = info.get("stockTicker", "")
        if is_index_ticker(ticker):
            continue

        q = info['position']['quantity']
        if q == 0:
            continue

        # 델타 노셔널(절댓값)
        d_notional = abs(q * info['position']['multiplier'] * info['lastPrice'])
        if d_notional <= 0:
            continue

        cap = get_market_cap(ticker)
        total_delta_notional += d_notional
        weighted_cap_sum += d_notional * cap

    if total_delta_notional <= 0:
        # 포지션이 없거나 모두 0이면 보수적으로 L로 처리(혹은 기본값)
        return "L"

    avg_cap = weighted_cap_sum / total_delta_notional
    return get_cap_group(avg_cap)


STOPLOSS_LIMIT = 0.003  # 0.6%

# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("🔎 Running risk analysis with Debug Logs...")

    # [디버깅] target_funds 구성 직후 확인
    target_funds = multi_1_book + prelude_book
    print(f"📊 Target Funds Configured: Total {len(target_funds)} accounts.")
    print(f"   - Prelude Book count: {len(prelude_book)}")
    if prelude_book:
        print(f"   - Prelude Sample IDs: {prelude_book[:3]}")

    position_info_dict, basket_table = get_basket_table(target_list=target_funds)

    fixed_out_xlsx = Path(__file__).resolve().parents[1] / "automate" / "risk_report_요약.xlsx"
    analyze_risk_single_sheet(position_info_dict, basket_table, out_xlsx=str(fixed_out_xlsx))