import numpy as np
import requests

import constants
import input_database
import uuid
import time
import pandas as pd
from etc_module.function import get_listing_date


def chg_90d_beta(ticker, date=None):
    _index_list = ["106", "101", "105"]
    beta_dict = dict()
    if len(ticker) == 5 and ticker[:3] not in _index_list:
        ticker = get_underlying_asset_item_code(ticker)
    _beta_data = {
        "ticker": ticker,
        "n": 90,
        # "recordDate": f"{input_database.today_middle_bar}",
        "recordDate": f"{date}",
    }
    chg_90d_beta_data = requests.get(
        url=input_database.url_market_beta_new, params=_beta_data
    ).json()
    beta_data = chg_90d_beta_data["body"]
    beta = 1
    for _page in beta_data:
        beta_dict[f"{_page['market']}"] = abs(_page["correlation"])
    if round(abs(beta_dict["KOSDAQ"] - beta_dict["KOSPI"]), 2) <= 0.1:
        market = str(find_market(ticker))
    else:
        market = max(beta_dict, key=beta_dict.get)
        if abs(beta_dict[f'{market}']) <= 0.2:
            market = str(find_market(ticker))
    menual_check = {
        "A0666": {
            'beta': 1,
            'market': 'KOSDAQ'
        },
        "A0566": {
            'beta': 1,
            'market': 'KOSPI'
        },
        "298380": { #에이비엘바이오
            "beta" : 1.2,
            'market': 'KOSDAQ'
        },
        "000500": { #가온전선
            "beta": 1.0,
            'market': 'KOSPI'
        },
        "103590": { #일진전기
            "beta": 1.0,
            'market': 'KOSPI'
        },
        "267260": { # HD현대일렉
            "beta": 1.5,
            'market': 'KOSPI'
        },
        "298040": { # 효성중공업
            "beta": 1.5,
            'market': 'KOSPI'
        },
        "068270": { #셀트리온
            "beta": 0.85,
            "market": "KOSDAQ"
        },
        "068760": { #셀트리온제약
            "beta": 0.85,
            "market": "KOSDAQ"
        },
        "009420": { #한올바이오파마
            "beta": 1,
            "market": "KOSDAQ"
        },
        "008930": { #한미사이언스
            "beta": 0.8,
            "market": "KOSPI"
        },
        "128940": { # 한미약품
            "beta": 0.8,
            "market": "KOSPI"
        },
        "483650": {
            "beta": 0.6,
            "market": "KOSDAQ"
        },
    }
    kq_check = ['018250', "128940", "008930"]
    quarterly_busy = 62
    for _page in beta_data:
        if _page["market"] == market and _page:
            try:
                date_difference = np.busday_count(
                    begindates=get_listing_date(ticker),
                    enddates=input_database.today_middle_bar,
                )
                if 0 < date_difference < quarterly_busy:
                    beta = _page["beta"] * (date_difference / quarterly_busy)
                elif date_difference <= 0:
                    beta = 0
                else:
                    beta = _page['beta']
            except ValueError:
                beta = _page['beta']
            except TypeError:
                print("TypeError:" + str(_page['stockName']))
                beta = _page['beta']
    if ticker in menual_check.keys():
        beta = menual_check[f'{ticker}']['beta']
        market = menual_check[f'{ticker}']['market']
    elif ticker in kq_check:
        market = "KOSDAQ"
        for _page in beta_data:
            if _page['market'] == "KOSDAQ":
                beta = _page['beta']
                return market, beta
    return market, beta


def get_underlying_asset_item_code(futures_item_code):
    df = pd.read_excel(constants.LONGSHORT_DIR + "/개별주식선물코드.xlsx")
    df['기초자산_종목코드'] = (
        df['기초자산_종목코드']
            .fillna('')
            .astype(str)
            .str.split('.').str[0]  # Remove any decimal point introduced by floats
            .str.zfill(6)  # Pad with zeros to 6 digits
    )
    matching_row = df[df['선물종목코드'].astype(str).str[:3] == futures_item_code[:3]]

    if not matching_row.empty:
        _underlying_ticker = str(matching_row['기초자산_종목코드'].tolist()[0])
        if len(_underlying_ticker) < 6:
            while len(_underlying_ticker) < 6:
                _underlying_ticker = "0" + _underlying_ticker
                if len(_underlying_ticker) == 6:
                    return _underlying_ticker
        return _underlying_ticker
    else:
        return futures_item_code


def standard_beta(_ticker):
    _beta_input = {
        "ticker": _ticker,
        "n": 90,
        "recordDate": f"{input_database.yesterday_middle_bar}",
    }
    yesterday_swagger = requests.get(
        url=input_database.url_market_beta_new, params=_beta_input
    ).json()
    yesterday_beta = dict()
    beta_data = yesterday_swagger["body"]
    for _page in beta_data:
        yesterday_beta[f"{_page['market']}"] = abs(_page["correlation"])
    yesterday_market = max(yesterday_beta, key=yesterday_beta.get)
    yesterday_beta = yesterday_beta[f'{yesterday_market}']

    return yesterday_market, yesterday_beta,


def find_market(_ticker):
    _info_input = {
        "requestHeader": {
            "protocolVersion": {
                "major": 1,
                "minor": 0,
                "revision": 0
            },
            "requestId": f'{request_uuid}',
            "requestTimestamp": timestamp
        },
        "body": {
            "tickers": [
                _ticker
            ]
        }
    }
    stock_info = requests.post(
        url=input_database.url_stock_ticker, json=_info_input
    ).json()['body']
    for _stocks in stock_info:
        find_market_data = _stocks['market']
        return find_market_data


request_uuid = uuid.uuid4()
timestamp = int(time.time())


def get_correlation_stock(_ticker):
    _beta_input = {
        "baseTicker": _ticker,
        "top": 200,
        "n": 90,
        "recordDate": f"{input_database.yesterday_middle_bar}",
    }
    correlation_stock_list = requests.get(
            url=input_database.url_relativity, params=_beta_input
    ).json()['body']
    asd = pd.DataFrame(correlation_stock_list)
    asd.to_excel("x.xlsx")


if __name__ == "__main__":
    print(chg_90d_beta('060250'))
    # print(get_underlying_asset_item_code('1FAVA'))
    # get_correlation_stock('042660')
