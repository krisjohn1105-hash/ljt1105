import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime as dt

import input_database

brokerage = {'하나금융투자': 'Hana', 'NH투자증권': 'NH', '미래에셋증권': 'Mirae', '대신증권': 'Daishin', '한국투자증권': 'KIS', 'KB증권': 'KB',
             '삼성증권': 'Samsung', 'IBK투자증권': 'IBK', '신한금융투자': 'Shinhan', '한화투자증권': 'Hanwha',
             '신영증권': 'Shinyoung', '현대차증권': 'HMCIB'}  #### Brokerage Dictionary to be fixed later
current_date = dt.date.today()  # For seeing if dates are updated


def book_build_start(url):
    page = requests.get(url)
    soup = BeautifulSoup(page.text, 'lxml')
    data = soup.find('table', summary="수요예측일정")
    headers = []
    for i in data.find_all('th'):
        title = i.text.strip()
        headers.append(title)
    rows = []
    df_bookbuild = pd.DataFrame(columns=headers)
    for j in data.find_all('tr')[2:]:
        rdata = j.find_all('td')
        row = [tr.text.strip() for tr in rdata]
        rows.append(row)
    for k in range(len(rows)):
        try:
            df_bookbuild.loc[k] = rows[k]
        except:
            print('Last row is an empty row')
    df_bookbuild = df_bookbuild[['종목명', '수요예측일', '주간사']]
    df_bookbuild['종목명'] = df_bookbuild['종목명'].apply(lambda x: x.split('(')[0])
    df_bookbuild.rename(columns={'수요예측일': '날짜'}, inplace=True)
    df_bookbuild['날짜'] = df_bookbuild['날짜'].apply(lambda x: x[0:10])
    df_bookbuild['주간사'] = df_bookbuild['주간사'].apply(lambda x: x.split(','))
    df_bookbuild['주간사'] = df_bookbuild['주간사'].apply(lambda x: x[0])  # Formatting
    df_bookbuild['Type'] = 'BB-시작'
    df_bookbuild['날짜'] = df_bookbuild['날짜'].apply(lambda x: x.replace('.', '-'))
    df_bookbuild = df_bookbuild[['종목명', '날짜', 'Type', '주간사']]
    return df_bookbuild


def bbs_merge():
    url_bookbuild_first = "http://www.38.co.kr/html/fund/index.htm?o=r&page=1"
    url_bookbuild_second = "http://www.38.co.kr/html/fund/index.htm?o=r&page=2"
    first_bbs = book_build_start(url_bookbuild_first)
    second_bbs = book_build_start(url_bookbuild_second)
    sum_bbs = pd.concat([first_bbs, second_bbs])
    return sum_bbs


def book_build_end(url):
    page = requests.get(url)
    soup = BeautifulSoup(page.text, 'lxml')
    data = soup.find('table', summary="수요예측일정")
    headers = []
    for i in data.find_all('th'):
        title = i.text.strip()
        headers.append(title)
    rows = []
    df_bookbuild = pd.DataFrame(columns=headers)
    for j in data.find_all('tr')[2:]:
        rdata = j.find_all('td')
        row = [tr.text.strip() for tr in rdata]
        rows.append(row)
    for k in range(len(rows)):
        try:
            df_bookbuild.loc[k] = rows[k]
        except:
            print('Last row is an empty row')
    df_bookbuild = df_bookbuild[['종목명', '수요예측일', '주간사']]
    df_bookbuild['종목명'] = df_bookbuild['종목명'].apply(lambda x: x.split('(')[0])
    df_bookbuild.rename(columns={'수요예측일': '날짜'}, inplace=True)
    df_bookbuild['날짜'] = df_bookbuild['날짜'].apply(lambda x: x[0:5] + x[11:16])
    df_bookbuild['주간사'] = df_bookbuild['주간사'].apply(lambda x: x.split(','))
    df_bookbuild['주간사'] = df_bookbuild['주간사'].apply(lambda x: x[0])  # Formatting
    df_bookbuild['Type'] = 'BB-마감'
    df_bookbuild['날짜'] = df_bookbuild['날짜'].apply(lambda x: x.replace('.', '-'))
    df_bookbuild = df_bookbuild[['종목명', '날짜', 'Type', '주간사']]
    df_bookbuild = df_bookbuild.drop(df_bookbuild[df_bookbuild['날짜'] < input_database.today_middle_bar].index)
    return df_bookbuild


def bbe_merge():
    url_bookbuild_first = "http://www.38.co.kr/html/fund/index.htm?o=r&page=1"
    url_bookbuild_second = "http://www.38.co.kr/html/fund/index.htm?o=r&page=2"
    first_bbe = book_build_end(url_bookbuild_first)
    second_bbe = book_build_end(url_bookbuild_second)
    sum_bbe = pd.concat([first_bbe, second_bbe])
    return sum_bbe


def individual(url):
    page = requests.get(url)
    soup = BeautifulSoup(page.text, 'lxml')
    data = soup.find('table', summary="공모주 청약일정")
    headers = []
    for i in data.find_all('th'):
        title = i.text.strip()
        headers.append(title)
    rows = []
    df_individual = pd.DataFrame(columns=headers)
    for j in data.find_all('tr')[2:]:
        rdata = j.find_all('td')
        row = [tr.text.strip() for tr in rdata]
        rows.append(row)
    for k in range(len(rows)):
        df_individual.loc[k] = rows[k]
    df_individual = df_individual[['종목명', '공모주일정', '주간사']]
    df_individual['종목명'] = df_individual['종목명'].apply(lambda x: x.split('(')[0])
    df_individual.rename(columns={'공모주일정': '날짜'}, inplace=True)
    df_individual['날짜'] = df_individual['날짜'].apply(lambda x: x[0:5] + x[11:16])
    df_individual['주간사'] = df_individual['주간사'].apply(lambda x: x.split(','))
    df_individual['주간사'] = df_individual['주간사'].apply(lambda x: x[0])
    df_individual['Type'] = '개인'
    df_individual['날짜'] = df_individual['날짜'].apply(lambda x: x.replace('.', '-'))
    df_individual = df_individual.drop(df_individual[df_individual['날짜'] < input_database.today_middle_bar].index)
    df_individual = df_individual[['종목명', '날짜', 'Type', '주간사']]
    return df_individual


def retail_merge():
    url_retail_first = "http://www.38.co.kr/html/fund/index.htm?o=k&page=1"
    url_retail_second = "http://www.38.co.kr/html/fund/index.htm?o=k&page=2"
    first_retail = individual(url_retail_first)
    second_retail = individual(url_retail_second)
    sum_retail = pd.concat([first_retail, second_retail])
    return sum_retail


def payment_links(url):
    req = requests.get(url)
    soup = BeautifulSoup(req.text, "lxml")
    links = []
    for link in soup.findAll('a', attrs={'class': 'menu'}):
        links.append(link.get('href'))

    for link in range(len(links)):
        links[link] = links[link].replace('.', 'http://www.38.co.kr/html/fund', int(str(url)[-1]))
    return links


def payment(url):
    pair = []
    page = requests.get(url)
    soup = BeautifulSoup(page.text, 'lxml')
    data_name = soup.find('table', summary="기업개요")
    data_pay = soup.find('table', summary="공모청약일정")
    data_bank = soup.find('table', summary="공모정보")
    name = data_name.find_all('tr')[0].find_all('td')[1].text.strip()
    pay = data_pay.find_all('tr')[3].find_all('td')[1].text.strip()
    bank = data_bank.find_all('tr')[4].find_all('td')[1].text.strip()
    bank = bank.split(',')[0]
    pair.append(name)
    pair.append(pay)
    pair.append(bank)
    return pair


def get_payment_df(url):
    url_list = payment_links(url)
    pair_list = []
    for url in url_list:
        pair = payment(url)
        pair_list.append(pair)
    df_payment = pd.DataFrame(pair_list, columns=['기업명', '날짜', '주간사'])

    df_payment['날짜'] = df_payment['날짜'].apply(lambda x: x.replace('.', '-'))
    df_payment['Type'] = '납입일'
    df_payment['종목명'] = df_payment['기업명']
    df_payment = df_payment[['종목명', '날짜', 'Type', '주간사']]
    df_payment = df_payment.drop(df_payment[df_payment['날짜'] < input_database.today_middle_bar].index)
    return df_payment


def payment_merge():
    url_payment_first = "http://www.38.co.kr/html/fund/index.htm?o=r&page=1"
    url_payment_second = "http://www.38.co.kr/html/fund/index.htm?o=r&page=2"
    first_pay = get_payment_df(url_payment_first)
    second_pay = get_payment_df(url_payment_second)
    sum_pay = pd.concat([first_pay, second_pay])
    return sum_pay


def listing_date_ipo(url):
    page = requests.get(url)
    soup = BeautifulSoup(page.text, 'lxml')
    data = soup.find('table', summary="신규상장종목")
    headers = []
    for i in data.find_all('th'):
        title = i.text.strip()
        headers.append(title)
    rows = []
    df_ipo = pd.DataFrame(columns=headers)
    for j in data.find_all('tr')[2:]:
        rdata = j.find_all('td')
        row = [tr.text.strip() for tr in rdata]
        rows.append(row)
    for k in range(len(rows)):
        df_ipo.loc[k] = rows[k]
    df_ipo = df_ipo[['기업명', '신규상장일']]
    df_ipo['종목명'] = df_ipo['기업명'].apply(lambda x: x.split('(')[0])
    df_ipo.rename(columns={'신규상장일': '날짜'}, inplace=True)
    df_ipo.rename(columns={'날짜_y': '날짜'}, inplace=True)
    df_ipo['Type'] = '상장일'
    df_ipo['주간사'] = ''
    df_ipo = df_ipo[['종목명', '날짜', 'Type', '주간사']]
    df_ipo['날짜'] = df_ipo['날짜'].apply(lambda x: x.replace('/', '-'))
    df_ipo = df_ipo.drop(df_ipo[df_ipo['날짜'] < input_database.today_middle_bar].index)
    return df_ipo


def listing_merge():
    url_listing_first = "http://www.38.co.kr/html/fund/index.htm?o=nw&page=1"
    url_listing_second = "http://www.38.co.kr/html/fund/index.htm?o=nw&page=2"
    first_listing = listing_date_ipo(url_listing_first)
    second_listing = listing_date_ipo(url_listing_second)
    sum_listing = pd.concat([first_listing, second_listing])
    return sum_listing


def df_merge():
    df_bbs = bbs_merge()
    df_bbe = bbe_merge()
    df_retail = retail_merge()
    df_pay = payment_merge()
    df_listing = listing_merge()
    result_df = pd.concat([df_bbs, df_bbe, df_retail, df_pay, df_listing])
    result_df = result_df.reset_index(drop=True)
    result_df = result_df[['종목명', 'Type', '날짜', '주간사']]
    return result_df


if __name__ == "__main__":
    print(df_merge())
