import pandas as pd
import numpy as np
import requests
import time
import os
from etc_module.function import get_listing_date
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

THREAD_WORKERS = 5
BATCH_SIZE = 20
DELAY_SECONDS = 4
RESULT_FILE_NAME = "Beta_Calculated_Result.xlsx"  # 🇰🇷 [추가] 결과를 저장할 파일명 정의


# 🚨 input_database 모듈과 url_market_beta_new 변수가 외부에서 정의되어 있어야 합니다.
# (테스트용 임시 클래스)
class input_database:
    url_market_beta_new = "http://43.202.36.216:13050/market-relativity/ticker/"


def historical_beta(_ticker: str, _date: str):
    _beta_data = {
        "ticker": _ticker,
        "n": 90,
        "recordDate": _date,
    }
    chg_90d_beta_data = requests.get(
        url=input_database.url_market_beta_new, params=_beta_data
    ).json()
    beta_data = chg_90d_beta_data["body"]
    beta = 1
    beta_dict = dict()
    for _page in beta_data:
        beta_dict[f"{_page['market']}"] = abs(_page["correlation"])
    market = max(beta_dict, key=beta_dict.get)
    quarterly_busy = 62
    for _page in beta_data:
        if _page["market"] == market and _page:
            try:
                date_difference = np.busday_count(
                    begindates=get_listing_date(_ticker),
                    enddates=_date,
                )
                if 0 < date_difference < quarterly_busy:
                    beta = _page["beta"] * (date_difference / quarterly_busy)
                elif date_difference <= 0:
                    beta = 0
                else:
                    beta = _page['beta']
            except ValueError:
                beta = _page['beta']
            except TypeError:
                print("TypeError:" + str(_page['stockName']))
                beta = _page['beta']
    return beta


def get_page_list():
    file_path = "Beta.xlsx"
    print(f"📁 입력 파일 '{file_path}'을(를) 불러옵니다.")

    # 1. 원본 데이터 로드
    try:
        df = pd.read_excel(file_path, dtype={'ticker': str})
    except FileNotFoundError:
        print(f"❌ 파일 '{file_path}'을(를) 찾을 수 없습니다.")
        return pd.DataFrame()

    # 2. 이어하기(Resume) 로직: 결과 파일이 있다면 병합
    if os.path.exists(RESULT_FILE_NAME):
        print(f"🔄 기존 결과 파일('{RESULT_FILE_NAME}') 발견! 이어하기를 준비합니다.")
        try:
            df_old = pd.read_excel(RESULT_FILE_NAME)

            # 'Beta' 컬럼이 있다면 병합 시도 (Ticker와 Date 기준)
            if 'Beta' in df_old.columns:
                # 원본 df에 'Beta' 컬럼이 없으면 생성
                if 'Beta' not in df.columns:
                    df['Beta'] = None

                # df_old에서 값을 가져와 df에 채워 넣기 (매핑)
                old_beta_map = {}
                for _, row in df_old.iterrows():
                    # 키 생성 시에도 문자열 변환 및 0 채우기 적용
                    t_code = str(row.get('ticker')).strip()
                    if t_code.isdigit() and len(t_code) < 6:
                        t_code = t_code.zfill(6)

                    key = (t_code, str(row.get('date')))
                    old_beta_map[key] = row.get('Beta')

                # 현재 df 업데이트
                applied_count = 0
                for idx, row in df.iterrows():
                    key = (str(row.get('ticker')), str(row.get('date')))
                    if key in old_beta_map and pd.notna(old_beta_map[key]):
                        df.at[idx, 'Beta'] = old_beta_map[key]
                        applied_count += 1

                print(f"✅ 기존 데이터에서 {applied_count}개의 베타 값을 복구했습니다.")

        except Exception as e:
            print(f"⚠️ 기존 파일 읽기 실패 (새로 시작합니다): {e}")
            df['Beta'] = None
    else:
        # 결과 파일이 없으면 Beta 컬럼 초기화
        if 'Beta' not in df.columns:
            df['Beta'] = None

    # 3. 처리해야 할 작업(Task) 선별
    tasks = []

    # Beta 값이 비어있는(NaN/None) 행만 작업 목록에 추가
    for index, row in df.iterrows():
        # 이미 값이 있으면 스킵
        if pd.notna(row['Beta']):
            continue

        ticker = str(row['ticker'])
        record_date = row["date"]

        if pd.notna(record_date):
            if isinstance(record_date, datetime):
                record_date_str = record_date.strftime('%Y-%m-%d')
            else:
                record_date_str = str(record_date).split(' ')[0]
        else:
            print(f"⚠️ {ticker} 종목에 날짜가 누락되었습니다. 스킵합니다.")
            continue

        tasks.append((index, ticker, record_date_str))

    total_tasks = len(tasks)
    total_rows = len(df)
    already_done = total_rows - total_tasks

    print(f"\n📊 [작업 현황판]")
    print(f"   - 전체 데이터: {total_rows} 건")
    print(f"   - 이미 완료됨: {already_done} 건")
    print(f"   - 처리할 작업: {total_tasks} 건")

    if total_tasks == 0:
        print("🎉 모든 작업이 이미 완료되었습니다!")
        return df

    print("\n🚀 베타 계산을 시작합니다...")

    # 4. 배치 처리 및 안전한 저장 (Try-Finally)
    # beta_results 리스트 대신 df에 직접 값을 씁니다.

    try:
        with ThreadPoolExecutor(max_workers=THREAD_WORKERS) as executor:
            num_tasks = len(tasks)
            processed_count = 0

            # 배치 단위 루프
            for i in range(0, num_tasks, BATCH_SIZE):
                batch_tasks = tasks[i:i + BATCH_SIZE]
                current_batch_size = len(batch_tasks)

                print(
                    f"\n⏳ [진행 중] {processed_count + 1} ~ {processed_count + current_batch_size} / {total_tasks} (배치 처리 중...)")

                future_to_index = {}
                for idx, ticker, record_date_str in batch_tasks:
                    future = executor.submit(historical_beta, ticker, record_date_str)
                    future_to_index[future] = idx

                for future in future_to_index:
                    index = future_to_index[future]
                    ticker = df.at[index, 'ticker']  # 원본 df에서 ticker 확인

                    try:
                        beta_value = future.result()
                        # 결과 즉시 반영 (메모리 상의 df 업데이트)
                        df.at[index, 'Beta'] = beta_value
                    except Exception as exc:
                        print(f"❌ {ticker} 처리 중 예외 발생: {exc}")

                processed_count += current_batch_size

                # 중간 저장 (선택 사항: 매우 중요한 경우 배치마다 저장 가능)
                # df.to_excel(RESULT_FILE_NAME, index=False)

                # 다음 배치 전 대기
                if i + BATCH_SIZE < num_tasks:
                    print(f"☕ 서버 부하 방지를 위해 {DELAY_SECONDS}초간 휴식합니다.")
                    time.sleep(DELAY_SECONDS)

    except KeyboardInterrupt:
        print("\n🛑 사용자에 의해 작업이 중단되었습니다!")
    except Exception as e:
        print(f"\n🚨 치명적인 오류 발생: {e}")
    finally:
        # 5. 최종 저장 (에러가 나든, 완료가 되든 무조건 실행)
        print(f"\n💾 작업 내용을 '{RESULT_FILE_NAME}'에 저장 중입니다... (절대 끄지 마세요)")
        df.to_excel(RESULT_FILE_NAME, index=False)
        print("✅ 저장이 완료되었습니다. 나중에 다시 실행하면 이어서 진행됩니다.")

    return df


if __name__ == "__main__":
    final_df = get_page_list()
    # 이미 함수 내부의 finally 블록에서 저장이 수행되므로 여기서는 추가 저장 불필요