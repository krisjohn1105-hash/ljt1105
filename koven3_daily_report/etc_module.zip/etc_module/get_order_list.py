import requests
import input_database
import pandas as pd
import uuid
import time
import os
import constants
from datetime import datetime
from operator import itemgetter
from common_function import get_uuid_list_through_filter, get_uuid_use_string_account


def order_data_period(_from: str, _to: str):
    macro_list = get_uuid_list_through_filter("macro-")
    ipo_list = get_uuid_list_through_filter("venture-1-ipo-ipo") + get_uuid_list_through_filter("venture-1-ipo-new") \
               + get_uuid_list_through_filter("multi-1-ipo-") + get_uuid_list_through_filter("ipo-1-ipo-") \
               + get_uuid_list_through_filter("venture-2-ipo-ipo") + get_uuid_list_through_filter("venture-2-ipo-new") \
               + get_uuid_list_through_filter("venture-3-ipo-ipo") + get_uuid_list_through_filter("venture-3-ipo-new") \
               + get_uuid_list_through_filter("multi-2-ipo-") + get_uuid_list_through_filter("prelude-ipo")
    block_list = (get_uuid_list_through_filter("block-stock") + get_uuid_list_through_filter("block-futures") +
                  get_uuid_list_through_filter("prelude-block"))
    event_list = get_uuid_list_through_filter("event-stock") + get_uuid_list_through_filter("event-futures") + get_uuid_list_through_filter("prelude-event")
    post_list = get_uuid_list_through_filter("post-stock") + get_uuid_list_through_filter("post-futures")
    account_list_ipo = get_uuid_list_through_filter("ipo-block-")
    account_list_kv = get_uuid_list_through_filter("venture-1-")
    account_list_kv2 = get_uuid_list_through_filter("venture-2-")
    account_list_kv3 = get_uuid_list_through_filter("venture-3-")
    account_list_multi = get_uuid_list_through_filter("multi-1-event")
    account_list_multi_2 = get_uuid_list_through_filter("multi-2-")
    account_list_prelude = get_uuid_list_through_filter("et-prelude")
    all_fund_account = account_list_prelude
    # all_fund_account = account_list_multi_2 + account_list_multi + account_list_kv2 + account_list_kv3 + account_list_kv + account_list_prelude

    sum_list = list()
    input_ecm = {
        "accountIds": all_fund_account,
        "from" : _from,
        "to": _to,
        }
    order_list = requests.post(url=input_database.uri_get_order_data, json=input_ecm).json()['body']
    cumulative_list = list()
    for _od in order_list:
        _member, _ticker, _asset_type, _stock_name, _listing_date, _order_list = position_id_info(_od['positionId'])
        order_dict = dict()
        order_dict['date'] = _od['orderDateTime']
        if _od['accountId'] in macro_list:
            order_dict['Book Name'] = 'Macro'
        elif _od['accountId'] in ipo_list:
            order_dict['Book Name'] = 'IPO'
        elif _od['accountId'] in event_list:
            order_dict['Book Name'] = 'event'
        elif _od['accountId'] in block_list:
            order_dict['Book Name'] = 'block'
        elif _od['accountId'] in post_list:
            order_dict['Book Name'] = 'post'
        else:
            member_map = {
                "pm": "Long Short__WK",
                "yc": "Long Short__YW",
                "hj": "Long Short__HJ",
                "jj": "Long Short__JJ"
            }
            order_dict['Book Name'] = member_map.get(_member, f"Long Short__{str(_member).upper()}")
            
        if len(_ticker) == 5:
            bloomberg_ticker = convert_to_bloomberg(_ticker, asset_table, year_data, month_data)
        elif len(_ticker) == 6:
            bloomberg_ticker = convert_spot_bbg_ticker(_ticker)
            continue
        else:
            bloomberg_ticker = _ticker
            continue
        order_dict['accountId'] = _od['accountId']
        order_dict['member'] = _member
        try:
            basket_id, basket_name = get_basket_id_by_position(_od['positionId'])
        except (TypeError, ValueError):
            basket_id, basket_name = "", ""
            
        trans_type = "BuyToCover" if _od['direction'] == "BUY" else "SellShort"
        
        order_dict['Trade Date'] = str(_od['orderDateTime'])[:10]
        order_dict['Settle Date'] = str(_od['orderDateTime'])[:10]
        order_dict['Account Id'] = 517879
        order_dict['Counterparty Code'] = 'INTL'
        order_dict['Transaction Type'] = trans_type
        order_dict['Identifier'] = bloomberg_ticker
        order_dict['Identifier Type'] = 'Bloomberg Yellow'
        order_dict['Quantity'] = abs(_od['quantity'])
        order_dict['Settle CCY'] = 'USD'
        order_dict['Trade CCY'] = 'KRW'
        order_dict['Other Payments 1'] = 0
        order_dict['Other Payments 1 Type'] = 'FlatCommission'
        order_dict['Trade Price'] = _od['price']
        order_dict['Trade/Settle FX Rate'] = 0.0007211781165712308
        order_dict['Notes'] = basket_name
        order_dict['Basket_id'] = basket_id
        
        cumulative_list.append(order_dict)
        
    df_log = pd.DataFrame(cumulative_list)
    cols_order = [
         'Trade Date', 'Settle Date', 'Account Id', 'Counterparty Code', 'Transaction Type',
         'Book Name', 'Identifier', 'Identifier Type', 'Quantity', 'Settle CCY', 'Trade CCY',
         'Other Payments 1', 'Other Payments 1 Type', 'Trade Price', 'Trade/Settle FX Rate', 'Notes', 'Basket_id'
     ]
    final_cols = [c for c in cols_order if c in df_log.columns]
    df_log = df_log[final_cols]
    
    df_log.to_excel(f'{_from}_order.xlsx', index=False, sheet_name="raw_data")
    return cumulative_list

def convert_to_bloomberg(futures_code, asset_table, year_table, month_table):
    korean_asset_code = futures_code[:3]
    if korean_asset_code not in index_list:
        asset_table['기초자산_종목코드'] = (
            asset_table['기초자산_종목코드']
            .fillna('')
            .astype(str)
            .str.split('.').str[0]  # Remove any decimal point introduced by floats
            .str.zfill(6)  # Pad with zeros to 6 digits
            )

    asset_row = asset_table[asset_table['선물종목코드'].astype(str).str[:3] == korean_asset_code]
    if asset_row.empty:
        return "ERROR: Unknown Asset Code"
    asset_code = asset_row['기초자산_종목코드'].values[0]
    market_code = asset_row['기초자산_소속시장'].values[0]

    # Extract year and month characters from futures contract code
    year_code = futures_code[3]
    month_code = futures_code[4]

    # Convert year code to Bloomberg format
    year_row = year_table[year_table['KoreanYearCode'] == year_code]
    if year_row.empty:
        return "ERROR: Invalid Year Code"
    bloomberg_year = year_row['BloombergYearCode'].values[0]

    # Convert month code to Bloomberg format
    month_row = month_table[month_table['KoreanMonthCode'] == month_code]
    if month_row.empty:
        return "ERROR: Invalid Month Code"
    bloomberg_month = month_row['BloombergMonthCode'].values[0]

    # Combine asset code and Bloomberg month-year code
    if any(keyword in str(asset_code) for keyword in ["KM", "KMS", "KST"]):
        asset_code = asset_code.replace("0", "")
        return f"{str(asset_code)}{bloomberg_month}{bloomberg_year} {market_code}"
    if korean_asset_code not in index_list:
        return f"{str(asset_code)[:5]}={bloomberg_month}{bloomberg_year} {market_code} Equity"
    else:
        return f"{str(asset_code)}{bloomberg_month}{bloomberg_year} {market_code}"


def convert_spot_bbg_ticker(_k_ticker):
    _url = input_database.url_get_price_ticker + str(_k_ticker)
    input_dict_k = {
        "ticker": _k_ticker
        }
    _market = requests.get(url=_url, params=input_dict_k).json()['body']['market']
    if _market == "KOSPI":
        return f"{_k_ticker} KP Equity"
    else:
        return f"{_k_ticker} KQ Equity"

def position_id_info(_position_id):
    positions_id = {
        'positionId': _position_id
    }
    position_info = \
        requests.get(url=input_database.url_positions_information + str(_position_id), params=positions_id).json()[
            'body']
    if position_info is None:
        return None
    elif position_info['memberId'] == input_database.member_hj['memberId']:
        _member = 'hj'
    elif position_info['memberId'] == input_database.member_jr['memberId']:
        _member = 'jr'
    elif position_info['memberId'] == input_database.member_yc['memberId']:
        _member = 'yc'
    elif position_info['memberId'] == input_database.member_dk['memberId']:
        _member = 'dk'
    elif position_info['memberId'] == input_database.member_jj['memberId']:
        _member = 'jj'
    else:
        _member = 'pm'
    _ticker = position_info['ticker']
    _asset_type = position_info['assetType']
    get_name = requests.get(url=input_database.url_stock_ticker + str(_ticker), params={"ticker": _ticker}).json()[
        'body']
    _stock_name = get_name['name']
    _listing_date = get_name['listingDate']
    position_order_info = requests.get(
        url=input_database.url_position_basic + str(_position_id), params=positions_id
    ).json()['body']['orders']
    try:
        order_date = order_split(position_order_info)
    except KeyError:
        order_date = []

    return _member, _ticker, _asset_type, _stock_name, _listing_date, order_date

def get_basket_id_by_position(position_id):
    url = "http://43.202.36.216:15000/api/baskets/by_positions"
    payload = [
        {
            "position_id": str(position_id)  # 문자열로 변환하여 전송
        }
    ]
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        data = response.json()
        if data and isinstance(data, list) and len(data) > 0:
            return data[0].get("basket_id"), data[0].get("name")
        else:
            print(f"해당 position_id({position_id})에 대한 바스켓 정보를 찾을 수 없습니다.")
            return None

    except requests.exceptions.RequestException as e:
        print(f"API 요청 중 오류 발생: {e}")
        return None
    except (IndexError, KeyError, TypeError) as e:
        print(f"데이터 파싱 중 오류 발생: {e}")
        return None

def order_split(_order_list):
    date_list = [str(_order['orderDateTime'])[0:10] for _order in _order_list]
    date_list.sort()

    if not date_list:
        return []

    return [date_list[0], date_list[-1]]

request_uuid = uuid.uuid4()
timestamp = int(time.time())
year_data = pd.DataFrame({
    'KoreanYearCode': ['S', 'T', 'V', 'W', '6'],
    'BloombergYearCode': ['2', '3', '4', '5', '6']
})

month_data = pd.DataFrame({
    'KoreanMonthCode': ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C'],
    'BloombergMonthCode': ['F', 'G', 'H', 'J', 'K', 'M', 'N', 'Q', 'U', 'V', 'X', 'Z']
})
index_list = ["A01", "A05", "A06"]
asset_table = pd.read_excel(constants.LONGSHORT_DIR + "/개별주식선물코드.xlsx")


if __name__ == "__main__":
    order_data_period("2026-03-01", "2026-03-04")