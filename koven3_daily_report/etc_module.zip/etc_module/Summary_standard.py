import pandas as pd
import input_database
import constants
import requests
import excel2img
import os
import re
import math
from intradayNotification.performance_prelude import get_pnl_base_prices
from etc_module.hints_pnl import hints_month_excel, hints_yesterday_excel
from openpyxl.styles import Border, Side, Alignment
from common_function import get_uuid_list_through_filter
from tabulate import tabulate
from common_function import get_fund_pnl_database, get_futures_data, get_krwusd
from openpyxl import load_workbook

tabulate.WIDE_CHARS_MODE = False


class HintsSearch:
    def __init__(self, bond_pnl: int):
        self.bond_pnl = bond_pnl

    def hints_excel(self):
        global all_aum_str

        # --- [ 1. 엑셀 로드 ] ---
        try:
            hints_excel = load_workbook(constants.LONGSHORT_DIR +
                                        f"/10304_일자별기준가격 조회_{input_database.today_constant}.xlsx"
                                        )
            sheet = hints_excel["22204_기준가격표"]
        except FileNotFoundError:
            print(f" [에러] AUM 엑셀 파일을 찾을 수 없습니다: {constants.LONGSHORT_DIR}")
            return None
        except KeyError:
            print(f" [에러] 엑셀 파일에서 '22204_기준가격표' 시트를 찾을 수 없습니다.")
            return None

        # --- [ 2. 펀드명 매핑 (E열 기준) ] ---
        # 엑셀 E열의 이름과 우리 내부 key(ipo, kv 등)를 연결.
        FUND_MAP = {
            "두나미스 공모주멀티 일반사모투자신탁": "ipo",
            "두나미스 공모주 일반사모투자신탁 제2호": "ipo2",
            "두나미스 공모주 포커스 일반사모투자신탁": "focus",
            "두나미스 코스닥벤처 일반사모투자신탁": "kv",
            "두나미스 코스닥벤처 일반사모투자신탁 2호": "kv2",
            "두나미스 코스닥벤처 일반사모투자신탁 3호": "kv3",
            "두나미스 멀티전략 일반사모(운)": "multi_1",
            "두나미스 멀티전략 일반사모투자신탁 2호": "multi_2",
            "두나미스 블록딜공모주 일반사모투자신탁 1호(운용)": "block",
            "DUNAMIS_PRELUDE 일임 (USD)": "prelude"
        }

        # --- [ 3. 데이터 로드 및 1차 계산 ] ---
        pnl_dict = fund_pnl()  # DB에서 PnL 가져오기
        fx_rate = get_krwusd()  # 환율 가져오기
        fund_data = {}  # 데이터를 저장할 딕셔너리

        # 엑셀을 E열(5)부터 J열(10)까지 순회.
        for row in sheet.iter_rows(min_row=2, max_row=50, min_col=5, max_col=10):
            fund_name_e = row[0].value  # E열 (펀드명)
            aum_g = row[2].value  # G열 (순자산 AUM)
            nav_j = row[5].value  # J열 (수정기준가)

            # E열의 펀드 이름이 우리가 찾는 펀드 맵에 있는지 확인
            if fund_name_e in FUND_MAP:
                book_name = FUND_MAP[fund_name_e]  # 'ipo', 'kv' 등 내부 이름

                # 숫자형 데이터가 맞는지 확인
                aum_pre = aum_g if isinstance(aum_g, (int, float)) else 0
                nav_pre = nav_j if isinstance(nav_j, (int, float)) else 0
                pnl = pnl_dict.get(book_name, 0)

                # 딕셔너리에 데이터 저장
                fund_data[book_name] = {
                    "name_excel": fund_name_e,
                    "aum_pre": aum_pre,  # 전일 AUM
                    "nav_pre": nav_pre,  # 전일 수정기준가
                    "pnl": pnl  # 당일 PnL
                }

        # --- [ 4. Prelude AUM 특별 처리 (기존 로직 동일) ] ---
        eqswap_result = get_pnl_base_prices()
        
        if not isinstance(eqswap_result, str):
            curr, mtd_base, ytd_base = eqswap_result
            
            # 엑셀(10304)에 Prelude가 없더라도, EQSWAP 데이터가 있다면 강제로 포함
            if "prelude" not in fund_data:
                fund_data["prelude"] = {
                    "name_excel": "DUNAMIS_PRELUDE 일임 (USD)",
                    "pnl": pnl_dict.get("prelude", 0),
                    "aum_pre": 0,
                    "nav_pre": 0
                }

            fund_data["prelude"]["aum_pre"] = 10000000 * fx_rate
            fund_data["prelude"]["nav_pre"] = curr
            fund_data["prelude"]["total_pct"] = curr / 1000 - 1
            fund_data["prelude"]["mtd_pct"] = mtd_base / 1000 - 1
            fund_data["prelude"]["ytd_pct"] = ytd_base / 1000 - 1
        else:
            print(f" [경고] Prelude 데이터를 처리할 수 없습니다: {eqswap_result}")

        # Prelude PnL은 fund_pnl()에서 이미 가져옴

        # --- [ 5. AUM 조정 및 Chg% 계산 (기존 로직 동일) ] ---
        all_aum = 0
        for book_name, data in fund_data.items():
            # Chg % 계산
            if data["aum_pre"] > 0:
                data["chg_pct"] = data["pnl"] / data["aum_pre"]
            else:
                data["chg_pct"] = 0

            # AUM 조정 (PnL 더하기)
            aum_post = data["aum_pre"] + data["pnl"]

            # 하드코딩된 AUM 조정 반영 (주석처리된 것도 동일하게 반영)

            # Prelude는 PnL을 더하지 않고 원본 AUM을 그대로 사용
            if book_name == "prelude":
                aum_post = data["aum_pre"]  # PnL 더한 것을 원복

            data["aum_post"] = aum_post
            all_aum += aum_post

        asset_unit = 100000000
        all_aum_str = str(round((all_aum / asset_unit), 1))

        # --- [ 6. 누적 수익률 (Total) 계산 (기존 로직 동일) ] ---
        # 원본 코드의 하드코딩된 최초 기준가
        initial_nav_bases = {
            "ipo": 1000, "ipo2": 957.21, "focus": 1000,
            "kv": 1000, "kv2": 1000, "kv3": 1000,
            "multi_1": 1000, "multi_2": 1000, "block": 1000,
            "prelude": 1000
        }

        for book_name, data in fund_data.items():
            if book_name in initial_nav_bases:
                today_nav = data["nav_pre"] * (1 + data["chg_pct"])
                initial_base = initial_nav_bases[book_name]

                if book_name == "ipo2":
                    data["total_pct"] = (today_nav / initial_base) - 1
                else:
                    data["total_pct"] = (today_nav - initial_base) / initial_base
            else:
                data["total_pct"] = 0

        # --- [ 7. MTD, YTD 계산 (기존 로직 동일) ] ---
        eom_pnl_dict = hints_month_excel()
        eom_pnl_dict['prelude'] = mtd_base
        # 원본 코드의 하드코딩된 YTD 기준가
        ytd_bases = {
            "ipo": 1665.0337, "ipo2_base": 1245.1267, "ipo2_initial": 957.21,
            "focus": 1063.4109, "kv": 2545.2509, "kv2": 1304.0044,
            "kv3": 1329.7383, "multi_1": 1780.8309, "multi_2": 1124.28,
            "block": 1164.4094, "prelude": ytd_base
        }

        # eom_pnl_dict의 key와 펀드 key를 매핑
        eom_keys = {
            "ipo": "ipo_1", "ipo2": "ipo_2", "focus": "ipo_f",
            "kv": "kv_1", "kv2": "kv_2", "kv3": "kv_3",
            "multi_1": "multi_1", "multi_2": "multi_2",
            "block": "ipo_b", "prelude": "prelude"
        }

        for book_name, data in fund_data.items():
            if book_name not in eom_keys: continue

            total_nav = data["total_pct"] * 1000 + 1000
            mtd_base_key = eom_keys[book_name]

            # MTD
            if book_name == "ipo2":
                data["mtd_pct"] = total_nav / (eom_pnl_dict['ipo_2'] / ytd_bases['ipo2_initial'] * 1000) - 1
            # elif book_name == "prelude":
            #     total_nav_prelude = data["total_pct"] * 10 + 10
            #     data["mtd_pct"] = total_nav_prelude / eom_pnl_dict['prelude'] - 1
            else:
                data["mtd_pct"] = total_nav / eom_pnl_dict[mtd_base_key] - 1

            # YTD
            if book_name == "ipo2":
                data["ytd_pct"] = total_nav / (ytd_bases['ipo2_base'] / ytd_bases['ipo2_initial'] * 1000) - 1
            # elif book_name == "prelude":
            #     total_nav_prelude = data["total_pct"] * 10 + 10
            #     data["ytd_pct"] = total_nav_prelude / ytd_bases['prelude'] - 1
            else:
                ytd_base_val = ytd_bases.get(book_name, 1000)  # 기본값 1000
                data["ytd_pct"] = total_nav / ytd_base_val - 1

        # --- [ 8. 최종 DataFrame 생성 (기존 로직 동일) ] ---
        # 원본 코드의 출력용 펀드 이름
        display_name_map = {
            "ipo": "공멀", "ipo2": "공2", "focus": "공F",
            "kv": "코1", "kv2": "코2", "kv3": "코3",
            "multi_1": "멀1", "multi_2": "멀2",
            "block": "블록", "prelude": "Pre"
        }
        # 원본 코드의 정렬 순서
        sorting_number = {
            '멀1': 1, '멀2': 2, '공멀': 3, '코1': 4, '코2': 5,
            '코3': 6, '블록': 7, '공F': 8, '공2': 9, 'Pre': 10
        }

        perform_list = []
        for book_name, data in fund_data.items():
            if book_name not in display_name_map: continue

            display_name = display_name_map[book_name]
            pnl_row = {
                '펀드': display_name,
                f'{all_aum_str}': str(round(data["aum_post"] / 100000000)),
                'Chg %': f"{round_down(data.get('chg_pct', 0) * 100, 2):.2f}%",
                'MTD': str(round_down(data.get('mtd_pct', 0) * 100)) + "%",
                'YTD': str(round_down(data.get('ytd_pct', 0) * 100)) + "%",
                'Total': str(round_down(data.get('total_pct', 0) * 100)) + "%",
                'sorted': sorting_number[display_name]
            }
            if data.get('chg_pct', 0) >= 0:
                pnl_row['Chg %'] = "+" + pnl_row['Chg %']

            perform_list.append(pnl_row)

        perform_list = sorted(perform_list, key=(lambda x: x['sorted']))
        perform_dataframe = pd.DataFrame.from_records(perform_list)
        perform_dataframe = perform_dataframe.drop('sorted', axis=1)

        perform_dataframe.to_excel(
            constants.LONGSHORT_DIR + f"./{input_database.today_constant}_data.xlsx"
        )
        return perform_dataframe


def round_down(value, decimals=1):
    factor = 10 ** decimals
    return math.floor(value * factor) / factor



def fund_pnl():
    pnl_dict = dict()
    pnl_dict['ipo'] = get_fund_pnl_database("ipo-1")
    pnl_dict['multi_1'] = get_fund_pnl_database("multi-1")
    pnl_dict['multi_2'] = get_fund_pnl_database("multi-2")
    pnl_dict['kv'] = get_fund_pnl_database("venture-1")
    pnl_dict['kv2'] = get_fund_pnl_database('venture-2')
    pnl_dict['kv3'] = get_fund_pnl_database('venture-3')
    pnl_dict['ipo2'] = get_fund_pnl_database("ipo-2")
    pnl_dict['focus'] = get_fund_pnl_database('ipo-focus')
    pnl_dict['alpha'] = get_fund_pnl_database('ipo-alpha')
    pnl_dict['block'] = get_fund_pnl_database('ipo-block')
    pnl_dict['prelude'] = get_fund_pnl_database('et-prelude')
    return pnl_dict


def fund_summary_image():
    workbook = load_workbook(constants.LONGSHORT_DIR + f"/{input_database.today_constant}_data.xlsx")
    sheet = workbook.active
    sheet['F1'] = input_database.today_middle_bar
    sheet.column_dimensions['C'].width = 15
    sheet.column_dimensions['F'].width = 12
    no_border = Border(left=Side(border_style=None),
                       right=Side(border_style=None),
                       top=Side(border_style=None),
                       bottom=Side(border_style=None))
    center_alignment = Alignment(horizontal='center', vertical='center')

    # 모든 셀에 대해 반복하면서 테두리 제거 및 중앙 정렬 적용
    for row in sheet.iter_rows():
        for cell in row:
            cell.border = no_border  # 테두리 제거
            cell.alignment = center_alignment
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    for row in range(1, 13):  # 1~11 행까지
        for col in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']:  # A~F 열까지
            cell = f"{col}{row}"
            if row == 1 or row == 11 or col in ['A', 'H']:
                sheet[cell].border = thin_border
    workbook.save(constants.LONGSHORT_DIR + f"/{input_database.today_constant}_data.xlsx")
    fund_summary = os.path.join(
        constants.LONGSHORT_DIR + f"/{input_database.today_constant}_data.xlsx"
    )
    excel2img.export_img(
        fund_summary,
        constants.BOOK_DIR + "/fund_summary.png",
        "Sheet1",
        f"B1:G12",
    )


def fund_futures_percentage():
    global all_aum_str
    fund_futures_dict = get_futures_data()
    except_high_pnl = HintsSearch(0)
    pnl_data = except_high_pnl.hints_excel()
    kv_asset_str = pnl_data.loc[pnl_data['펀드'] == "코1", f"{all_aum_str}"]
    kv2_asset_str = pnl_data.loc[pnl_data['펀드'] == "코2", f"{all_aum_str}"]
    kv3_asset_str = pnl_data.loc[pnl_data['펀드'] == "코3", f"{all_aum_str}"]
    multi1_asset_str = pnl_data.loc[pnl_data['펀드'] == "멀1", f"{all_aum_str}"]
    multi2_asset_str = pnl_data.loc[pnl_data['펀드'] == "멀2", f"{all_aum_str}"]
    ipo_asset_float = 0.1
    kv_asset_float = convert_string_to_float(kv_asset_str[2])
    kv_2_asset_float = convert_string_to_float(kv2_asset_str[3])
    kv_3_asset_float = convert_string_to_float(kv3_asset_str[4])
    multi1_asset_float = convert_string_to_float(multi1_asset_str[0])
    multi2_asset_float = convert_string_to_float(multi2_asset_str[1])
    kv_cfd_delta = fund_futures_dict['kv'] + get_derivative_positions("venture")
    kv_2_cfd_delta = fund_futures_dict['kv2'] + get_derivative_positions("venture-2")
    kv_3_cfd_delta = fund_futures_dict['kv3'] + get_derivative_positions("venture-3")
    multi_1_cfd_delta = fund_futures_dict['multi1'] + get_derivative_positions("multi-1")
    multi_2_cfd_delta = fund_futures_dict['multi2'] + get_derivative_positions("multi-2")

    multi_1_room = str(round((multi1_asset_float * 0.2 - (multi_1_cfd_delta / 100000000)), 1)) + " 억원"
    multi_2_room = str(round((multi2_asset_float * 0.2 - (multi_2_cfd_delta / 100000000)), 1)) + " 억원"
    kv_room = str(round(((kv_asset_float * 0.1) - (kv_cfd_delta / 100000000)), 1)) + " 억원 (10% limit)"
    kv_2_room = str(round(((kv_2_asset_float * 0.2) - (kv_2_cfd_delta / 100000000)), 1)) + " 억원"
    kv_3_room = str(round(((kv_3_asset_float * 0.2) - (kv_3_cfd_delta / 100000000)), 1)) + " 억원"
    multi_1_futures_percentage = str(round(((multi_1_cfd_delta / 1000000) / multi1_asset_float), 1)) + " %"
    multi_2_futures_percentage = str(round(((multi_2_cfd_delta / 1000000) / multi2_asset_float), 1)) + " %"
    kv_futures_percentage = str(round(((kv_cfd_delta / 1000000) / kv_asset_float), 1)) + " %"
    kv_2_futures_percentage = str(round(((kv_2_cfd_delta / 1000000) / kv_2_asset_float), 1)) + " %"
    kv_3_futures_percentage = str(round(((kv_3_cfd_delta / 1000000) / kv_3_asset_float), 1)) + " %"

    return kv_futures_percentage, kv_room, multi_1_futures_percentage, multi_1_room, \
           multi_2_futures_percentage, multi_2_room, kv_2_futures_percentage, kv_2_room, kv_3_futures_percentage, kv_3_room


def convert_string_to_float(_string: str):
    pattern = r"\d+\.\d+|\d+"
    matches = re.findall(pattern, _string)
    numbers = [float(match.replace(" ", "").replace(",", "")) for match in matches]
    return numbers[0]


def get_derivative_positions(_fund):
    positions = 0
    derivative_ticker_list = ["251340", "252670", "233740", "229200", "465350", "069500"]
    derivative_account = get_uuid_list_through_filter(f"{_fund}-1-ls-stock")
    if _fund == "venture-3":
        derivative_account = get_uuid_list_through_filter(f"venture-3-ls-stock")
    elif _fund == "venture-2":
        derivative_account = get_uuid_list_through_filter(f"venture-2-ls-stock")
    elif _fund == "multi-2":
        derivative_account = get_uuid_list_through_filter(f"multi-2-ls-stock")
    elif _fund == "multi-1":
        derivative_account = get_uuid_list_through_filter(f"multi-1-ls-stock")
    _pages = requests.get(url=input_database.url_book_new + str(derivative_account[0]), params=input_date).json()['body']['pages']
    for _page in _pages:
        if _page['stockTicker'] in derivative_ticker_list:
            positions += (_page['position']['quantity'] * _page['lastPrice'])
    swap_list = [""]
    swap_account = get_uuid_list_through_filter(f"{_fund}-1-event-stock")
    if _fund == "venture-3":
        swap_account = get_uuid_list_through_filter(f"venture-3-event-stock")
    elif _fund == "venture-2":
        swap_account = get_uuid_list_through_filter(f"venture-2-event-stock")
    elif _fund == "multi-2":
        swap_account = get_uuid_list_through_filter(f"multi-2-event-stock")
    elif _fund == "multi-1":
        swap_account = get_uuid_list_through_filter(f"multi-1-event-stock")
    _pages = requests.get(url=input_database.url_book_new + str(swap_account[0]), params=input_date).json()['body']['pages']
    for _page in _pages:
        if _page['stockTicker'] in swap_list:
            positions += abs(_page['position']['quantity'] * _page['lastPrice'])
    return positions


def get_venture_corp_delta_in_post(_fund_number):
    post_list = get_uuid_list_through_filter(f"venture-{_fund_number}-post-stock")
    venture_delta = 0
    for _account in post_list:
        _pages = requests.get(url=input_database.url_book_new + str(_account), params=input_date).json()['body']['pages']
        for _page in _pages:
            if _page['stockTicker'] in venture_ticker_list:
                venture_delta += _page['positionNotionalValue']

    return venture_delta


def extract_numbers(text):
    numbers = re.findall(r"\d+\.\d+|\d+", text)
    return numbers[0] if numbers else None


def get_venture_ratio(_number):
    except_high_pnl = HintsSearch(0)
    pnl_data = except_high_pnl.hints_excel()
    if _number == 3:
        asset_number = 4
    elif _number == 2:
        asset_number = 3
    elif _number == 1:
        asset_number = 2

    asset_divide = pnl_data.loc[pnl_data['펀드'] == f"코{_number}", f"{all_aum_str}"]
    kv_asset = float(extract_numbers(asset_divide[asset_number]))
    kv_new_list = get_uuid_list_through_filter(f"venture-{_number}-ipo-new-stock")
    kv_exist_list = get_uuid_list_through_filter(f"venture-{_number}-ipo-exist-stock")
    kv_stock_list = kv_new_list + kv_exist_list
    post_list = []
    kv_new_delta, kv_exist_delta = 0, 0
    for _account in kv_stock_list:
        _pages = requests.get(url=input_database.url_book_new + str(_account), params=input_date).json()['body'][
            'pages']
        if _account in kv_new_list:
            for _page in _pages:
                if _page['stockTicker'] == "252670":
                    continue
                kv_new_delta += _page['positionNotionalValue']
        elif _account in kv_exist_list:
            for _page in _pages:
                kv_exist_delta += _page['positionNotionalValue']
    kv_new_room = str(round(((kv_new_delta / 100000000) - (kv_asset * 0.15)), 1)) + " 억원"
    kv_exist_room = str(
        round((((kv_exist_delta + get_venture_corp_delta_in_post(_number)) / 100000000) - (kv_asset * 0.35)),
              1)) + " 억원"
    kv_new_percentage = str(round(((kv_new_delta / 1000000) / kv_asset), 1)) + " %"
    kv_exist_percentage = str(
        round((((kv_exist_delta + get_venture_corp_delta_in_post(_number)) / 1000000) / kv_asset), 1)) + " %"
    return kv_new_percentage, kv_new_room, kv_exist_percentage, kv_exist_room


def venture_trigger():
    kv_1_new_per, kv_1_new_room, kv_1_exist_per, kv_1_exist_room = get_venture_ratio(1)
    kv_2_new_per, kv_2_new_room, kv_2_exist_per, kv_2_exist_room = get_venture_ratio(2)
    kv_3_new_per, kv_3_new_room, kv_3_exist_per, kv_3_exist_room = get_venture_ratio(3)
    ratio_table = {
        "Fund": ["코벤1_신주", "코벤1_구주", "코벤2_신주", "코벤2_구주", "코벤3_신주", "코벤3_구주"],
        "Current_%": [kv_1_new_per, kv_1_exist_per, kv_2_new_per, kv_2_exist_per, kv_3_new_per, kv_3_exist_per],
        "Available": [kv_1_new_room, kv_1_exist_room, kv_2_new_room, kv_2_exist_room, kv_3_new_room, kv_3_exist_room]
    }
    df_regulation = pd.DataFrame(ratio_table)
    regulation_tabulate = tabulate(df_regulation, headers="keys", tablefmt="presto", showindex=False, stralign="left",
                                   numalign='right')
    _parameter = {'content': regulation_tabulate}
    send_nate = requests.post(url=input_database.nateon_regulation, headers=input_database.nateon_header,
                              data=_parameter, timeout=5, verify=False)
    return regulation_tabulate


def kv_stock_regulation():
    kv_f, kv_room, multi_1_f, multi_1_room, multi_2_f, multi_2_room, kv_2_f, kv_2_room, kv_3_f, kv_3_room = fund_futures_percentage()
    regulation_table = {
        "Fund": ["멀티1_파생", "멀티2_파생", "코벤1_파생", "코벤2_파생", "코벤3_파생"],
        "Current_%": [multi_1_f, multi_2_f, kv_f, kv_2_f, kv_3_f],
        "Available": [multi_1_room, multi_2_room, kv_room, kv_2_room, kv_3_room]
    }
    df_regulation = pd.DataFrame(regulation_table)
    regulation_tabulate = tabulate(df_regulation, headers="keys", tablefmt="presto", showindex=False, stralign="left", numalign='right')
    _parameter = {'content': regulation_tabulate}
    send_nate = requests.post(url=input_database.nateon_regulation, headers=input_database.nateon_header, data=_parameter, timeout=5,
                                 verify=False)
    return regulation_tabulate


def send_nate_tabulate():
    except_h_2_pnl = HintsSearch(0)
    pnl_dataframe = except_h_2_pnl.hints_excel()
    missing_val = ""
    pnl_dataframe['펀드'] = pnl_dataframe['펀드'].apply(lambda x: x.ljust(16))
    pnl_dataframe['Chg %'] = pnl_dataframe['Chg %'].apply(lambda x: x.rjust(5))
    pnl_dataframe['MTD'] = pnl_dataframe['MTD'].apply(lambda x: x.rjust(5))
    pnl_dataframe['Total'] = pnl_dataframe['Total'].apply(lambda x: x.rjust(5))

    pnl_table = tabulate(pnl_dataframe, headers='keys', tablefmt='pretty', showindex=False, stralign="center", numalign='center', missingval=missing_val)
    parameter = {'content': pnl_table}
    sendnate = requests.post(url=input_database.nateon_tester, headers=input_database.nateon_header, data=parameter, timeout=5,
                                 verify=False)
    return pnl_table


def main(bond_pnl):
    hints_function = HintsSearch(bond_pnl)
    hints_function.hints_excel()
    print("load positions")
    fund_summary_image()
    print("complete")


input_date = {
        "recordDate": input_database.today_middle_bar
    }
venture_ticker_list = [
    "415380", "381620"
]


def get_another_venture_ratio():
    hints_excel = load_workbook(constants.LONGSHORT_DIR +
        f"/10304_일자별기준가격 조회_{input_database.today_constant}.xlsx"
    )
    hints_standard = hints_excel.active
    sheet = hints_excel["22204_기준가격표"]

    hints_standard.delete_cols(2)
    hints_standard.delete_cols(2)
    hints_standard.delete_cols(13, 30)
    hints_standard.delete_rows(2, 2)
    hints_standard.delete_rows(5, 1)
    hints_standard.delete_rows(6, 2)
    hints_standard.delete_rows(7, 2)
    hints_standard.delete_rows(8, 2)
    hints_standard.delete_rows(10, 11)
    hints_standard.delete_rows(11, 3)
    sheet.column_dimensions.group("A", "B", hidden=True)
    sheet.column_dimensions.group("D", "D", hidden=True)
    sheet.column_dimensions.group("F", "G", hidden=True)
    sheet["C7"].value = "코벤2"
    sheet["C8"].value = "코벤3"
    kv_2_aum_yesterday = sheet["E7"].value
    kv_3_aum_yesterday = sheet["E8"].value
    return kv_2_aum_yesterday, kv_3_aum_yesterday


if __name__ == "__main__":
    # print(send_nate_tabulate())
    # fund_summary_image()
    print(venture_trigger())
    # print(get_krwusd())
    # print(kv_stock_regulation())
    # print(fund_futures_percentage())
    # fund_summary_image()
