import pandas as pd
import constants
import os


def get_dunamis_sector():
    file_path = os.path.join(constants.LONGSHORT_DIR + "/dunamis_sector_list.xlsx")
    df = pd.read_excel(file_path, header=0)
    return df
